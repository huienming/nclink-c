from __future__ import annotations
"""
Autogenerate code from xml spec
Date:2026-05-16 06:47:19.383822+00:00
"""

from datetime import datetime, timezone
from enum import IntEnum, IntFlag
from dataclasses import dataclass, field

from asyncua.ua.uatypes import SByte, Byte, Bytes, ByteString, Int16, Int32, Int64, UInt16, UInt32
from asyncua.ua.uatypes import UInt64, Boolean, Float, Double, Null, String, CharArray, DateTime, Guid
from asyncua.ua.uatypes import AccessLevel, EventNotifier
from asyncua.ua.uatypes import LocalizedText, Variant, QualifiedName, StatusCode, DataValue
from asyncua.ua.uatypes import RelativePath, RelativePathElement
from asyncua.ua.uatypes import NodeId, FourByteNodeId, ExpandedNodeId, ExtensionObject, DiagnosticInfo
from asyncua.ua.uatypes import typeid_by_extension_objects, extension_objects_by_typeid
from asyncua.ua.object_ids import ObjectIds


Image = ByteString


ImageBMP = ByteString


ImageGIF = ByteString


ImageJPG = ByteString


ImagePNG = ByteString


AudioDataType = ByteString


UriString = String


BitFieldMaskDataType = UInt64


SemanticVersionString = String


Handle = UInt32


TrimmedString = String


EncodedTicket = String


NormalizedString = String


DecimalString = String


DurationString = String


TimeString = String


DateString = String


Duration = Double


UtcTime = DateTime


LocaleId = String


Index = UInt32


IntegerId = UInt32


VersionTime = UInt32


ApplicationInstanceCertificate = ByteString


SessionAuthenticationToken = NodeId


ContinuationPoint = ByteString


Counter = UInt32


NumericRange = String


class NamingRuleType(IntEnum):
    """
    :ivar Mandatory:
    :vartype Mandatory: 1
    :ivar Optional:
    :vartype Optional: 2
    :ivar Constraint:
    :vartype Constraint: 3
    """
    Mandatory = 1
    Optional = 2
    Constraint = 3


class RedundantServerMode(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.44

    :ivar PrimaryWithBackup:
    :vartype PrimaryWithBackup: 0
    :ivar PrimaryOnly:
    :vartype PrimaryOnly: 1
    :ivar BackupReady:
    :vartype BackupReady: 2
    :ivar BackupNotReady:
    :vartype BackupNotReady: 3
    """
    PrimaryWithBackup = 0
    PrimaryOnly = 1
    BackupReady = 2
    BackupNotReady = 3


class OpenFileMode(IntEnum):
    """
    :ivar Read:
    :vartype Read: 1
    :ivar Write:
    :vartype Write: 2
    :ivar EraseExisting:
    :vartype EraseExisting: 4
    :ivar Append:
    :vartype Append: 8
    """
    Read = 1
    Write = 2
    EraseExisting = 4
    Append = 8


class IdentityCriteriaType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part18/4.4.4

    :ivar UserName:
    :vartype UserName: 1
    :ivar Thumbprint:
    :vartype Thumbprint: 2
    :ivar Role:
    :vartype Role: 3
    :ivar GroupId:
    :vartype GroupId: 4
    :ivar Anonymous:
    :vartype Anonymous: 5
    :ivar AuthenticatedUser:
    :vartype AuthenticatedUser: 6
    :ivar Application:
    :vartype Application: 7
    :ivar X509Subject:
    :vartype X509Subject: 8
    :ivar TrustedApplication:
    :vartype TrustedApplication: 9
    """
    UserName = 1
    Thumbprint = 2
    Role = 3
    GroupId = 4
    Anonymous = 5
    AuthenticatedUser = 6
    Application = 7
    X509Subject = 8
    TrustedApplication = 9


class ConversionLimitEnum(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/6.6.3

    :ivar NoConversion:
    :vartype NoConversion: 0
    :ivar Limited:
    :vartype Limited: 1
    :ivar Unlimited:
    :vartype Unlimited: 2
    """
    NoConversion = 0
    Limited = 1
    Unlimited = 2


class AlarmMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part9/8.3

    :ivar Active:
    :vartype Active: Bit: 0
    :ivar Unacknowledged:
    :vartype Unacknowledged: Bit: 1
    :ivar Unconfirmed:
    :vartype Unconfirmed: Bit: 2
    """
    Active = 1<<0
    Unacknowledged = 1<<1
    Unconfirmed = 1<<2

    @staticmethod
    def datatype() -> str:
        return "UInt16"


class TrustListValidationOptions(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.2/#7.8.2.10

    :ivar SuppressCertificateExpired:
    :vartype SuppressCertificateExpired: Bit: 0
    :ivar SuppressHostNameInvalid:
    :vartype SuppressHostNameInvalid: Bit: 1
    :ivar SuppressRevocationStatusUnknown:
    :vartype SuppressRevocationStatusUnknown: Bit: 2
    :ivar SuppressIssuerCertificateExpired:
    :vartype SuppressIssuerCertificateExpired: Bit: 3
    :ivar SuppressIssuerRevocationStatusUnknown:
    :vartype SuppressIssuerRevocationStatusUnknown: Bit: 4
    :ivar CheckRevocationStatusOnline:
    :vartype CheckRevocationStatusOnline: Bit: 5
    :ivar CheckRevocationStatusOffline:
    :vartype CheckRevocationStatusOffline: Bit: 6
    """
    SuppressCertificateExpired = 1<<0
    SuppressHostNameInvalid = 1<<1
    SuppressRevocationStatusUnknown = 1<<2
    SuppressIssuerCertificateExpired = 1<<3
    SuppressIssuerRevocationStatusUnknown = 1<<4
    CheckRevocationStatusOnline = 1<<5
    CheckRevocationStatusOffline = 1<<6

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class TrustListMasks(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.2/#7.8.2.9

    :ivar None_:
    :vartype None_: 0
    :ivar TrustedCertificates:
    :vartype TrustedCertificates: 1
    :ivar TrustedCrls:
    :vartype TrustedCrls: 2
    :ivar IssuerCertificates:
    :vartype IssuerCertificates: 4
    :ivar IssuerCrls:
    :vartype IssuerCrls: 8
    :ivar All:
    :vartype All: 15
    """
    None_ = 0
    TrustedCertificates = 1
    TrustedCrls = 2
    IssuerCertificates = 4
    IssuerCrls = 8
    All = 15


class ConfigurationUpdateType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.5/#7.8.5.7

    :ivar Insert:
    :vartype Insert: 1
    :ivar Replace:
    :vartype Replace: 2
    :ivar InsertOrReplace:
    :vartype InsertOrReplace: 3
    :ivar Delete:
    :vartype Delete: 4
    """
    Insert = 1
    Replace = 2
    InsertOrReplace = 3
    Delete = 4


class PubSubState(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.1

    :ivar Disabled:
    :vartype Disabled: 0
    :ivar Paused:
    :vartype Paused: 1
    :ivar Operational:
    :vartype Operational: 2
    :ivar Error:
    :vartype Error: 3
    :ivar PreOperational:
    :vartype PreOperational: 4
    """
    Disabled = 0
    Paused = 1
    Operational = 2
    Error = 3
    PreOperational = 4


class DataSetFieldFlags(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.2.5

    :ivar PromotedField:
    :vartype PromotedField: Bit: 0
    """
    PromotedField = 1<<0

    @staticmethod
    def datatype() -> str:
        return "UInt16"


class ActionState(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.11/#6.2.11.2.1

    :ivar Idle:
    :vartype Idle: 0
    :ivar Executing:
    :vartype Executing: 1
    :ivar Done:
    :vartype Done: 2
    """
    Idle = 0
    Executing = 1
    Done = 2


class DataSetFieldContentMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.4/#6.2.4.2

    :ivar StatusCode:
    :vartype StatusCode: Bit: 0
    :ivar SourceTimestamp:
    :vartype SourceTimestamp: Bit: 1
    :ivar ServerTimestamp:
    :vartype ServerTimestamp: Bit: 2
    :ivar SourcePicoSeconds:
    :vartype SourcePicoSeconds: Bit: 3
    :ivar ServerPicoSeconds:
    :vartype ServerPicoSeconds: Bit: 4
    :ivar RawData:
    :vartype RawData: Bit: 5
    """
    StatusCode = 1<<0
    SourceTimestamp = 1<<1
    ServerTimestamp = 1<<2
    SourcePicoSeconds = 1<<3
    ServerPicoSeconds = 1<<4
    RawData = 1<<5

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class OverrideValueHandling(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.2.4

    :ivar Disabled:
    :vartype Disabled: 0
    :ivar LastUsableValue:
    :vartype LastUsableValue: 1
    :ivar OverrideValue:
    :vartype OverrideValue: 2
    """
    Disabled = 0
    LastUsableValue = 1
    OverrideValue = 2


class DataSetOrderingType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.1/#6.3.1.1.3

    :ivar Undefined:
    :vartype Undefined: 0
    :ivar AscendingWriterId:
    :vartype AscendingWriterId: 1
    :ivar AscendingWriterIdSingle:
    :vartype AscendingWriterIdSingle: 2
    """
    Undefined = 0
    AscendingWriterId = 1
    AscendingWriterIdSingle = 2


class UadpNetworkMessageContentMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.1/#6.3.1.1.4

    :ivar PublisherId:
    :vartype PublisherId: Bit: 0
    :ivar GroupHeader:
    :vartype GroupHeader: Bit: 1
    :ivar WriterGroupId:
    :vartype WriterGroupId: Bit: 2
    :ivar GroupVersion:
    :vartype GroupVersion: Bit: 3
    :ivar NetworkMessageNumber:
    :vartype NetworkMessageNumber: Bit: 4
    :ivar SequenceNumber:
    :vartype SequenceNumber: Bit: 5
    :ivar PayloadHeader:
    :vartype PayloadHeader: Bit: 6
    :ivar Timestamp:
    :vartype Timestamp: Bit: 7
    :ivar PicoSeconds:
    :vartype PicoSeconds: Bit: 8
    :ivar DataSetClassId:
    :vartype DataSetClassId: Bit: 9
    :ivar PromotedFields:
    :vartype PromotedFields: Bit: 10
    """
    PublisherId = 1<<0
    GroupHeader = 1<<1
    WriterGroupId = 1<<2
    GroupVersion = 1<<3
    NetworkMessageNumber = 1<<4
    SequenceNumber = 1<<5
    PayloadHeader = 1<<6
    Timestamp = 1<<7
    PicoSeconds = 1<<8
    DataSetClassId = 1<<9
    PromotedFields = 1<<10

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class UadpDataSetMessageContentMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.1/#6.3.1.3.2

    :ivar Timestamp:
    :vartype Timestamp: Bit: 0
    :ivar PicoSeconds:
    :vartype PicoSeconds: Bit: 1
    :ivar Status:
    :vartype Status: Bit: 2
    :ivar MajorVersion:
    :vartype MajorVersion: Bit: 3
    :ivar MinorVersion:
    :vartype MinorVersion: Bit: 4
    :ivar SequenceNumber:
    :vartype SequenceNumber: Bit: 5
    """
    Timestamp = 1<<0
    PicoSeconds = 1<<1
    Status = 1<<2
    MajorVersion = 1<<3
    MinorVersion = 1<<4
    SequenceNumber = 1<<5

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class JsonNetworkMessageContentMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.2/#6.3.2.1.1

    :ivar NetworkMessageHeader:
    :vartype NetworkMessageHeader: Bit: 0
    :ivar DataSetMessageHeader:
    :vartype DataSetMessageHeader: Bit: 1
    :ivar SingleDataSetMessage:
    :vartype SingleDataSetMessage: Bit: 2
    :ivar PublisherId:
    :vartype PublisherId: Bit: 3
    :ivar DataSetClassId:
    :vartype DataSetClassId: Bit: 4
    :ivar ReplyTo:
    :vartype ReplyTo: Bit: 5
    :ivar WriterGroupName:
    :vartype WriterGroupName: Bit: 6
    """
    NetworkMessageHeader = 1<<0
    DataSetMessageHeader = 1<<1
    SingleDataSetMessage = 1<<2
    PublisherId = 1<<3
    DataSetClassId = 1<<4
    ReplyTo = 1<<5
    WriterGroupName = 1<<6

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class JsonDataSetMessageContentMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.2/#6.3.2.3.1

    :ivar DataSetWriterId:
    :vartype DataSetWriterId: Bit: 0
    :ivar MetaDataVersion:
    :vartype MetaDataVersion: Bit: 1
    :ivar SequenceNumber:
    :vartype SequenceNumber: Bit: 2
    :ivar Timestamp:
    :vartype Timestamp: Bit: 3
    :ivar Status:
    :vartype Status: Bit: 4
    :ivar MessageType:
    :vartype MessageType: Bit: 5
    :ivar DataSetWriterName:
    :vartype DataSetWriterName: Bit: 6
    :ivar FieldEncoding1:
    :vartype FieldEncoding1: Bit: 7
    :ivar PublisherId:
    :vartype PublisherId: Bit: 8
    :ivar WriterGroupName:
    :vartype WriterGroupName: Bit: 9
    :ivar MinorVersion:
    :vartype MinorVersion: Bit: 10
    :ivar FieldEncoding2:
    :vartype FieldEncoding2: Bit: 11
    """
    DataSetWriterId = 1<<0
    MetaDataVersion = 1<<1
    SequenceNumber = 1<<2
    Timestamp = 1<<3
    Status = 1<<4
    MessageType = 1<<5
    DataSetWriterName = 1<<6
    FieldEncoding1 = 1<<7
    PublisherId = 1<<8
    WriterGroupName = 1<<9
    MinorVersion = 1<<10
    FieldEncoding2 = 1<<11

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class BrokerTransportQualityOfService(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.2/#6.4.2.1

    :ivar NotSpecified:
    :vartype NotSpecified: 0
    :ivar BestEffort:
    :vartype BestEffort: 1
    :ivar AtLeastOnce:
    :vartype AtLeastOnce: 2
    :ivar AtMostOnce:
    :vartype AtMostOnce: 3
    :ivar ExactlyOnce:
    :vartype ExactlyOnce: 4
    """
    NotSpecified = 0
    BestEffort = 1
    AtLeastOnce = 2
    AtMostOnce = 3
    ExactlyOnce = 4


class PubSubConfigurationRefMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/9.1.3/#9.1.3.7.2

    :ivar ElementAdd:
    :vartype ElementAdd: Bit: 0
    :ivar ElementMatch:
    :vartype ElementMatch: Bit: 1
    :ivar ElementModify:
    :vartype ElementModify: Bit: 2
    :ivar ElementRemove:
    :vartype ElementRemove: Bit: 3
    :ivar ReferenceWriter:
    :vartype ReferenceWriter: Bit: 4
    :ivar ReferenceReader:
    :vartype ReferenceReader: Bit: 5
    :ivar ReferenceWriterGroup:
    :vartype ReferenceWriterGroup: Bit: 6
    :ivar ReferenceReaderGroup:
    :vartype ReferenceReaderGroup: Bit: 7
    :ivar ReferenceConnection:
    :vartype ReferenceConnection: Bit: 8
    :ivar ReferencePubDataset:
    :vartype ReferencePubDataset: Bit: 9
    :ivar ReferenceSubDataset:
    :vartype ReferenceSubDataset: Bit: 10
    :ivar ReferenceSecurityGroup:
    :vartype ReferenceSecurityGroup: Bit: 11
    :ivar ReferencePushTarget:
    :vartype ReferencePushTarget: Bit: 12
    """
    ElementAdd = 1<<0
    ElementMatch = 1<<1
    ElementModify = 1<<2
    ElementRemove = 1<<3
    ReferenceWriter = 1<<4
    ReferenceReader = 1<<5
    ReferenceWriterGroup = 1<<6
    ReferenceReaderGroup = 1<<7
    ReferenceConnection = 1<<8
    ReferencePubDataset = 1<<9
    ReferenceSubDataset = 1<<10
    ReferenceSecurityGroup = 1<<11
    ReferencePushTarget = 1<<12

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class DiagnosticsLevel(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/9.1.11/#9.1.11.4

    :ivar Basic:
    :vartype Basic: 0
    :ivar Advanced:
    :vartype Advanced: 1
    :ivar Info:
    :vartype Info: 2
    :ivar Log:
    :vartype Log: 3
    :ivar Debug:
    :vartype Debug: 4
    """
    Basic = 0
    Advanced = 1
    Info = 2
    Log = 3
    Debug = 4


class PubSubDiagnosticsCounterClassification(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/9.1.11/#9.1.11.6

    :ivar Information:
    :vartype Information: 0
    :ivar Error:
    :vartype Error: 1
    """
    Information = 0
    Error = 1


class PasswordOptionsMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part18/5.2.2

    :ivar SupportInitialPasswordChange:
    :vartype SupportInitialPasswordChange: Bit: 0
    :ivar SupportDisableUser:
    :vartype SupportDisableUser: Bit: 1
    :ivar SupportDisableDeleteForUser:
    :vartype SupportDisableDeleteForUser: Bit: 2
    :ivar SupportNoChangeForUser:
    :vartype SupportNoChangeForUser: Bit: 3
    :ivar SupportDescriptionForUser:
    :vartype SupportDescriptionForUser: Bit: 4
    :ivar RequiresUpperCaseCharacters:
    :vartype RequiresUpperCaseCharacters: Bit: 5
    :ivar RequiresLowerCaseCharacters:
    :vartype RequiresLowerCaseCharacters: Bit: 6
    :ivar RequiresDigitCharacters:
    :vartype RequiresDigitCharacters: Bit: 7
    :ivar RequiresSpecialCharacters:
    :vartype RequiresSpecialCharacters: Bit: 8
    """
    SupportInitialPasswordChange = 1<<0
    SupportDisableUser = 1<<1
    SupportDisableDeleteForUser = 1<<2
    SupportNoChangeForUser = 1<<3
    SupportDescriptionForUser = 1<<4
    RequiresUpperCaseCharacters = 1<<5
    RequiresLowerCaseCharacters = 1<<6
    RequiresDigitCharacters = 1<<7
    RequiresSpecialCharacters = 1<<8

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class UserConfigurationMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part18/5.2.3

    :ivar NoDelete:
    :vartype NoDelete: Bit: 0
    :ivar Disabled:
    :vartype Disabled: Bit: 1
    :ivar NoChangeByUser:
    :vartype NoChangeByUser: Bit: 2
    :ivar MustChangePassword:
    :vartype MustChangePassword: Bit: 3
    """
    NoDelete = 1<<0
    Disabled = 1<<1
    NoChangeByUser = 1<<2
    MustChangePassword = 1<<3

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class Duplex(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.1

    :ivar Full:
    :vartype Full: 0
    :ivar Half:
    :vartype Half: 1
    :ivar Unknown:
    :vartype Unknown: 2
    """
    Full = 0
    Half = 1
    Unknown = 2


class InterfaceAdminStatus(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.2

    :ivar Up:
    :vartype Up: 0
    :ivar Down:
    :vartype Down: 1
    :ivar Testing:
    :vartype Testing: 2
    """
    Up = 0
    Down = 1
    Testing = 2


class InterfaceOperStatus(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.3

    :ivar Up:
    :vartype Up: 0
    :ivar Down:
    :vartype Down: 1
    :ivar Testing:
    :vartype Testing: 2
    :ivar Unknown:
    :vartype Unknown: 3
    :ivar Dormant:
    :vartype Dormant: 4
    :ivar NotPresent:
    :vartype NotPresent: 5
    :ivar LowerLayerDown:
    :vartype LowerLayerDown: 6
    """
    Up = 0
    Down = 1
    Testing = 2
    Unknown = 3
    Dormant = 4
    NotPresent = 5
    LowerLayerDown = 6


class NegotiationStatus(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.4

    :ivar InProgress:
    :vartype InProgress: 0
    :ivar Complete:
    :vartype Complete: 1
    :ivar Failed:
    :vartype Failed: 2
    :ivar Unknown:
    :vartype Unknown: 3
    :ivar NoNegotiation:
    :vartype NoNegotiation: 4
    """
    InProgress = 0
    Complete = 1
    Failed = 2
    Unknown = 3
    NoNegotiation = 4


class TsnFailureCode(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.5

    :ivar NoFailure:
    :vartype NoFailure: 0
    :ivar InsufficientBandwidth:
    :vartype InsufficientBandwidth: 1
    :ivar InsufficientResources:
    :vartype InsufficientResources: 2
    :ivar InsufficientTrafficClassBandwidth:
    :vartype InsufficientTrafficClassBandwidth: 3
    :ivar StreamIdInUse:
    :vartype StreamIdInUse: 4
    :ivar StreamDestinationAddressInUse:
    :vartype StreamDestinationAddressInUse: 5
    :ivar StreamPreemptedByHigherRank:
    :vartype StreamPreemptedByHigherRank: 6
    :ivar LatencyHasChanged:
    :vartype LatencyHasChanged: 7
    :ivar EgressPortNotAvbCapable:
    :vartype EgressPortNotAvbCapable: 8
    :ivar UseDifferentDestinationAddress:
    :vartype UseDifferentDestinationAddress: 9
    :ivar OutOfMsrpResources:
    :vartype OutOfMsrpResources: 10
    :ivar OutOfMmrpResources:
    :vartype OutOfMmrpResources: 11
    :ivar CannotStoreDestinationAddress:
    :vartype CannotStoreDestinationAddress: 12
    :ivar PriorityIsNotAnSrcClass:
    :vartype PriorityIsNotAnSrcClass: 13
    :ivar MaxFrameSizeTooLarge:
    :vartype MaxFrameSizeTooLarge: 14
    :ivar MaxFanInPortsLimitReached:
    :vartype MaxFanInPortsLimitReached: 15
    :ivar FirstValueChangedForStreamId:
    :vartype FirstValueChangedForStreamId: 16
    :ivar VlanBlockedOnEgress:
    :vartype VlanBlockedOnEgress: 17
    :ivar VlanTaggingDisabledOnEgress:
    :vartype VlanTaggingDisabledOnEgress: 18
    :ivar SrClassPriorityMismatch:
    :vartype SrClassPriorityMismatch: 19
    :ivar FeatureNotPropagated:
    :vartype FeatureNotPropagated: 20
    :ivar MaxLatencyExceeded:
    :vartype MaxLatencyExceeded: 21
    :ivar BridgeDoesNotProvideNetworkId:
    :vartype BridgeDoesNotProvideNetworkId: 22
    :ivar StreamTransformNotSupported:
    :vartype StreamTransformNotSupported: 23
    :ivar StreamIdTypeNotSupported:
    :vartype StreamIdTypeNotSupported: 24
    :ivar FeatureNotSupported:
    :vartype FeatureNotSupported: 25
    """
    NoFailure = 0
    InsufficientBandwidth = 1
    InsufficientResources = 2
    InsufficientTrafficClassBandwidth = 3
    StreamIdInUse = 4
    StreamDestinationAddressInUse = 5
    StreamPreemptedByHigherRank = 6
    LatencyHasChanged = 7
    EgressPortNotAvbCapable = 8
    UseDifferentDestinationAddress = 9
    OutOfMsrpResources = 10
    OutOfMmrpResources = 11
    CannotStoreDestinationAddress = 12
    PriorityIsNotAnSrcClass = 13
    MaxFrameSizeTooLarge = 14
    MaxFanInPortsLimitReached = 15
    FirstValueChangedForStreamId = 16
    VlanBlockedOnEgress = 17
    VlanTaggingDisabledOnEgress = 18
    SrClassPriorityMismatch = 19
    FeatureNotPropagated = 20
    MaxLatencyExceeded = 21
    BridgeDoesNotProvideNetworkId = 22
    StreamTransformNotSupported = 23
    StreamIdTypeNotSupported = 24
    FeatureNotSupported = 25


class TsnStreamState(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.6

    :ivar Disabled:
    :vartype Disabled: 0
    :ivar Configuring:
    :vartype Configuring: 1
    :ivar Ready:
    :vartype Ready: 2
    :ivar Operational:
    :vartype Operational: 3
    :ivar Error:
    :vartype Error: 4
    """
    Disabled = 0
    Configuring = 1
    Ready = 2
    Operational = 3
    Error = 4


class TsnTalkerStatus(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.7

    :ivar None_:
    :vartype None_: 0
    :ivar Ready:
    :vartype Ready: 1
    :ivar Failed:
    :vartype Failed: 2
    """
    None_ = 0
    Ready = 1
    Failed = 2


class TsnListenerStatus(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.8

    :ivar None_:
    :vartype None_: 0
    :ivar Ready:
    :vartype Ready: 1
    :ivar PartialFailed:
    :vartype PartialFailed: 2
    :ivar Failed:
    :vartype Failed: 3
    """
    None_ = 0
    Ready = 1
    PartialFailed = 2
    Failed = 3


class ChassisIdSubtype(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.9

    :ivar ChassisComponent:
    :vartype ChassisComponent: 1
    :ivar InterfaceAlias:
    :vartype InterfaceAlias: 2
    :ivar PortComponent:
    :vartype PortComponent: 3
    :ivar MacAddress:
    :vartype MacAddress: 4
    :ivar NetworkAddress:
    :vartype NetworkAddress: 5
    :ivar InterfaceName:
    :vartype InterfaceName: 6
    :ivar Local:
    :vartype Local: 7
    """
    ChassisComponent = 1
    InterfaceAlias = 2
    PortComponent = 3
    MacAddress = 4
    NetworkAddress = 5
    InterfaceName = 6
    Local = 7


class PortIdSubtype(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.10

    :ivar InterfaceAlias:
    :vartype InterfaceAlias: 1
    :ivar PortComponent:
    :vartype PortComponent: 2
    :ivar MacAddress:
    :vartype MacAddress: 3
    :ivar NetworkAddress:
    :vartype NetworkAddress: 4
    :ivar InterfaceName:
    :vartype InterfaceName: 5
    :ivar AgentCircuitId:
    :vartype AgentCircuitId: 6
    :ivar Local:
    :vartype Local: 7
    """
    InterfaceAlias = 1
    PortComponent = 2
    MacAddress = 3
    NetworkAddress = 4
    InterfaceName = 5
    AgentCircuitId = 6
    Local = 7


class ManAddrIfSubtype(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.1/#5.3.1.11

    :ivar None_:
    :vartype None_: 0
    :ivar Unknown:
    :vartype Unknown: 1
    :ivar PortRef:
    :vartype PortRef: 2
    :ivar SystemPortNumber:
    :vartype SystemPortNumber: 3
    """
    None_ = 0
    Unknown = 1
    PortRef = 2
    SystemPortNumber = 3


class LldpSystemCapabilitiesMap(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.3/#5.3.3.1

    :ivar Other:
    :vartype Other: Bit: 0
    :ivar Repeater:
    :vartype Repeater: Bit: 1
    :ivar Bridge:
    :vartype Bridge: Bit: 2
    :ivar WlanAccessPoint:
    :vartype WlanAccessPoint: Bit: 3
    :ivar Router:
    :vartype Router: Bit: 4
    :ivar Telephone:
    :vartype Telephone: Bit: 5
    :ivar DocsisCableDevice:
    :vartype DocsisCableDevice: Bit: 6
    :ivar StationOnly:
    :vartype StationOnly: Bit: 7
    :ivar CvlanComponent:
    :vartype CvlanComponent: Bit: 8
    :ivar SvlanComponent:
    :vartype SvlanComponent: Bit: 9
    :ivar TwoPortMacRelay:
    :vartype TwoPortMacRelay: Bit: 10
    """
    Other = 1<<0
    Repeater = 1<<1
    Bridge = 1<<2
    WlanAccessPoint = 1<<3
    Router = 1<<4
    Telephone = 1<<5
    DocsisCableDevice = 1<<6
    StationOnly = 1<<7
    CvlanComponent = 1<<8
    SvlanComponent = 1<<9
    TwoPortMacRelay = 1<<10

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class LogRecordMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part26/5.8

    :ivar EventType:
    :vartype EventType: Bit: 0
    :ivar SourceNode:
    :vartype SourceNode: Bit: 1
    :ivar SourceName:
    :vartype SourceName: Bit: 2
    :ivar TraceContext:
    :vartype TraceContext: Bit: 3
    :ivar AdditionalData:
    :vartype AdditionalData: Bit: 4
    """
    EventType = 1<<0
    SourceNode = 1<<1
    SourceName = 1<<2
    TraceContext = 1<<3
    AdditionalData = 1<<4

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class IdType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.2.3

    :ivar Numeric:
    :vartype Numeric: 0
    :ivar String:
    :vartype String: 1
    :ivar Guid:
    :vartype Guid: 2
    :ivar Opaque:
    :vartype Opaque: 3
    """
    Numeric = 0
    String = 1
    Guid = 2
    Opaque = 3


class NodeClass(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.29

    :ivar Unspecified:
    :vartype Unspecified: 0
    :ivar Object:
    :vartype Object: 1
    :ivar Variable:
    :vartype Variable: 2
    :ivar Method:
    :vartype Method: 4
    :ivar ObjectType:
    :vartype ObjectType: 8
    :ivar VariableType:
    :vartype VariableType: 16
    :ivar ReferenceType:
    :vartype ReferenceType: 32
    :ivar DataType:
    :vartype DataType: 64
    :ivar View:
    :vartype View: 128
    """
    Unspecified = 0
    Object = 1
    Variable = 2
    Method = 4
    ObjectType = 8
    VariableType = 16
    ReferenceType = 32
    DataType = 64
    View = 128


class PermissionType(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.55

    :ivar Browse:
    :vartype Browse: Bit: 0
    :ivar ReadRolePermissions:
    :vartype ReadRolePermissions: Bit: 1
    :ivar WriteAttribute:
    :vartype WriteAttribute: Bit: 2
    :ivar WriteRolePermissions:
    :vartype WriteRolePermissions: Bit: 3
    :ivar WriteHistorizing:
    :vartype WriteHistorizing: Bit: 4
    :ivar Read:
    :vartype Read: Bit: 5
    :ivar Write:
    :vartype Write: Bit: 6
    :ivar ReadHistory:
    :vartype ReadHistory: Bit: 7
    :ivar InsertHistory:
    :vartype InsertHistory: Bit: 8
    :ivar ModifyHistory:
    :vartype ModifyHistory: Bit: 9
    :ivar DeleteHistory:
    :vartype DeleteHistory: Bit: 10
    :ivar ReceiveEvents:
    :vartype ReceiveEvents: Bit: 11
    :ivar Call:
    :vartype Call: Bit: 12
    :ivar AddReference:
    :vartype AddReference: Bit: 13
    :ivar RemoveReference:
    :vartype RemoveReference: Bit: 14
    :ivar DeleteNode:
    :vartype DeleteNode: Bit: 15
    :ivar AddNode:
    :vartype AddNode: Bit: 16
    """
    Browse = 1<<0
    ReadRolePermissions = 1<<1
    WriteAttribute = 1<<2
    WriteRolePermissions = 1<<3
    WriteHistorizing = 1<<4
    Read = 1<<5
    Write = 1<<6
    ReadHistory = 1<<7
    InsertHistory = 1<<8
    ModifyHistory = 1<<9
    DeleteHistory = 1<<10
    ReceiveEvents = 1<<11
    Call = 1<<12
    AddReference = 1<<13
    RemoveReference = 1<<14
    DeleteNode = 1<<15
    AddNode = 1<<16

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class AccessLevelType(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.57

    :ivar CurrentRead:
    :vartype CurrentRead: Bit: 0
    :ivar CurrentWrite:
    :vartype CurrentWrite: Bit: 1
    :ivar HistoryRead:
    :vartype HistoryRead: Bit: 2
    :ivar HistoryWrite:
    :vartype HistoryWrite: Bit: 3
    :ivar SemanticChange:
    :vartype SemanticChange: Bit: 4
    :ivar StatusWrite:
    :vartype StatusWrite: Bit: 5
    :ivar TimestampWrite:
    :vartype TimestampWrite: Bit: 6
    """
    CurrentRead = 1<<0
    CurrentWrite = 1<<1
    HistoryRead = 1<<2
    HistoryWrite = 1<<3
    SemanticChange = 1<<4
    StatusWrite = 1<<5
    TimestampWrite = 1<<6

    @staticmethod
    def datatype() -> str:
        return "Byte"


class AccessLevelExType(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.58

    :ivar CurrentRead:
    :vartype CurrentRead: Bit: 0
    :ivar CurrentWrite:
    :vartype CurrentWrite: Bit: 1
    :ivar HistoryRead:
    :vartype HistoryRead: Bit: 2
    :ivar HistoryWrite:
    :vartype HistoryWrite: Bit: 3
    :ivar SemanticChange:
    :vartype SemanticChange: Bit: 4
    :ivar StatusWrite:
    :vartype StatusWrite: Bit: 5
    :ivar TimestampWrite:
    :vartype TimestampWrite: Bit: 6
    :ivar NonatomicRead:
    :vartype NonatomicRead: Bit: 8
    :ivar NonatomicWrite:
    :vartype NonatomicWrite: Bit: 9
    :ivar WriteFullArrayOnly:
    :vartype WriteFullArrayOnly: Bit: 10
    :ivar NoSubDataTypes:
    :vartype NoSubDataTypes: Bit: 11
    :ivar NonVolatile:
    :vartype NonVolatile: Bit: 12
    :ivar Constant:
    :vartype Constant: Bit: 13
    """
    CurrentRead = 1<<0
    CurrentWrite = 1<<1
    HistoryRead = 1<<2
    HistoryWrite = 1<<3
    SemanticChange = 1<<4
    StatusWrite = 1<<5
    TimestampWrite = 1<<6
    NonatomicRead = 1<<8
    NonatomicWrite = 1<<9
    WriteFullArrayOnly = 1<<10
    NoSubDataTypes = 1<<11
    NonVolatile = 1<<12
    Constant = 1<<13

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class EventNotifierType(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.59

    :ivar SubscribeToEvents:
    :vartype SubscribeToEvents: Bit: 0
    :ivar HistoryRead:
    :vartype HistoryRead: Bit: 2
    :ivar HistoryWrite:
    :vartype HistoryWrite: Bit: 3
    """
    SubscribeToEvents = 1<<0
    HistoryRead = 1<<2
    HistoryWrite = 1<<3

    @staticmethod
    def datatype() -> str:
        return "Byte"


class AccessRestrictionType(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.56

    :ivar SigningRequired:
    :vartype SigningRequired: Bit: 0
    :ivar EncryptionRequired:
    :vartype EncryptionRequired: Bit: 1
    :ivar SessionRequired:
    :vartype SessionRequired: Bit: 2
    :ivar ApplyRestrictionsToBrowse:
    :vartype ApplyRestrictionsToBrowse: Bit: 3
    """
    SigningRequired = 1<<0
    EncryptionRequired = 1<<1
    SessionRequired = 1<<2
    ApplyRestrictionsToBrowse = 1<<3

    @staticmethod
    def datatype() -> str:
        return "UInt16"


class StructureType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.49

    :ivar Structure:
    :vartype Structure: 0
    :ivar StructureWithOptionalFields:
    :vartype StructureWithOptionalFields: 1
    :ivar Union:
    :vartype Union: 2
    :ivar StructureWithSubtypedValues:
    :vartype StructureWithSubtypedValues: 3
    :ivar UnionWithSubtypedValues:
    :vartype UnionWithSubtypedValues: 4
    """
    Structure = 0
    StructureWithOptionalFields = 1
    Union = 2
    StructureWithSubtypedValues = 3
    UnionWithSubtypedValues = 4


class ApplicationType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.4

    :ivar Server:
    :vartype Server: 0
    :ivar Client:
    :vartype Client: 1
    :ivar ClientAndServer:
    :vartype ClientAndServer: 2
    :ivar DiscoveryServer:
    :vartype DiscoveryServer: 3
    """
    Server = 0
    Client = 1
    ClientAndServer = 2
    DiscoveryServer = 3


class MessageSecurityMode(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.20

    :ivar Invalid:
    :vartype Invalid: 0
    :ivar None_:
    :vartype None_: 1
    :ivar Sign:
    :vartype Sign: 2
    :ivar SignAndEncrypt:
    :vartype SignAndEncrypt: 3
    """
    Invalid = 0
    None_ = 1
    Sign = 2
    SignAndEncrypt = 3


class UserTokenType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.42

    :ivar Anonymous:
    :vartype Anonymous: 0
    :ivar UserName:
    :vartype UserName: 1
    :ivar Certificate:
    :vartype Certificate: 2
    :ivar IssuedToken:
    :vartype IssuedToken: 3
    """
    Anonymous = 0
    UserName = 1
    Certificate = 2
    IssuedToken = 3


class SecurityTokenRequestType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.3.12

    :ivar Issue:
    :vartype Issue: 0
    :ivar Renew:
    :vartype Renew: 1
    """
    Issue = 0
    Renew = 1


class NodeAttributesMask(IntEnum):
    """
    :ivar None_:
    :vartype None_: 0
    :ivar AccessLevel:
    :vartype AccessLevel: 1
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: 2
    :ivar BrowseName:
    :vartype BrowseName: 4
    :ivar ContainsNoLoops:
    :vartype ContainsNoLoops: 8
    :ivar DataType:
    :vartype DataType: 16
    :ivar Description:
    :vartype Description: 32
    :ivar DisplayName:
    :vartype DisplayName: 64
    :ivar EventNotifier:
    :vartype EventNotifier: 128
    :ivar Executable:
    :vartype Executable: 256
    :ivar Historizing:
    :vartype Historizing: 512
    :ivar InverseName:
    :vartype InverseName: 1024
    :ivar IsAbstract:
    :vartype IsAbstract: 2048
    :ivar MinimumSamplingInterval:
    :vartype MinimumSamplingInterval: 4096
    :ivar NodeClass:
    :vartype NodeClass: 8192
    :ivar NodeId:
    :vartype NodeId: 16384
    :ivar Symmetric:
    :vartype Symmetric: 32768
    :ivar UserAccessLevel:
    :vartype UserAccessLevel: 65536
    :ivar UserExecutable:
    :vartype UserExecutable: 131072
    :ivar UserWriteMask:
    :vartype UserWriteMask: 262144
    :ivar ValueRank:
    :vartype ValueRank: 524288
    :ivar WriteMask:
    :vartype WriteMask: 1048576
    :ivar Value:
    :vartype Value: 2097152
    :ivar DataTypeDefinition:
    :vartype DataTypeDefinition: 4194304
    :ivar RolePermissions:
    :vartype RolePermissions: 8388608
    :ivar AccessRestrictions:
    :vartype AccessRestrictions: 16777216
    :ivar All:
    :vartype All: 33554431
    :ivar BaseNode:
    :vartype BaseNode: 26501220
    :ivar Object:
    :vartype Object: 26501348
    :ivar ObjectType:
    :vartype ObjectType: 26503268
    :ivar Variable:
    :vartype Variable: 26571383
    :ivar VariableType:
    :vartype VariableType: 28600438
    :ivar Method:
    :vartype Method: 26632548
    :ivar ReferenceType:
    :vartype ReferenceType: 26537060
    :ivar View:
    :vartype View: 26501356
    """
    None_ = 0
    AccessLevel = 1
    ArrayDimensions = 2
    BrowseName = 4
    ContainsNoLoops = 8
    DataType = 16
    Description = 32
    DisplayName = 64
    EventNotifier = 128
    Executable = 256
    Historizing = 512
    InverseName = 1024
    IsAbstract = 2048
    MinimumSamplingInterval = 4096
    NodeClass = 8192
    NodeId = 16384
    Symmetric = 32768
    UserAccessLevel = 65536
    UserExecutable = 131072
    UserWriteMask = 262144
    ValueRank = 524288
    WriteMask = 1048576
    Value = 2097152
    DataTypeDefinition = 4194304
    RolePermissions = 8388608
    AccessRestrictions = 16777216
    All = 33554431
    BaseNode = 26501220
    Object = 26501348
    ObjectType = 26503268
    Variable = 26571383
    VariableType = 28600438
    Method = 26632548
    ReferenceType = 26537060
    View = 26501356


class AttributeWriteMask(IntFlag):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.60

    :ivar AccessLevel:
    :vartype AccessLevel: Bit: 0
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: Bit: 1
    :ivar BrowseName:
    :vartype BrowseName: Bit: 2
    :ivar ContainsNoLoops:
    :vartype ContainsNoLoops: Bit: 3
    :ivar DataType:
    :vartype DataType: Bit: 4
    :ivar Description:
    :vartype Description: Bit: 5
    :ivar DisplayName:
    :vartype DisplayName: Bit: 6
    :ivar EventNotifier:
    :vartype EventNotifier: Bit: 7
    :ivar Executable:
    :vartype Executable: Bit: 8
    :ivar Historizing:
    :vartype Historizing: Bit: 9
    :ivar InverseName:
    :vartype InverseName: Bit: 10
    :ivar IsAbstract:
    :vartype IsAbstract: Bit: 11
    :ivar MinimumSamplingInterval:
    :vartype MinimumSamplingInterval: Bit: 12
    :ivar NodeClass:
    :vartype NodeClass: Bit: 13
    :ivar NodeId:
    :vartype NodeId: Bit: 14
    :ivar Symmetric:
    :vartype Symmetric: Bit: 15
    :ivar UserAccessLevel:
    :vartype UserAccessLevel: Bit: 16
    :ivar UserExecutable:
    :vartype UserExecutable: Bit: 17
    :ivar UserWriteMask:
    :vartype UserWriteMask: Bit: 18
    :ivar ValueRank:
    :vartype ValueRank: Bit: 19
    :ivar WriteMask:
    :vartype WriteMask: Bit: 20
    :ivar ValueForVariableType:
    :vartype ValueForVariableType: Bit: 21
    :ivar DataTypeDefinition:
    :vartype DataTypeDefinition: Bit: 22
    :ivar RolePermissions:
    :vartype RolePermissions: Bit: 23
    :ivar AccessRestrictions:
    :vartype AccessRestrictions: Bit: 24
    :ivar AccessLevelEx:
    :vartype AccessLevelEx: Bit: 25
    """
    AccessLevel = 1<<0
    ArrayDimensions = 1<<1
    BrowseName = 1<<2
    ContainsNoLoops = 1<<3
    DataType = 1<<4
    Description = 1<<5
    DisplayName = 1<<6
    EventNotifier = 1<<7
    Executable = 1<<8
    Historizing = 1<<9
    InverseName = 1<<10
    IsAbstract = 1<<11
    MinimumSamplingInterval = 1<<12
    NodeClass = 1<<13
    NodeId = 1<<14
    Symmetric = 1<<15
    UserAccessLevel = 1<<16
    UserExecutable = 1<<17
    UserWriteMask = 1<<18
    ValueRank = 1<<19
    WriteMask = 1<<20
    ValueForVariableType = 1<<21
    DataTypeDefinition = 1<<22
    RolePermissions = 1<<23
    AccessRestrictions = 1<<24
    AccessLevelEx = 1<<25

    @staticmethod
    def datatype() -> str:
        return "UInt32"


class BrowseDirection(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.5

    :ivar Forward:
    :vartype Forward: 0
    :ivar Inverse:
    :vartype Inverse: 1
    :ivar Both:
    :vartype Both: 2
    :ivar Invalid:
    :vartype Invalid: 3
    """
    Forward = 0
    Inverse = 1
    Both = 2
    Invalid = 3


class BrowseResultMask(IntEnum):
    """
    :ivar None_:
    :vartype None_: 0
    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: 1
    :ivar IsForward:
    :vartype IsForward: 2
    :ivar NodeClass:
    :vartype NodeClass: 4
    :ivar BrowseName:
    :vartype BrowseName: 8
    :ivar DisplayName:
    :vartype DisplayName: 16
    :ivar TypeDefinition:
    :vartype TypeDefinition: 32
    :ivar All:
    :vartype All: 63
    :ivar ReferenceTypeInfo:
    :vartype ReferenceTypeInfo: 3
    :ivar TargetInfo:
    :vartype TargetInfo: 60
    """
    None_ = 0
    ReferenceTypeId = 1
    IsForward = 2
    NodeClass = 4
    BrowseName = 8
    DisplayName = 16
    TypeDefinition = 32
    All = 63
    ReferenceTypeInfo = 3
    TargetInfo = 60


class FilterOperator(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.3

    :ivar Equals:
    :vartype Equals: 0
    :ivar IsNull:
    :vartype IsNull: 1
    :ivar GreaterThan:
    :vartype GreaterThan: 2
    :ivar LessThan:
    :vartype LessThan: 3
    :ivar GreaterThanOrEqual:
    :vartype GreaterThanOrEqual: 4
    :ivar LessThanOrEqual:
    :vartype LessThanOrEqual: 5
    :ivar Like:
    :vartype Like: 6
    :ivar Not:
    :vartype Not: 7
    :ivar Between:
    :vartype Between: 8
    :ivar InList:
    :vartype InList: 9
    :ivar And:
    :vartype And: 10
    :ivar Or:
    :vartype Or: 11
    :ivar Cast:
    :vartype Cast: 12
    :ivar InView:
    :vartype InView: 13
    :ivar OfType:
    :vartype OfType: 14
    :ivar RelatedTo:
    :vartype RelatedTo: 15
    :ivar BitwiseAnd:
    :vartype BitwiseAnd: 16
    :ivar BitwiseOr:
    :vartype BitwiseOr: 17
    """
    Equals = 0
    IsNull = 1
    GreaterThan = 2
    LessThan = 3
    GreaterThanOrEqual = 4
    LessThanOrEqual = 5
    Like = 6
    Not = 7
    Between = 8
    InList = 9
    And = 10
    Or = 11
    Cast = 12
    InView = 13
    OfType = 14
    RelatedTo = 15
    BitwiseAnd = 16
    BitwiseOr = 17


class TimestampsToReturn(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.39

    :ivar Source:
    :vartype Source: 0
    :ivar Server:
    :vartype Server: 1
    :ivar Both:
    :vartype Both: 2
    :ivar Neither:
    :vartype Neither: 3
    :ivar Invalid:
    :vartype Invalid: 4
    """
    Source = 0
    Server = 1
    Both = 2
    Neither = 3
    Invalid = 4


class SortOrderType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.8

    :ivar Ascending:
    :vartype Ascending: 0
    :ivar Descending:
    :vartype Descending: 1
    """
    Ascending = 0
    Descending = 1


class HistoryUpdateType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.7

    :ivar Insert:
    :vartype Insert: 1
    :ivar Replace:
    :vartype Replace: 2
    :ivar Update:
    :vartype Update: 3
    :ivar Delete:
    :vartype Delete: 4
    """
    Insert = 1
    Replace = 2
    Update = 3
    Delete = 4


class PerformUpdateType(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.8

    :ivar Insert:
    :vartype Insert: 1
    :ivar Replace:
    :vartype Replace: 2
    :ivar Update:
    :vartype Update: 3
    :ivar Remove:
    :vartype Remove: 4
    """
    Insert = 1
    Replace = 2
    Update = 3
    Remove = 4


class MonitoringMode(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.23

    :ivar Disabled:
    :vartype Disabled: 0
    :ivar Sampling:
    :vartype Sampling: 1
    :ivar Reporting:
    :vartype Reporting: 2
    """
    Disabled = 0
    Sampling = 1
    Reporting = 2


class DataChangeTrigger(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.10

    :ivar Status:
    :vartype Status: 0
    :ivar StatusValue:
    :vartype StatusValue: 1
    :ivar StatusValueTimestamp:
    :vartype StatusValueTimestamp: 2
    """
    Status = 0
    StatusValue = 1
    StatusValueTimestamp = 2


class DeadbandType(IntEnum):
    """
    :ivar None_:
    :vartype None_: 0
    :ivar Absolute:
    :vartype Absolute: 1
    :ivar Percent:
    :vartype Percent: 2
    """
    None_ = 0
    Absolute = 1
    Percent = 2


class RedundancySupport(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.5

    :ivar None_:
    :vartype None_: 0
    :ivar Cold:
    :vartype Cold: 1
    :ivar Warm:
    :vartype Warm: 2
    :ivar Hot:
    :vartype Hot: 3
    :ivar Transparent:
    :vartype Transparent: 4
    :ivar HotAndMirrored:
    :vartype HotAndMirrored: 5
    """
    None_ = 0
    Cold = 1
    Warm = 2
    Hot = 3
    Transparent = 4
    HotAndMirrored = 5


class ServerState(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.6

    :ivar Running:
    :vartype Running: 0
    :ivar Failed:
    :vartype Failed: 1
    :ivar NoConfiguration:
    :vartype NoConfiguration: 2
    :ivar Suspended:
    :vartype Suspended: 3
    :ivar Shutdown:
    :vartype Shutdown: 4
    :ivar Test:
    :vartype Test: 5
    :ivar CommunicationFault:
    :vartype CommunicationFault: 6
    :ivar Unknown:
    :vartype Unknown: 7
    """
    Running = 0
    Failed = 1
    NoConfiguration = 2
    Suspended = 3
    Shutdown = 4
    Test = 5
    CommunicationFault = 6
    Unknown = 7


class ModelChangeStructureVerbMask(IntEnum):
    """
    :ivar NodeAdded:
    :vartype NodeAdded: 1
    :ivar NodeDeleted:
    :vartype NodeDeleted: 2
    :ivar ReferenceAdded:
    :vartype ReferenceAdded: 4
    :ivar ReferenceDeleted:
    :vartype ReferenceDeleted: 8
    :ivar DataTypeChanged:
    :vartype DataTypeChanged: 16
    """
    NodeAdded = 1
    NodeDeleted = 2
    ReferenceAdded = 4
    ReferenceDeleted = 8
    DataTypeChanged = 16


class AxisScaleEnumeration(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.8

    :ivar Linear:
    :vartype Linear: 0
    :ivar Log:
    :vartype Log: 1
    :ivar Ln:
    :vartype Ln: 2
    """
    Linear = 0
    Log = 1
    Ln = 2


class ExceptionDeviationFormat(IntEnum):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/5.2.2

    :ivar AbsoluteValue:
    :vartype AbsoluteValue: 0
    :ivar PercentOfValue:
    :vartype PercentOfValue: 1
    :ivar PercentOfRange:
    :vartype PercentOfRange: 2
    :ivar PercentOfEURange:
    :vartype PercentOfEURange: 3
    :ivar Unknown:
    :vartype Unknown: 4
    """
    AbsoluteValue = 0
    PercentOfValue = 1
    PercentOfRange = 2
    PercentOfEURange = 3
    Unknown = 4


@dataclass(slots=True) # type: ignore
class Union: # type: ignore
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.41

    """

    data_type = NodeId(ObjectIds.Union)


@dataclass(slots=True)
class KeyValuePair:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.21

    :ivar Key:
    :vartype Key: QualifiedName
    :ivar Value:
    :vartype Value: Variant
    """

    data_type = NodeId(ObjectIds.KeyValuePair)

    Key: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    Value: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class AdditionalParametersType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.1

    :ivar Parameters:
    :vartype Parameters: KeyValuePair
    """

    data_type = NodeId(ObjectIds.AdditionalParametersType)

    Parameters: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class EphemeralKeyType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.15

    :ivar PublicKey:
    :vartype PublicKey: ByteString
    :ivar Signature:
    :vartype Signature: ByteString
    """

    data_type = NodeId(ObjectIds.EphemeralKeyType)

    PublicKey: 'ua.ByteString' = None
    Signature: 'ua.ByteString' = None


@dataclass(slots=True)
class EndpointType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part18/4.4.2

    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    :ivar TransportProfileUri:
    :vartype TransportProfileUri: String
    """

    data_type = NodeId(ObjectIds.EndpointType)

    EndpointUrl: 'ua.String' = None
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityPolicyUri: 'ua.String' = None
    TransportProfileUri: 'ua.String' = None


@dataclass(slots=True)
class BitFieldDefinition:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.45

    :ivar Name:
    :vartype Name: String
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar Reserved:
    :vartype Reserved: Boolean
    :ivar StartingBitPosition:
    :vartype StartingBitPosition: UInt32
    :ivar EndingBitPosition:
    :vartype EndingBitPosition: UInt32
    """

    data_type = NodeId(ObjectIds.BitFieldDefinition)

    Name: 'ua.String' = None
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Reserved: 'ua.Boolean' = True
    StartingBitPosition: 'ua.UInt32' = 0
    EndingBitPosition: 'ua.UInt32' = 0


@dataclass(slots=True)
class RationalNumber:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.22

    :ivar Numerator:
    :vartype Numerator: Int32
    :ivar Denominator:
    :vartype Denominator: UInt32
    """

    data_type = NodeId(ObjectIds.RationalNumber)

    Numerator: 'ua.Int32' = 0
    Denominator: 'ua.UInt32' = 0


@dataclass(slots=True)
class Vector:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.23

    """

    data_type = NodeId(ObjectIds.Vector)


@dataclass(slots=True)
class ThreeDVector(Vector):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.24

    :ivar X:
    :vartype X: Double
    :ivar Y:
    :vartype Y: Double
    :ivar Z:
    :vartype Z: Double
    """

    data_type = NodeId(ObjectIds.ThreeDVector)

    X: 'ua.Double' = 0
    Y: 'ua.Double' = 0
    Z: 'ua.Double' = 0


@dataclass(slots=True)
class CartesianCoordinates:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.25

    """

    data_type = NodeId(ObjectIds.CartesianCoordinates)


@dataclass(slots=True)
class ThreeDCartesianCoordinates(CartesianCoordinates):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.26

    :ivar X:
    :vartype X: Double
    :ivar Y:
    :vartype Y: Double
    :ivar Z:
    :vartype Z: Double
    """

    data_type = NodeId(ObjectIds.ThreeDCartesianCoordinates)

    X: 'ua.Double' = 0
    Y: 'ua.Double' = 0
    Z: 'ua.Double' = 0


@dataclass(slots=True)
class Orientation:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.27

    """

    data_type = NodeId(ObjectIds.Orientation)


@dataclass(slots=True)
class ThreeDOrientation(Orientation):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.28

    :ivar A:
    :vartype A: Double
    :ivar B:
    :vartype B: Double
    :ivar C:
    :vartype C: Double
    """

    data_type = NodeId(ObjectIds.ThreeDOrientation)

    A: 'ua.Double' = 0
    B: 'ua.Double' = 0
    C: 'ua.Double' = 0


@dataclass(slots=True)
class Frame:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.29

    """

    data_type = NodeId(ObjectIds.Frame)


@dataclass(slots=True)
class ThreeDFrame(Frame):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.30

    :ivar CartesianCoordinates:
    :vartype CartesianCoordinates: ThreeDCartesianCoordinates
    :ivar Orientation:
    :vartype Orientation: ThreeDOrientation
    """

    data_type = NodeId(ObjectIds.ThreeDFrame)

    CartesianCoordinates: 'ua.ThreeDCartesianCoordinates' = field(default_factory=lambda: ThreeDCartesianCoordinates())
    Orientation: 'ua.ThreeDOrientation' = field(default_factory=lambda: ThreeDOrientation())


@dataclass(slots=True)
class IdentityMappingRuleType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part18/4.4.3

    :ivar CriteriaType:
    :vartype CriteriaType: IdentityCriteriaType
    :ivar Criteria:
    :vartype Criteria: String
    """

    data_type = NodeId(ObjectIds.IdentityMappingRuleType)

    CriteriaType: 'ua.IdentityCriteriaType' = field(default_factory=lambda:IdentityCriteriaType.UserName)
    Criteria: 'ua.String' = None


@dataclass(slots=True)
class CurrencyUnitType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.61

    :ivar NumericCode:
    :vartype NumericCode: Int16
    :ivar Exponent:
    :vartype Exponent: SByte
    :ivar AlphabeticCode:
    :vartype AlphabeticCode: String
    :ivar Currency:
    :vartype Currency: LocalizedText
    """

    data_type = NodeId(ObjectIds.CurrencyUnitType)

    NumericCode: 'ua.Int16' = 0
    Exponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    AlphabeticCode: 'ua.String' = None
    Currency: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class AnnotationDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/6.6.1

    :ivar Annotation:
    :vartype Annotation: String
    :ivar Discipline:
    :vartype Discipline: String
    :ivar Uri:
    :vartype Uri: String
    """

    data_type = NodeId(ObjectIds.AnnotationDataType)

    Annotation: 'ua.String' = None
    Discipline: 'ua.String' = None
    Uri: 'ua.String' = None


@dataclass(slots=True)
class LinearConversionDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/6.6.2

    :ivar InitialAddend:
    :vartype InitialAddend: Float
    :ivar Multiplicand:
    :vartype Multiplicand: Float
    :ivar Divisor:
    :vartype Divisor: Float
    :ivar FinalAddend:
    :vartype FinalAddend: Float
    """

    data_type = NodeId(ObjectIds.LinearConversionDataType)

    InitialAddend: 'ua.Float' = 0
    Multiplicand: 'ua.Float' = 0
    Divisor: 'ua.Float' = 0
    FinalAddend: 'ua.Float' = 0


@dataclass(slots=True)
class QuantityDimension:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/6.6.4

    :ivar MassExponent:
    :vartype MassExponent: SByte
    :ivar LengthExponent:
    :vartype LengthExponent: SByte
    :ivar TimeExponent:
    :vartype TimeExponent: SByte
    :ivar ElectricCurrentExponent:
    :vartype ElectricCurrentExponent: SByte
    :ivar AmountOfSubstanceExponent:
    :vartype AmountOfSubstanceExponent: SByte
    :ivar LuminousIntensityExponent:
    :vartype LuminousIntensityExponent: SByte
    :ivar AbsoluteTemperatureExponent:
    :vartype AbsoluteTemperatureExponent: SByte
    :ivar DimensionlessExponent:
    :vartype DimensionlessExponent: SByte
    """

    data_type = NodeId(ObjectIds.QuantityDimension)

    MassExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    LengthExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    TimeExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    ElectricCurrentExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    AmountOfSubstanceExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    LuminousIntensityExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    AbsoluteTemperatureExponent: 'ua.SByte' = field(default_factory=lambda: SByte())
    DimensionlessExponent: 'ua.SByte' = field(default_factory=lambda: SByte())


@dataclass(slots=True)
class TrustListDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.2/#7.8.2.8

    :ivar SpecifiedLists:
    :vartype SpecifiedLists: UInt32
    :ivar TrustedCertificates:
    :vartype TrustedCertificates: ByteString
    :ivar TrustedCrls:
    :vartype TrustedCrls: ByteString
    :ivar IssuerCertificates:
    :vartype IssuerCertificates: ByteString
    :ivar IssuerCrls:
    :vartype IssuerCrls: ByteString
    """

    data_type = NodeId(ObjectIds.TrustListDataType)

    SpecifiedLists: 'ua.UInt32' = 0
    TrustedCertificates: 'list[ua.ByteString]' = field(default_factory=list)
    TrustedCrls: 'list[ua.ByteString]' = field(default_factory=list)
    IssuerCertificates: 'list[ua.ByteString]' = field(default_factory=list)
    IssuerCrls: 'list[ua.ByteString]' = field(default_factory=list)


@dataclass(slots=True)
class BaseConfigurationDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.5/#7.8.5.4

    :ivar ConfigurationVersion:
    :vartype ConfigurationVersion: VersionTime
    :ivar ConfigurationProperties:
    :vartype ConfigurationProperties: KeyValuePair
    """

    data_type = NodeId(ObjectIds.BaseConfigurationDataType)

    ConfigurationVersion: 'ua.VersionTime' = 0
    ConfigurationProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class BaseConfigurationRecordDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.5/#7.8.5.5

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    """

    data_type = NodeId(ObjectIds.BaseConfigurationRecordDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class CertificateGroupDataType(BaseConfigurationRecordDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.3/#7.8.3.4

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar Purpose:
    :vartype Purpose: NodeId
    :ivar CertificateTypes:
    :vartype CertificateTypes: NodeId
    :ivar IsCertificateAssigned:
    :vartype IsCertificateAssigned: Boolean
    :ivar ValidationOptions:
    :vartype ValidationOptions: TrustListValidationOptions
    """

    data_type = NodeId(ObjectIds.CertificateGroupDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    Purpose: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    CertificateTypes: 'list[ua.NodeId]' = field(default_factory=list)
    IsCertificateAssigned: 'list[ua.Boolean]' = field(default_factory=list)
    ValidationOptions: 'ua.TrustListValidationOptions' = field(default_factory=lambda:TrustListValidationOptions(0))


@dataclass(slots=True)
class ConfigurationUpdateTargetType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.8.5/#7.8.5.6

    :ivar Path:
    :vartype Path: String
    :ivar UpdateType:
    :vartype UpdateType: ConfigurationUpdateType
    """

    data_type = NodeId(ObjectIds.ConfigurationUpdateTargetType)

    Path: 'ua.String' = None
    UpdateType: 'ua.ConfigurationUpdateType' = field(default_factory=lambda:ConfigurationUpdateType.Insert)


@dataclass(slots=True)
class TransactionErrorType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.18

    :ivar TargetId:
    :vartype TargetId: NodeId
    :ivar Error:
    :vartype Error: StatusCode
    :ivar Message:
    :vartype Message: LocalizedText
    """

    data_type = NodeId(ObjectIds.TransactionErrorType)

    TargetId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Error: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    Message: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class EndpointDataType(BaseConfigurationRecordDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.22

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar DiscoveryUrls:
    :vartype DiscoveryUrls: UriString
    :ivar NetworkName:
    :vartype NetworkName: String
    :ivar Port:
    :vartype Port: UInt16
    """

    data_type = NodeId(ObjectIds.EndpointDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    DiscoveryUrls: 'list[ua.UriString]' = field(default_factory=list)
    NetworkName: 'ua.String' = None
    Port: 'ua.UInt16' = 0


@dataclass(slots=True)
class ServerEndpointDataType(EndpointDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.23

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar DiscoveryUrls:
    :vartype DiscoveryUrls: UriString
    :ivar NetworkName:
    :vartype NetworkName: String
    :ivar Port:
    :vartype Port: UInt16
    :ivar EndpointUrls:
    :vartype EndpointUrls: UriString
    :ivar SecuritySettingNames:
    :vartype SecuritySettingNames: String
    :ivar TransportProfileUri:
    :vartype TransportProfileUri: UriString
    :ivar UserTokenSettingNames:
    :vartype UserTokenSettingNames: String
    :ivar ReverseConnectUrls:
    :vartype ReverseConnectUrls: String
    """

    data_type = NodeId(ObjectIds.ServerEndpointDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    DiscoveryUrls: 'list[ua.UriString]' = field(default_factory=list)
    NetworkName: 'ua.String' = None
    Port: 'ua.UInt16' = 0
    EndpointUrls: 'list[ua.UriString]' = field(default_factory=list)
    SecuritySettingNames: 'list[ua.String]' = field(default_factory=list)
    TransportProfileUri: 'ua.UriString' = None
    UserTokenSettingNames: 'list[ua.String]' = field(default_factory=list)
    ReverseConnectUrls: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class SecuritySettingsDataType(BaseConfigurationRecordDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.24

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar SecurityModes:
    :vartype SecurityModes: MessageSecurityMode
    :ivar SecurityPolicyUris:
    :vartype SecurityPolicyUris: String
    :ivar CertificateGroupName:
    :vartype CertificateGroupName: String
    """

    data_type = NodeId(ObjectIds.SecuritySettingsDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    SecurityModes: 'list[ua.MessageSecurityMode]' = field(default_factory=list)
    SecurityPolicyUris: 'list[ua.String]' = field(default_factory=list)
    CertificateGroupName: 'ua.String' = None


@dataclass(slots=True)
class UserTokenSettingsDataType(BaseConfigurationRecordDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.25

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar TokenType:
    :vartype TokenType: UserTokenType
    :ivar IssuedTokenType:
    :vartype IssuedTokenType: String
    :ivar IssuerEndpointUrl:
    :vartype IssuerEndpointUrl: String
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    :ivar CertificateGroupName:
    :vartype CertificateGroupName: String
    :ivar AuthorizationServiceName:
    :vartype AuthorizationServiceName: String
    """

    data_type = NodeId(ObjectIds.UserTokenSettingsDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    TokenType: 'ua.UserTokenType' = field(default_factory=lambda:UserTokenType.Anonymous)
    IssuedTokenType: 'ua.String' = None
    IssuerEndpointUrl: 'ua.String' = None
    SecurityPolicyUri: 'ua.String' = None
    CertificateGroupName: 'ua.String' = None
    AuthorizationServiceName: 'ua.String' = None


@dataclass(slots=True)
class ServiceCertificateDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/9.7.5

    :ivar Certificate:
    :vartype Certificate: ByteString
    :ivar Issuers:
    :vartype Issuers: ByteString
    :ivar ValidFrom:
    :vartype ValidFrom: UtcTime
    :ivar ValidTo:
    :vartype ValidTo: UtcTime
    """

    data_type = NodeId(ObjectIds.ServiceCertificateDataType)

    Certificate: 'ua.ByteString' = None
    Issuers: 'list[ua.ByteString]' = field(default_factory=list)
    ValidFrom: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    ValidTo: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(slots=True)
class AuthorizationServiceConfigurationDataType(BaseConfigurationRecordDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/9.7.5

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar ServiceUri:
    :vartype ServiceUri: UriString
    :ivar ServiceCertificates:
    :vartype ServiceCertificates: ServiceCertificateDataType
    :ivar IssuerEndpointSettings:
    :vartype IssuerEndpointSettings: String
    """

    data_type = NodeId(ObjectIds.AuthorizationServiceConfigurationDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    ServiceUri: 'ua.UriString' = None
    ServiceCertificates: 'list[ua.ServiceCertificateDataType]' = field(default_factory=list)
    IssuerEndpointSettings: 'ua.String' = None


@dataclass(slots=True)
class DecimalDataType:
    """
    :ivar Scale:
    :vartype Scale: Int16
    :ivar Value:
    :vartype Value: ByteString
    """

    data_type = NodeId(ObjectIds.DecimalDataType)

    Scale: 'ua.Int16' = 0
    Value: 'ua.ByteString' = None


@dataclass(slots=True)
class DataTypeDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.32

    :ivar DataTypeId:
    :vartype DataTypeId: NodeId
    :ivar Name:
    :vartype Name: QualifiedName
    """

    data_type = NodeId(ObjectIds.DataTypeDescription)

    DataTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Name: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())


@dataclass(slots=True)
class SimpleTypeDescription(DataTypeDescription):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.35

    :ivar DataTypeId:
    :vartype DataTypeId: NodeId
    :ivar Name:
    :vartype Name: QualifiedName
    :ivar BaseDataType:
    :vartype BaseDataType: NodeId
    :ivar BuiltInType:
    :vartype BuiltInType: Byte
    """

    data_type = NodeId(ObjectIds.SimpleTypeDescription)

    DataTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Name: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    BaseDataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    BuiltInType: 'ua.Byte' = 0


@dataclass(slots=True)
class PortableQualifiedName:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.37

    :ivar NamespaceUri:
    :vartype NamespaceUri: String
    :ivar Name:
    :vartype Name: String
    """

    data_type = NodeId(ObjectIds.PortableQualifiedName)

    NamespaceUri: 'ua.String' = None
    Name: 'ua.String' = None


@dataclass(slots=True)
class UnsignedRationalNumber:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.40

    :ivar Numerator:
    :vartype Numerator: UInt32
    :ivar Denominator:
    :vartype Denominator: UInt32
    """

    data_type = NodeId(ObjectIds.UnsignedRationalNumber)

    Numerator: 'ua.UInt32' = 0
    Denominator: 'ua.UInt32' = 0


@dataclass(slots=True)
class FieldMetaData:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.2.4

    :ivar Name:
    :vartype Name: String
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar FieldFlags:
    :vartype FieldFlags: DataSetFieldFlags
    :ivar BuiltInType:
    :vartype BuiltInType: Byte
    :ivar DataType:
    :vartype DataType: NodeId
    :ivar ValueRank:
    :vartype ValueRank: Int32
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: UInt32
    :ivar MaxStringLength:
    :vartype MaxStringLength: UInt32
    :ivar DataSetFieldId:
    :vartype DataSetFieldId: Guid
    :ivar Properties:
    :vartype Properties: KeyValuePair
    """

    data_type = NodeId(ObjectIds.FieldMetaData)

    Name: 'ua.String' = None
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    FieldFlags: 'ua.DataSetFieldFlags' = field(default_factory=lambda:DataSetFieldFlags(0))
    BuiltInType: 'ua.Byte' = 0
    DataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ValueRank: 'ua.Int32' = 0
    ArrayDimensions: 'list[ua.UInt32]' = field(default_factory=list)
    MaxStringLength: 'ua.UInt32' = 0
    DataSetFieldId: 'ua.Guid' = Guid(int=0)
    Properties: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class ConfigurationVersionDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.2.6

    :ivar MajorVersion:
    :vartype MajorVersion: VersionTime
    :ivar MinorVersion:
    :vartype MinorVersion: VersionTime
    """

    data_type = NodeId(ObjectIds.ConfigurationVersionDataType)

    MajorVersion: 'ua.VersionTime' = 0
    MinorVersion: 'ua.VersionTime' = 0


@dataclass(slots=True)
class PublishedDataSetSourceDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.6

    """

    data_type = NodeId(ObjectIds.PublishedDataSetSourceDataType)


@dataclass(slots=True)
class PublishedVariableDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.7.1

    :ivar PublishedVariable:
    :vartype PublishedVariable: NodeId
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar SamplingIntervalHint:
    :vartype SamplingIntervalHint: Duration
    :ivar DeadbandType:
    :vartype DeadbandType: UInt32
    :ivar DeadbandValue:
    :vartype DeadbandValue: Double
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    :ivar SubstituteValue:
    :vartype SubstituteValue: Variant
    :ivar MetaDataProperties:
    :vartype MetaDataProperties: QualifiedName
    """

    data_type = NodeId(ObjectIds.PublishedVariableDataType)

    PublishedVariable: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AttributeId: 'ua.IntegerId' = 0
    SamplingIntervalHint: 'ua.Duration' = 0
    DeadbandType: 'ua.UInt32' = 0
    DeadbandValue: 'ua.Double' = 0
    IndexRange: 'ua.NumericRange' = None
    SubstituteValue: 'ua.Variant' = field(default_factory=lambda: Variant())
    MetaDataProperties: 'list[ua.QualifiedName]' = field(default_factory=list)


@dataclass(slots=True)
class PublishedDataItemsDataType(PublishedDataSetSourceDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.7.2

    :ivar PublishedData:
    :vartype PublishedData: PublishedVariableDataType
    """

    data_type = NodeId(ObjectIds.PublishedDataItemsDataType)

    PublishedData: 'list[ua.PublishedVariableDataType]' = field(default_factory=list)


@dataclass(slots=True)
class PublishedDataSetCustomSourceDataType(PublishedDataSetSourceDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.9.2

    :ivar CyclicDataSet:
    :vartype CyclicDataSet: Boolean
    """

    data_type = NodeId(ObjectIds.PublishedDataSetCustomSourceDataType)

    CyclicDataSet: 'ua.Boolean' = True


@dataclass(slots=True)
class ActionTargetDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.10.3

    :ivar ActionTargetId:
    :vartype ActionTargetId: UInt16
    :ivar Name:
    :vartype Name: String
    :ivar Description:
    :vartype Description: LocalizedText
    """

    data_type = NodeId(ObjectIds.ActionTargetDataType)

    ActionTargetId: 'ua.UInt16' = 0
    Name: 'ua.String' = None
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class ActionMethodDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.10.5

    :ivar ObjectId:
    :vartype ObjectId: NodeId
    :ivar MethodId:
    :vartype MethodId: NodeId
    """

    data_type = NodeId(ObjectIds.ActionMethodDataType)

    ObjectId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    MethodId: 'ua.NodeId' = field(default_factory=lambda: NodeId())


@dataclass(slots=True)
class DataSetWriterTransportDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.4/#6.2.4.5.2

    """

    data_type = NodeId(ObjectIds.DataSetWriterTransportDataType)


@dataclass(slots=True)
class DataSetWriterMessageDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.4/#6.2.4.5.3

    """

    data_type = NodeId(ObjectIds.DataSetWriterMessageDataType)


@dataclass(slots=True)
class DataSetWriterDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.4/#6.2.4.5.1

    :ivar Name:
    :vartype Name: String
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar DataSetFieldContentMask:
    :vartype DataSetFieldContentMask: DataSetFieldContentMask
    :ivar KeyFrameCount:
    :vartype KeyFrameCount: UInt32
    :ivar DataSetName:
    :vartype DataSetName: String
    :ivar DataSetWriterProperties:
    :vartype DataSetWriterProperties: KeyValuePair
    :ivar TransportSettings:
    :vartype TransportSettings: DataSetWriterTransportDataType
    :ivar MessageSettings:
    :vartype MessageSettings: DataSetWriterMessageDataType
    """

    data_type = NodeId(ObjectIds.DataSetWriterDataType)

    Name: 'ua.String' = None
    Enabled: 'ua.Boolean' = True
    DataSetWriterId: 'ua.UInt16' = 0
    DataSetFieldContentMask: 'ua.DataSetFieldContentMask' = field(default_factory=lambda:DataSetFieldContentMask(0))
    KeyFrameCount: 'ua.UInt32' = 0
    DataSetName: 'ua.String' = None
    DataSetWriterProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    TransportSettings: 'type[ua.DataSetWriterTransportDataType]' = field(default_factory=lambda: DataSetWriterTransportDataType())
    MessageSettings: 'type[ua.DataSetWriterMessageDataType]' = field(default_factory=lambda: DataSetWriterMessageDataType())


@dataclass(slots=True)
class WriterGroupTransportDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.6/#6.2.6.7.2

    """

    data_type = NodeId(ObjectIds.WriterGroupTransportDataType)


@dataclass(slots=True)
class WriterGroupMessageDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.6/#6.2.6.7.3

    """

    data_type = NodeId(ObjectIds.WriterGroupMessageDataType)


@dataclass(slots=True)
class ConnectionTransportDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.7/#6.2.7.5.2

    """

    data_type = NodeId(ObjectIds.ConnectionTransportDataType)


@dataclass(slots=True)
class NetworkAddressDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.7/#6.2.7.5.3

    :ivar NetworkInterface:
    :vartype NetworkInterface: String
    """

    data_type = NodeId(ObjectIds.NetworkAddressDataType)

    NetworkInterface: 'ua.String' = None


@dataclass(slots=True)
class NetworkAddressUrlDataType(NetworkAddressDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.7/#6.2.7.5.4

    :ivar NetworkInterface:
    :vartype NetworkInterface: String
    :ivar Url:
    :vartype Url: String
    """

    data_type = NodeId(ObjectIds.NetworkAddressUrlDataType)

    NetworkInterface: 'ua.String' = None
    Url: 'ua.String' = None


@dataclass(slots=True)
class ReaderGroupTransportDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.8/#6.2.8.2.2

    """

    data_type = NodeId(ObjectIds.ReaderGroupTransportDataType)


@dataclass(slots=True)
class ReaderGroupMessageDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.8/#6.2.8.2.3

    """

    data_type = NodeId(ObjectIds.ReaderGroupMessageDataType)


@dataclass(slots=True)
class DataSetReaderTransportDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.9/#6.2.9.13.2

    """

    data_type = NodeId(ObjectIds.DataSetReaderTransportDataType)


@dataclass(slots=True)
class DataSetReaderMessageDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.9/#6.2.9.13.3

    """

    data_type = NodeId(ObjectIds.DataSetReaderMessageDataType)


@dataclass(slots=True)
class SubscribedDataSetDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.1

    """

    data_type = NodeId(ObjectIds.SubscribedDataSetDataType)


@dataclass(slots=True)
class FieldTargetDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.2.3

    :ivar DataSetFieldId:
    :vartype DataSetFieldId: Guid
    :ivar ReceiverIndexRange:
    :vartype ReceiverIndexRange: NumericRange
    :ivar TargetNodeId:
    :vartype TargetNodeId: NodeId
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar WriteIndexRange:
    :vartype WriteIndexRange: NumericRange
    :ivar OverrideValueHandling:
    :vartype OverrideValueHandling: OverrideValueHandling
    :ivar OverrideValue:
    :vartype OverrideValue: Variant
    """

    data_type = NodeId(ObjectIds.FieldTargetDataType)

    DataSetFieldId: 'ua.Guid' = Guid(int=0)
    ReceiverIndexRange: 'ua.NumericRange' = None
    TargetNodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AttributeId: 'ua.IntegerId' = 0
    WriteIndexRange: 'ua.NumericRange' = None
    OverrideValueHandling: 'ua.OverrideValueHandling' = field(default_factory=lambda:OverrideValueHandling.Disabled)
    OverrideValue: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class TargetVariablesDataType(SubscribedDataSetDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.2.2

    :ivar TargetVariables:
    :vartype TargetVariables: FieldTargetDataType
    """

    data_type = NodeId(ObjectIds.TargetVariablesDataType)

    TargetVariables: 'list[ua.FieldTargetDataType]' = field(default_factory=list)


@dataclass(slots=True)
class StandaloneSubscribedDataSetRefDataType(SubscribedDataSetDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.4

    :ivar DataSetName:
    :vartype DataSetName: String
    """

    data_type = NodeId(ObjectIds.StandaloneSubscribedDataSetRefDataType)

    DataSetName: 'ua.String' = None


@dataclass(slots=True)
class UadpWriterGroupMessageDataType(WriterGroupMessageDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.1/#6.3.1.1.7

    :ivar GroupVersion:
    :vartype GroupVersion: VersionTime
    :ivar DataSetOrdering:
    :vartype DataSetOrdering: DataSetOrderingType
    :ivar NetworkMessageContentMask:
    :vartype NetworkMessageContentMask: UadpNetworkMessageContentMask
    :ivar SamplingOffset:
    :vartype SamplingOffset: Duration
    :ivar PublishingOffset:
    :vartype PublishingOffset: Duration
    """

    data_type = NodeId(ObjectIds.UadpWriterGroupMessageDataType)

    GroupVersion: 'ua.VersionTime' = 0
    DataSetOrdering: 'ua.DataSetOrderingType' = field(default_factory=lambda:DataSetOrderingType.Undefined)
    NetworkMessageContentMask: 'ua.UadpNetworkMessageContentMask' = field(default_factory=lambda:UadpNetworkMessageContentMask(0))
    SamplingOffset: 'ua.Duration' = 0
    PublishingOffset: 'list[ua.Duration]' = field(default_factory=list)


@dataclass(slots=True)
class UadpDataSetWriterMessageDataType(DataSetWriterMessageDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.1/#6.3.1.3.6

    :ivar DataSetMessageContentMask:
    :vartype DataSetMessageContentMask: UadpDataSetMessageContentMask
    :ivar ConfiguredSize:
    :vartype ConfiguredSize: UInt16
    :ivar NetworkMessageNumber:
    :vartype NetworkMessageNumber: UInt16
    :ivar DataSetOffset:
    :vartype DataSetOffset: UInt16
    """

    data_type = NodeId(ObjectIds.UadpDataSetWriterMessageDataType)

    DataSetMessageContentMask: 'ua.UadpDataSetMessageContentMask' = field(default_factory=lambda:UadpDataSetMessageContentMask(0))
    ConfiguredSize: 'ua.UInt16' = 0
    NetworkMessageNumber: 'ua.UInt16' = 0
    DataSetOffset: 'ua.UInt16' = 0


@dataclass(slots=True)
class UadpDataSetReaderMessageDataType(DataSetReaderMessageDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.1/#6.3.1.4.10

    :ivar GroupVersion:
    :vartype GroupVersion: VersionTime
    :ivar NetworkMessageNumber:
    :vartype NetworkMessageNumber: UInt16
    :ivar DataSetOffset:
    :vartype DataSetOffset: UInt16
    :ivar DataSetClassId:
    :vartype DataSetClassId: Guid
    :ivar NetworkMessageContentMask:
    :vartype NetworkMessageContentMask: UadpNetworkMessageContentMask
    :ivar DataSetMessageContentMask:
    :vartype DataSetMessageContentMask: UadpDataSetMessageContentMask
    :ivar PublishingInterval:
    :vartype PublishingInterval: Duration
    :ivar ReceiveOffset:
    :vartype ReceiveOffset: Duration
    :ivar ProcessingOffset:
    :vartype ProcessingOffset: Duration
    """

    data_type = NodeId(ObjectIds.UadpDataSetReaderMessageDataType)

    GroupVersion: 'ua.VersionTime' = 0
    NetworkMessageNumber: 'ua.UInt16' = 0
    DataSetOffset: 'ua.UInt16' = 0
    DataSetClassId: 'ua.Guid' = Guid(int=0)
    NetworkMessageContentMask: 'ua.UadpNetworkMessageContentMask' = field(default_factory=lambda:UadpNetworkMessageContentMask(0))
    DataSetMessageContentMask: 'ua.UadpDataSetMessageContentMask' = field(default_factory=lambda:UadpDataSetMessageContentMask(0))
    PublishingInterval: 'ua.Duration' = 0
    ReceiveOffset: 'ua.Duration' = 0
    ProcessingOffset: 'ua.Duration' = 0


@dataclass(slots=True)
class JsonWriterGroupMessageDataType(WriterGroupMessageDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.2/#6.3.2.1.2

    :ivar NetworkMessageContentMask:
    :vartype NetworkMessageContentMask: JsonNetworkMessageContentMask
    """

    data_type = NodeId(ObjectIds.JsonWriterGroupMessageDataType)

    NetworkMessageContentMask: 'ua.JsonNetworkMessageContentMask' = field(default_factory=lambda:JsonNetworkMessageContentMask(0))


@dataclass(slots=True)
class JsonDataSetWriterMessageDataType(DataSetWriterMessageDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.2/#6.3.2.3.2

    :ivar DataSetMessageContentMask:
    :vartype DataSetMessageContentMask: JsonDataSetMessageContentMask
    """

    data_type = NodeId(ObjectIds.JsonDataSetWriterMessageDataType)

    DataSetMessageContentMask: 'ua.JsonDataSetMessageContentMask' = field(default_factory=lambda:JsonDataSetMessageContentMask(0))


@dataclass(slots=True)
class JsonDataSetReaderMessageDataType(DataSetReaderMessageDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.3.2/#6.3.2.4.3

    :ivar NetworkMessageContentMask:
    :vartype NetworkMessageContentMask: JsonNetworkMessageContentMask
    :ivar DataSetMessageContentMask:
    :vartype DataSetMessageContentMask: JsonDataSetMessageContentMask
    """

    data_type = NodeId(ObjectIds.JsonDataSetReaderMessageDataType)

    NetworkMessageContentMask: 'ua.JsonNetworkMessageContentMask' = field(default_factory=lambda:JsonNetworkMessageContentMask(0))
    DataSetMessageContentMask: 'ua.JsonDataSetMessageContentMask' = field(default_factory=lambda:JsonDataSetMessageContentMask(0))


@dataclass(slots=True)
class QosDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.1.2

    """

    data_type = NodeId(ObjectIds.QosDataType)


@dataclass(slots=True)
class TransmitQosDataType(QosDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.1.3

    """

    data_type = NodeId(ObjectIds.TransmitQosDataType)


@dataclass(slots=True)
class TransmitQosPriorityDataType(TransmitQosDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.1.4.2

    :ivar PriorityLabel:
    :vartype PriorityLabel: String
    """

    data_type = NodeId(ObjectIds.TransmitQosPriorityDataType)

    PriorityLabel: 'ua.String' = None


@dataclass(slots=True)
class ReceiveQosDataType(QosDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.1.5

    """

    data_type = NodeId(ObjectIds.ReceiveQosDataType)


@dataclass(slots=True)
class ReceiveQosPriorityDataType(ReceiveQosDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.1.6.2

    :ivar PriorityLabel:
    :vartype PriorityLabel: String
    """

    data_type = NodeId(ObjectIds.ReceiveQosPriorityDataType)

    PriorityLabel: 'ua.String' = None


@dataclass(slots=True)
class DatagramConnectionTransportDataType(ConnectionTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.2.2

    :ivar DiscoveryAddress:
    :vartype DiscoveryAddress: NetworkAddressDataType
    """

    data_type = NodeId(ObjectIds.DatagramConnectionTransportDataType)

    DiscoveryAddress: 'type[ua.NetworkAddressDataType]' = field(default_factory=lambda: NetworkAddressDataType())


@dataclass(slots=True)
class DatagramConnectionTransport2DataType(DatagramConnectionTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.2.7

    :ivar DiscoveryAddress:
    :vartype DiscoveryAddress: NetworkAddressDataType
    :ivar DiscoveryAnnounceRate:
    :vartype DiscoveryAnnounceRate: UInt32
    :ivar DiscoveryMaxMessageSize:
    :vartype DiscoveryMaxMessageSize: UInt32
    :ivar QosCategory:
    :vartype QosCategory: String
    :ivar DatagramQos:
    :vartype DatagramQos: QosDataType
    """

    data_type = NodeId(ObjectIds.DatagramConnectionTransport2DataType)

    DiscoveryAddress: 'type[ua.NetworkAddressDataType]' = field(default_factory=lambda: NetworkAddressDataType())
    DiscoveryAnnounceRate: 'ua.UInt32' = 0
    DiscoveryMaxMessageSize: 'ua.UInt32' = 0
    QosCategory: 'ua.String' = None
    DatagramQos: 'list[type[ua.QosDataType]]' = field(default_factory=list)


@dataclass(slots=True)
class DatagramWriterGroupTransportDataType(WriterGroupTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.3.3

    :ivar MessageRepeatCount:
    :vartype MessageRepeatCount: Byte
    :ivar MessageRepeatDelay:
    :vartype MessageRepeatDelay: Duration
    """

    data_type = NodeId(ObjectIds.DatagramWriterGroupTransportDataType)

    MessageRepeatCount: 'ua.Byte' = 0
    MessageRepeatDelay: 'ua.Duration' = 0


@dataclass(slots=True)
class DatagramWriterGroupTransport2DataType(DatagramWriterGroupTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.3.9

    :ivar MessageRepeatCount:
    :vartype MessageRepeatCount: Byte
    :ivar MessageRepeatDelay:
    :vartype MessageRepeatDelay: Duration
    :ivar Address:
    :vartype Address: NetworkAddressDataType
    :ivar QosCategory:
    :vartype QosCategory: String
    :ivar DatagramQos:
    :vartype DatagramQos: TransmitQosDataType
    :ivar DiscoveryAnnounceRate:
    :vartype DiscoveryAnnounceRate: UInt32
    :ivar Topic:
    :vartype Topic: String
    """

    data_type = NodeId(ObjectIds.DatagramWriterGroupTransport2DataType)

    MessageRepeatCount: 'ua.Byte' = 0
    MessageRepeatDelay: 'ua.Duration' = 0
    Address: 'type[ua.NetworkAddressDataType]' = field(default_factory=lambda: NetworkAddressDataType())
    QosCategory: 'ua.String' = None
    DatagramQos: 'list[type[ua.TransmitQosDataType]]' = field(default_factory=list)
    DiscoveryAnnounceRate: 'ua.UInt32' = 0
    Topic: 'ua.String' = None


@dataclass(slots=True)
class DatagramDataSetReaderTransportDataType(DataSetReaderTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.6.5

    :ivar Address:
    :vartype Address: NetworkAddressDataType
    :ivar QosCategory:
    :vartype QosCategory: String
    :ivar DatagramQos:
    :vartype DatagramQos: ReceiveQosDataType
    :ivar Topic:
    :vartype Topic: String
    """

    data_type = NodeId(ObjectIds.DatagramDataSetReaderTransportDataType)

    Address: 'type[ua.NetworkAddressDataType]' = field(default_factory=lambda: NetworkAddressDataType())
    QosCategory: 'ua.String' = None
    DatagramQos: 'list[type[ua.ReceiveQosDataType]]' = field(default_factory=list)
    Topic: 'ua.String' = None


@dataclass(slots=True)
class DtlsPubSubConnectionDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.1/#6.4.1.7.6

    :ivar ClientCipherSuite:
    :vartype ClientCipherSuite: String
    :ivar ServerCipherSuites:
    :vartype ServerCipherSuites: String
    :ivar ZeroRTT:
    :vartype ZeroRTT: Boolean
    :ivar CertificateGroupId:
    :vartype CertificateGroupId: NodeId
    :ivar VerifyClientCertificate:
    :vartype VerifyClientCertificate: Boolean
    """

    data_type = NodeId(ObjectIds.DtlsPubSubConnectionDataType)

    ClientCipherSuite: 'ua.String' = None
    ServerCipherSuites: 'list[ua.String]' = field(default_factory=list)
    ZeroRTT: 'ua.Boolean' = True
    CertificateGroupId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    VerifyClientCertificate: 'ua.Boolean' = True


@dataclass(slots=True)
class BrokerConnectionTransportDataType(ConnectionTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.2/#6.4.2.2.3

    :ivar ResourceUri:
    :vartype ResourceUri: String
    :ivar AuthenticationProfileUri:
    :vartype AuthenticationProfileUri: String
    """

    data_type = NodeId(ObjectIds.BrokerConnectionTransportDataType)

    ResourceUri: 'ua.String' = None
    AuthenticationProfileUri: 'ua.String' = None


@dataclass(slots=True)
class BrokerWriterGroupTransportDataType(WriterGroupTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.2/#6.4.2.3.5

    :ivar QueueName:
    :vartype QueueName: String
    :ivar ResourceUri:
    :vartype ResourceUri: String
    :ivar AuthenticationProfileUri:
    :vartype AuthenticationProfileUri: String
    :ivar RequestedDeliveryGuarantee:
    :vartype RequestedDeliveryGuarantee: BrokerTransportQualityOfService
    """

    data_type = NodeId(ObjectIds.BrokerWriterGroupTransportDataType)

    QueueName: 'ua.String' = None
    ResourceUri: 'ua.String' = None
    AuthenticationProfileUri: 'ua.String' = None
    RequestedDeliveryGuarantee: 'ua.BrokerTransportQualityOfService' = field(default_factory=lambda:BrokerTransportQualityOfService.NotSpecified)


@dataclass(slots=True)
class BrokerDataSetWriterTransportDataType(DataSetWriterTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.2/#6.4.2.5.7

    :ivar QueueName:
    :vartype QueueName: String
    :ivar ResourceUri:
    :vartype ResourceUri: String
    :ivar AuthenticationProfileUri:
    :vartype AuthenticationProfileUri: String
    :ivar RequestedDeliveryGuarantee:
    :vartype RequestedDeliveryGuarantee: BrokerTransportQualityOfService
    :ivar MetaDataQueueName:
    :vartype MetaDataQueueName: String
    :ivar MetaDataUpdateTime:
    :vartype MetaDataUpdateTime: Duration
    """

    data_type = NodeId(ObjectIds.BrokerDataSetWriterTransportDataType)

    QueueName: 'ua.String' = None
    ResourceUri: 'ua.String' = None
    AuthenticationProfileUri: 'ua.String' = None
    RequestedDeliveryGuarantee: 'ua.BrokerTransportQualityOfService' = field(default_factory=lambda:BrokerTransportQualityOfService.NotSpecified)
    MetaDataQueueName: 'ua.String' = None
    MetaDataUpdateTime: 'ua.Duration' = 0


@dataclass(slots=True)
class BrokerDataSetReaderTransportDataType(DataSetReaderTransportDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.4.2/#6.4.2.6.6

    :ivar QueueName:
    :vartype QueueName: String
    :ivar ResourceUri:
    :vartype ResourceUri: String
    :ivar AuthenticationProfileUri:
    :vartype AuthenticationProfileUri: String
    :ivar RequestedDeliveryGuarantee:
    :vartype RequestedDeliveryGuarantee: BrokerTransportQualityOfService
    :ivar MetaDataQueueName:
    :vartype MetaDataQueueName: String
    """

    data_type = NodeId(ObjectIds.BrokerDataSetReaderTransportDataType)

    QueueName: 'ua.String' = None
    ResourceUri: 'ua.String' = None
    AuthenticationProfileUri: 'ua.String' = None
    RequestedDeliveryGuarantee: 'ua.BrokerTransportQualityOfService' = field(default_factory=lambda:BrokerTransportQualityOfService.NotSpecified)
    MetaDataQueueName: 'ua.String' = None


@dataclass(slots=True)
class PubSubConfigurationRefDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/9.1.3/#9.1.3.7.3

    :ivar ConfigurationMask:
    :vartype ConfigurationMask: PubSubConfigurationRefMask
    :ivar ElementIndex:
    :vartype ElementIndex: UInt16
    :ivar ConnectionIndex:
    :vartype ConnectionIndex: UInt16
    :ivar GroupIndex:
    :vartype GroupIndex: UInt16
    """

    data_type = NodeId(ObjectIds.PubSubConfigurationRefDataType)

    ConfigurationMask: 'ua.PubSubConfigurationRefMask' = field(default_factory=lambda:PubSubConfigurationRefMask(0))
    ElementIndex: 'ua.UInt16' = 0
    ConnectionIndex: 'ua.UInt16' = 0
    GroupIndex: 'ua.UInt16' = 0


@dataclass(slots=True)
class PubSubConfigurationValueDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/9.1.3/#9.1.3.7.4

    :ivar ConfigurationElement:
    :vartype ConfigurationElement: PubSubConfigurationRefDataType
    :ivar Name:
    :vartype Name: String
    :ivar Identifier:
    :vartype Identifier: Variant
    """

    data_type = NodeId(ObjectIds.PubSubConfigurationValueDataType)

    ConfigurationElement: 'ua.PubSubConfigurationRefDataType' = field(default_factory=lambda: PubSubConfigurationRefDataType())
    Name: 'ua.String' = None
    Identifier: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class JsonNetworkMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar WriterGroupName:
    :vartype WriterGroupName: String
    :ivar DataSetClassId:
    :vartype DataSetClassId: String
    :ivar Messages:
    :vartype Messages: ExtensionObject
    """

    data_type = NodeId(ObjectIds.JsonNetworkMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    WriterGroupName: 'ua.String' = None
    DataSetClassId: 'ua.String' = None
    Messages: 'list[ua.ExtensionObject]' = field(default_factory=list)


@dataclass(slots=True)
class JsonDataSetMessage:
    """
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar DataSetWriterName:
    :vartype DataSetWriterName: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar WriterGroupName:
    :vartype WriterGroupName: String
    :ivar SequenceNumber:
    :vartype SequenceNumber: UInt32
    :ivar MetaDataVersion:
    :vartype MetaDataVersion: ConfigurationVersionDataType
    :ivar MinorVersion:
    :vartype MinorVersion: VersionTime
    :ivar Timestamp:
    :vartype Timestamp: DateTime
    :ivar Status:
    :vartype Status: StatusCode
    :ivar MessageType:
    :vartype MessageType: String
    :ivar Payload:
    :vartype Payload: ExtensionObject
    """

    data_type = NodeId(ObjectIds.JsonDataSetMessage)

    DataSetWriterId: 'ua.UInt16' = 0
    DataSetWriterName: 'ua.String' = None
    PublisherId: 'ua.String' = None
    WriterGroupName: 'ua.String' = None
    SequenceNumber: 'ua.UInt32' = 0
    MetaDataVersion: 'ua.ConfigurationVersionDataType' = field(default_factory=lambda: ConfigurationVersionDataType())
    MinorVersion: 'ua.VersionTime' = 0
    Timestamp: 'ua.DateTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Status: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    MessageType: 'ua.String' = None
    Payload: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class JsonStatusMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar IsCyclic:
    :vartype IsCyclic: Boolean
    :ivar Status:
    :vartype Status: PubSubState
    :ivar NextReportTime:
    :vartype NextReportTime: UtcTime
    """

    data_type = NodeId(ObjectIds.JsonStatusMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    IsCyclic: 'ua.Boolean' = True
    Status: 'ua.PubSubState' = field(default_factory=lambda:PubSubState.Disabled)
    NextReportTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(slots=True)
class JsonActionNetworkMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar ResponseAddress:
    :vartype ResponseAddress: String
    :ivar CorrelationData:
    :vartype CorrelationData: ByteString
    :ivar RequestorId:
    :vartype RequestorId: String
    :ivar TimeoutHint:
    :vartype TimeoutHint: Duration
    :ivar Messages:
    :vartype Messages: ExtensionObject
    """

    data_type = NodeId(ObjectIds.JsonActionNetworkMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    ResponseAddress: 'ua.String' = None
    CorrelationData: 'ua.ByteString' = None
    RequestorId: 'ua.String' = None
    TimeoutHint: 'ua.Duration' = 0
    Messages: 'list[ua.ExtensionObject]' = field(default_factory=list)


@dataclass(slots=True)
class JsonActionRequestMessage:
    """
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar ActionTargetId:
    :vartype ActionTargetId: UInt16
    :ivar DataSetWriterName:
    :vartype DataSetWriterName: String
    :ivar WriterGroupName:
    :vartype WriterGroupName: String
    :ivar MetaDataVersion:
    :vartype MetaDataVersion: ConfigurationVersionDataType
    :ivar MinorVersion:
    :vartype MinorVersion: VersionTime
    :ivar Timestamp:
    :vartype Timestamp: DateTime
    :ivar MessageType:
    :vartype MessageType: String
    :ivar RequestId:
    :vartype RequestId: UInt16
    :ivar ActionState:
    :vartype ActionState: ActionState
    :ivar Payload:
    :vartype Payload: ExtensionObject
    """

    data_type = NodeId(ObjectIds.JsonActionRequestMessage)

    DataSetWriterId: 'ua.UInt16' = 0
    ActionTargetId: 'ua.UInt16' = 0
    DataSetWriterName: 'ua.String' = None
    WriterGroupName: 'ua.String' = None
    MetaDataVersion: 'ua.ConfigurationVersionDataType' = field(default_factory=lambda: ConfigurationVersionDataType())
    MinorVersion: 'ua.VersionTime' = 0
    Timestamp: 'ua.DateTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    MessageType: 'ua.String' = None
    RequestId: 'ua.UInt16' = 0
    ActionState: 'ua.ActionState' = field(default_factory=lambda:ActionState.Idle)
    Payload: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class JsonActionResponseMessage:
    """
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar ActionTargetId:
    :vartype ActionTargetId: UInt16
    :ivar DataSetWriterName:
    :vartype DataSetWriterName: String
    :ivar WriterGroupName:
    :vartype WriterGroupName: String
    :ivar MetaDataVersion:
    :vartype MetaDataVersion: ConfigurationVersionDataType
    :ivar MinorVersion:
    :vartype MinorVersion: VersionTime
    :ivar Timestamp:
    :vartype Timestamp: DateTime
    :ivar Status:
    :vartype Status: StatusCode
    :ivar MessageType:
    :vartype MessageType: String
    :ivar RequestId:
    :vartype RequestId: UInt16
    :ivar ActionState:
    :vartype ActionState: ActionState
    :ivar Payload:
    :vartype Payload: ExtensionObject
    """

    data_type = NodeId(ObjectIds.JsonActionResponseMessage)

    DataSetWriterId: 'ua.UInt16' = 0
    ActionTargetId: 'ua.UInt16' = 0
    DataSetWriterName: 'ua.String' = None
    WriterGroupName: 'ua.String' = None
    MetaDataVersion: 'ua.ConfigurationVersionDataType' = field(default_factory=lambda: ConfigurationVersionDataType())
    MinorVersion: 'ua.VersionTime' = 0
    Timestamp: 'ua.DateTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Status: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    MessageType: 'ua.String' = None
    RequestId: 'ua.UInt16' = 0
    ActionState: 'ua.ActionState' = field(default_factory=lambda:ActionState.Idle)
    Payload: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class AliasNameDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part17/7.2

    :ivar AliasName:
    :vartype AliasName: QualifiedName
    :ivar ReferencedNodes:
    :vartype ReferencedNodes: ExpandedNodeId
    """

    data_type = NodeId(ObjectIds.AliasNameDataType)

    AliasName: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    ReferencedNodes: 'list[ua.ExpandedNodeId]' = field(default_factory=list)


@dataclass(slots=True)
class AliasNameVerboseDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part17/7.3

    :ivar AliasName:
    :vartype AliasName: QualifiedName
    :ivar ReferencedNodes:
    :vartype ReferencedNodes: ExpandedNodeId
    :ivar ServerUris:
    :vartype ServerUris: String
    :ivar AliasNameCategoryId:
    :vartype AliasNameCategoryId: NodeId
    """

    data_type = NodeId(ObjectIds.AliasNameVerboseDataType)

    AliasName: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    ReferencedNodes: 'list[ua.ExpandedNodeId]' = field(default_factory=list)
    ServerUris: 'list[ua.String]' = field(default_factory=list)
    AliasNameCategoryId: 'ua.NodeId' = field(default_factory=lambda: NodeId())


@dataclass(slots=True)
class AliasCategoryUpdateDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part17/D.2.1

    :ivar Category:
    :vartype Category: PortableNodeId
    :ivar LastChange:
    :vartype LastChange: VersionTime
    """

    data_type = NodeId(ObjectIds.AliasCategoryUpdateDataType)

    Category: 'ua.PortableNodeId' = field(default_factory=lambda: PortableNodeId())
    LastChange: 'ua.VersionTime' = 0


@dataclass(slots=True)
class AliasUpdateDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part17/D.2.2

    :ivar ApplicationUri:
    :vartype ApplicationUri: String
    :ivar Categories:
    :vartype Categories: AliasCategoryUpdateDataType
    """

    data_type = NodeId(ObjectIds.AliasUpdateDataType)

    ApplicationUri: 'ua.String' = None
    Categories: 'list[ua.AliasCategoryUpdateDataType]' = field(default_factory=list)


@dataclass(slots=True)
class UserManagementDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part18/5.2.4

    :ivar UserName:
    :vartype UserName: String
    :ivar UserConfiguration:
    :vartype UserConfiguration: UserConfigurationMask
    :ivar Description:
    :vartype Description: String
    """

    data_type = NodeId(ObjectIds.UserManagementDataType)

    UserName: 'ua.String' = None
    UserConfiguration: 'ua.UserConfigurationMask' = field(default_factory=lambda:UserConfigurationMask(0))
    Description: 'ua.String' = None


@dataclass(slots=True)
class PriorityMappingEntryType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.2/#5.3.2.1

    :ivar MappingUri:
    :vartype MappingUri: String
    :ivar PriorityLabel:
    :vartype PriorityLabel: String
    :ivar PriorityValue_PCP:
    :vartype PriorityValue_PCP: Byte
    :ivar PriorityValue_DSCP:
    :vartype PriorityValue_DSCP: UInt32
    """

    data_type = NodeId(ObjectIds.PriorityMappingEntryType)

    MappingUri: 'ua.String' = None
    PriorityLabel: 'ua.String' = None
    PriorityValue_PCP: 'ua.Byte' = 0
    PriorityValue_DSCP: 'ua.UInt32' = 0


@dataclass(slots=True)
class LldpManagementAddressTxPortType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.2/#5.3.2.2

    :ivar AddressSubtype:
    :vartype AddressSubtype: UInt32
    :ivar ManAddress:
    :vartype ManAddress: String
    :ivar TxEnable:
    :vartype TxEnable: Boolean
    :ivar AddrLen:
    :vartype AddrLen: UInt32
    :ivar IfSubtype:
    :vartype IfSubtype: ManAddrIfSubtype
    :ivar IfId:
    :vartype IfId: UInt32
    """

    data_type = NodeId(ObjectIds.LldpManagementAddressTxPortType)

    AddressSubtype: 'ua.UInt32' = 0
    ManAddress: 'ua.String' = None
    TxEnable: 'ua.Boolean' = True
    AddrLen: 'ua.UInt32' = 0
    IfSubtype: 'ua.ManAddrIfSubtype' = field(default_factory=lambda:ManAddrIfSubtype.None_)
    IfId: 'ua.UInt32' = 0


@dataclass(slots=True)
class LldpManagementAddressType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.2/#5.3.2.3

    :ivar AddressSubtype:
    :vartype AddressSubtype: UInt32
    :ivar Address:
    :vartype Address: String
    :ivar IfSubtype:
    :vartype IfSubtype: ManAddrIfSubtype
    :ivar IfId:
    :vartype IfId: UInt32
    """

    data_type = NodeId(ObjectIds.LldpManagementAddressType)

    AddressSubtype: 'ua.UInt32' = 0
    Address: 'ua.String' = None
    IfSubtype: 'ua.ManAddrIfSubtype' = field(default_factory=lambda:ManAddrIfSubtype.None_)
    IfId: 'ua.UInt32' = 0


@dataclass(slots=True)
class LldpTlvType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part22/5.3.2/#5.3.2.4

    :ivar TlvType:
    :vartype TlvType: UInt32
    :ivar TlvInfo:
    :vartype TlvInfo: ByteString
    """

    data_type = NodeId(ObjectIds.LldpTlvType)

    TlvType: 'ua.UInt32' = 0
    TlvInfo: 'ua.ByteString' = None


@dataclass(slots=True)
class ReferenceDescriptionDataType:
    """
    :ivar SourceNode:
    :vartype SourceNode: NodeId
    :ivar ReferenceType:
    :vartype ReferenceType: NodeId
    :ivar IsForward:
    :vartype IsForward: Boolean
    :ivar TargetNode:
    :vartype TargetNode: ExpandedNodeId
    """

    data_type = NodeId(ObjectIds.ReferenceDescriptionDataType)

    SourceNode: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ReferenceType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsForward: 'ua.Boolean' = True
    TargetNode: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())


@dataclass(slots=True)
class ReferenceListEntryDataType:
    """
    :ivar ReferenceType:
    :vartype ReferenceType: NodeId
    :ivar IsForward:
    :vartype IsForward: Boolean
    :ivar TargetNode:
    :vartype TargetNode: ExpandedNodeId
    """

    data_type = NodeId(ObjectIds.ReferenceListEntryDataType)

    ReferenceType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsForward: 'ua.Boolean' = True
    TargetNode: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())


@dataclass(slots=True)
class SpanContextDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part26/5.6.2

    :ivar TraceId:
    :vartype TraceId: Guid
    :ivar SpanId:
    :vartype SpanId: UInt64
    """

    data_type = NodeId(ObjectIds.SpanContextDataType)

    TraceId: 'ua.Guid' = Guid(int=0)
    SpanId: 'ua.UInt64' = 0


@dataclass(slots=True)
class TraceContextDataType(SpanContextDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part26/5.6.3

    :ivar TraceId:
    :vartype TraceId: Guid
    :ivar SpanId:
    :vartype SpanId: UInt64
    :ivar ParentSpanId:
    :vartype ParentSpanId: UInt64
    :ivar ParentIdentifier:
    :vartype ParentIdentifier: String
    """

    data_type = NodeId(ObjectIds.TraceContextDataType)

    TraceId: 'ua.Guid' = Guid(int=0)
    SpanId: 'ua.UInt64' = 0
    ParentSpanId: 'ua.UInt64' = 0
    ParentIdentifier: 'ua.String' = None


@dataclass(slots=True)
class NameValuePair:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part26/5.7

    :ivar Name:
    :vartype Name: String
    :ivar Value:
    :vartype Value: Variant
    """

    data_type = NodeId(ObjectIds.NameValuePair)

    Name: 'ua.String' = None
    Value: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class LogRecord:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part26/5.5

    :ivar Time:
    :vartype Time: DateTime
    :ivar Severity:
    :vartype Severity: UInt16
    :ivar EventType:
    :vartype EventType: NodeId
    :ivar SourceNode:
    :vartype SourceNode: NodeId
    :ivar SourceName:
    :vartype SourceName: String
    :ivar Message:
    :vartype Message: LocalizedText
    :ivar TraceContext:
    :vartype TraceContext: TraceContextDataType
    :ivar AdditionalData:
    :vartype AdditionalData: NameValuePair
    """

    data_type = NodeId(ObjectIds.LogRecord)

    Time: 'ua.DateTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Severity: 'ua.UInt16' = 0
    EventType: 'ua.NodeId | None' = None
    SourceNode: 'ua.NodeId | None' = None
    SourceName: 'ua.String | None' = None
    Message: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    TraceContext: 'ua.TraceContextDataType | None' = None
    AdditionalData: 'list[ua.NameValuePair] | None' = field(default_factory=list)


@dataclass(slots=True)
class LogRecordsDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part26/5.10

    :ivar LogRecordArray:
    :vartype LogRecordArray: LogRecord
    """

    data_type = NodeId(ObjectIds.LogRecordsDataType)

    LogRecordArray: 'list[ua.LogRecord]' = field(default_factory=list)


@dataclass(slots=True)
class RolePermissionType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/5.2.9

    :ivar RoleId:
    :vartype RoleId: NodeId
    :ivar Permissions:
    :vartype Permissions: PermissionType
    """

    data_type = NodeId(ObjectIds.RolePermissionType)

    RoleId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Permissions: 'ua.PermissionType' = field(default_factory=lambda:PermissionType(0))


@dataclass(slots=True)
class SubscribedDataSetMirrorDataType(SubscribedDataSetDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.3.4

    :ivar ParentNodeName:
    :vartype ParentNodeName: String
    :ivar RolePermissions:
    :vartype RolePermissions: RolePermissionType
    """

    data_type = NodeId(ObjectIds.SubscribedDataSetMirrorDataType)

    ParentNodeName: 'ua.String' = None
    RolePermissions: 'list[ua.RolePermissionType]' = field(default_factory=list)


@dataclass(slots=True)
class SecurityGroupDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.12/#6.2.12.2

    :ivar Name:
    :vartype Name: String
    :ivar SecurityGroupFolder:
    :vartype SecurityGroupFolder: String
    :ivar KeyLifetime:
    :vartype KeyLifetime: Duration
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    :ivar MaxFutureKeyCount:
    :vartype MaxFutureKeyCount: UInt32
    :ivar MaxPastKeyCount:
    :vartype MaxPastKeyCount: UInt32
    :ivar SecurityGroupId:
    :vartype SecurityGroupId: String
    :ivar RolePermissions:
    :vartype RolePermissions: RolePermissionType
    :ivar GroupProperties:
    :vartype GroupProperties: KeyValuePair
    """

    data_type = NodeId(ObjectIds.SecurityGroupDataType)

    Name: 'ua.String' = None
    SecurityGroupFolder: 'list[ua.String]' = field(default_factory=list)
    KeyLifetime: 'ua.Duration' = 0
    SecurityPolicyUri: 'ua.String' = None
    MaxFutureKeyCount: 'ua.UInt32' = 0
    MaxPastKeyCount: 'ua.UInt32' = 0
    SecurityGroupId: 'ua.String' = None
    RolePermissions: 'list[ua.RolePermissionType]' = field(default_factory=list)
    GroupProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class DataTypeDefinition:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.47

    """

    data_type = NodeId(ObjectIds.DataTypeDefinition)


@dataclass(slots=True)
class StructureField:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.51

    :ivar Name:
    :vartype Name: String
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar DataType:
    :vartype DataType: NodeId
    :ivar ValueRank:
    :vartype ValueRank: Int32
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: UInt32
    :ivar MaxStringLength:
    :vartype MaxStringLength: UInt32
    :ivar IsOptional:
    :vartype IsOptional: Boolean
    """

    data_type = NodeId(ObjectIds.StructureField)

    Name: 'ua.String' = None
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    DataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ValueRank: 'ua.Int32' = 0
    ArrayDimensions: 'list[ua.UInt32]' = field(default_factory=list)
    MaxStringLength: 'ua.UInt32' = 0
    IsOptional: 'ua.Boolean' = True


@dataclass(slots=True)
class StructureDefinition(DataTypeDefinition):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.48

    :ivar DefaultEncodingId:
    :vartype DefaultEncodingId: NodeId
    :ivar BaseDataType:
    :vartype BaseDataType: NodeId
    :ivar StructureType:
    :vartype StructureType: StructureType
    :ivar Fields:
    :vartype Fields: StructureField
    """

    data_type = NodeId(ObjectIds.StructureDefinition)

    DefaultEncodingId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    BaseDataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    StructureType: 'ua.StructureType' = field(default_factory=lambda:StructureType.Structure)
    Fields: 'list[ua.StructureField]' = field(default_factory=list)


@dataclass(slots=True)
class StructureDescription(DataTypeDescription):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.33

    :ivar DataTypeId:
    :vartype DataTypeId: NodeId
    :ivar Name:
    :vartype Name: QualifiedName
    :ivar StructureDefinition:
    :vartype StructureDefinition: StructureDefinition
    """

    data_type = NodeId(ObjectIds.StructureDescription)

    DataTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Name: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    StructureDefinition: 'ua.StructureDefinition' = field(default_factory=lambda: StructureDefinition())


@dataclass(slots=True)
class Argument:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.6

    :ivar Name:
    :vartype Name: String
    :ivar DataType:
    :vartype DataType: NodeId
    :ivar ValueRank:
    :vartype ValueRank: Int32
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: UInt32
    :ivar Description:
    :vartype Description: LocalizedText
    """

    data_type = NodeId(ObjectIds.Argument)

    Name: 'ua.String' = None
    DataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ValueRank: 'ua.Int32' = 0
    ArrayDimensions: 'list[ua.UInt32]' = field(default_factory=list)
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class EnumValueType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.39

    :ivar Value:
    :vartype Value: Int64
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    """

    data_type = NodeId(ObjectIds.EnumValueType)

    Value: 'ua.Int64' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class EnumField(EnumValueType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.52

    :ivar Value:
    :vartype Value: Int64
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar Name:
    :vartype Name: String
    """

    data_type = NodeId(ObjectIds.EnumField)

    Value: 'ua.Int64' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Name: 'ua.String' = None


@dataclass(slots=True)
class EnumDefinition(DataTypeDefinition):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.50

    :ivar Fields:
    :vartype Fields: EnumField
    """

    data_type = NodeId(ObjectIds.EnumDefinition)

    Fields: 'list[ua.EnumField]' = field(default_factory=list)


@dataclass(slots=True)
class EnumDescription(DataTypeDescription):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.34

    :ivar DataTypeId:
    :vartype DataTypeId: NodeId
    :ivar Name:
    :vartype Name: QualifiedName
    :ivar EnumDefinition:
    :vartype EnumDefinition: EnumDefinition
    :ivar BuiltInType:
    :vartype BuiltInType: Byte
    """

    data_type = NodeId(ObjectIds.EnumDescription)

    DataTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Name: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    EnumDefinition: 'ua.EnumDefinition' = field(default_factory=lambda: EnumDefinition())
    BuiltInType: 'ua.Byte' = 0


@dataclass(slots=True)
class DataTypeSchemaHeader:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.31

    :ivar Namespaces:
    :vartype Namespaces: String
    :ivar StructureDataTypes:
    :vartype StructureDataTypes: StructureDescription
    :ivar EnumDataTypes:
    :vartype EnumDataTypes: EnumDescription
    :ivar SimpleDataTypes:
    :vartype SimpleDataTypes: SimpleTypeDescription
    """

    data_type = NodeId(ObjectIds.DataTypeSchemaHeader)

    Namespaces: 'list[ua.String]' = field(default_factory=list)
    StructureDataTypes: 'list[ua.StructureDescription]' = field(default_factory=list)
    EnumDataTypes: 'list[ua.EnumDescription]' = field(default_factory=list)
    SimpleDataTypes: 'list[ua.SimpleTypeDescription]' = field(default_factory=list)


@dataclass(slots=True)
class UABinaryFileDataType(DataTypeSchemaHeader):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.36

    :ivar Namespaces:
    :vartype Namespaces: String
    :ivar StructureDataTypes:
    :vartype StructureDataTypes: StructureDescription
    :ivar EnumDataTypes:
    :vartype EnumDataTypes: EnumDescription
    :ivar SimpleDataTypes:
    :vartype SimpleDataTypes: SimpleTypeDescription
    :ivar SchemaLocation:
    :vartype SchemaLocation: String
    :ivar FileHeader:
    :vartype FileHeader: KeyValuePair
    :ivar Body:
    :vartype Body: Variant
    """

    data_type = NodeId(ObjectIds.UABinaryFileDataType)

    Namespaces: 'list[ua.String]' = field(default_factory=list)
    StructureDataTypes: 'list[ua.StructureDescription]' = field(default_factory=list)
    EnumDataTypes: 'list[ua.EnumDescription]' = field(default_factory=list)
    SimpleDataTypes: 'list[ua.SimpleTypeDescription]' = field(default_factory=list)
    SchemaLocation: 'ua.String' = None
    FileHeader: 'list[ua.KeyValuePair]' = field(default_factory=list)
    Body: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class DataSetMetaDataType(DataTypeSchemaHeader):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.2.3

    :ivar Namespaces:
    :vartype Namespaces: String
    :ivar StructureDataTypes:
    :vartype StructureDataTypes: StructureDescription
    :ivar EnumDataTypes:
    :vartype EnumDataTypes: EnumDescription
    :ivar SimpleDataTypes:
    :vartype SimpleDataTypes: SimpleTypeDescription
    :ivar Name:
    :vartype Name: String
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar Fields:
    :vartype Fields: FieldMetaData
    :ivar DataSetClassId:
    :vartype DataSetClassId: Guid
    :ivar ConfigurationVersion:
    :vartype ConfigurationVersion: ConfigurationVersionDataType
    """

    data_type = NodeId(ObjectIds.DataSetMetaDataType)

    Namespaces: 'list[ua.String]' = field(default_factory=list)
    StructureDataTypes: 'list[ua.StructureDescription]' = field(default_factory=list)
    EnumDataTypes: 'list[ua.EnumDescription]' = field(default_factory=list)
    SimpleDataTypes: 'list[ua.SimpleTypeDescription]' = field(default_factory=list)
    Name: 'ua.String' = None
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Fields: 'list[ua.FieldMetaData]' = field(default_factory=list)
    DataSetClassId: 'ua.Guid' = Guid(int=0)
    ConfigurationVersion: 'ua.ConfigurationVersionDataType' = field(default_factory=lambda: ConfigurationVersionDataType())


@dataclass(slots=True)
class PublishedDataSetDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.5

    :ivar Name:
    :vartype Name: String
    :ivar DataSetFolder:
    :vartype DataSetFolder: String
    :ivar DataSetMetaData:
    :vartype DataSetMetaData: DataSetMetaDataType
    :ivar ExtensionFields:
    :vartype ExtensionFields: KeyValuePair
    :ivar DataSetSource:
    :vartype DataSetSource: PublishedDataSetSourceDataType
    """

    data_type = NodeId(ObjectIds.PublishedDataSetDataType)

    Name: 'ua.String' = None
    DataSetFolder: 'list[ua.String]' = field(default_factory=list)
    DataSetMetaData: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    ExtensionFields: 'list[ua.KeyValuePair]' = field(default_factory=list)
    DataSetSource: 'type[ua.PublishedDataSetSourceDataType]' = field(default_factory=lambda: PublishedDataSetSourceDataType())


@dataclass(slots=True)
class PublishedActionDataType(PublishedDataSetSourceDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.10.4

    :ivar RequestDataSetMetaData:
    :vartype RequestDataSetMetaData: DataSetMetaDataType
    :ivar ActionTargets:
    :vartype ActionTargets: ActionTargetDataType
    """

    data_type = NodeId(ObjectIds.PublishedActionDataType)

    RequestDataSetMetaData: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    ActionTargets: 'list[ua.ActionTargetDataType]' = field(default_factory=list)


@dataclass(slots=True)
class PublishedActionMethodDataType(PublishedActionDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.10.6

    :ivar RequestDataSetMetaData:
    :vartype RequestDataSetMetaData: DataSetMetaDataType
    :ivar ActionTargets:
    :vartype ActionTargets: ActionTargetDataType
    :ivar ActionMethods:
    :vartype ActionMethods: ActionMethodDataType
    """

    data_type = NodeId(ObjectIds.PublishedActionMethodDataType)

    RequestDataSetMetaData: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    ActionTargets: 'list[ua.ActionTargetDataType]' = field(default_factory=list)
    ActionMethods: 'list[ua.ActionMethodDataType]' = field(default_factory=list)


@dataclass(slots=True)
class StandaloneSubscribedDataSetDataType(SubscribedDataSetDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.10/#6.2.10.5

    :ivar Name:
    :vartype Name: String
    :ivar DataSetFolder:
    :vartype DataSetFolder: String
    :ivar DataSetMetaData:
    :vartype DataSetMetaData: DataSetMetaDataType
    :ivar SubscribedDataSet:
    :vartype SubscribedDataSet: SubscribedDataSetDataType
    """

    data_type = NodeId(ObjectIds.StandaloneSubscribedDataSetDataType)

    Name: 'ua.String' = None
    DataSetFolder: 'list[ua.String]' = field(default_factory=list)
    DataSetMetaData: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    SubscribedDataSet: 'type[ua.SubscribedDataSetDataType]' = field(default_factory=lambda: SubscribedDataSetDataType())


@dataclass(slots=True)
class JsonDataSetMetaDataMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar WriterGroupName:
    :vartype WriterGroupName: String
    :ivar DataSetWriterName:
    :vartype DataSetWriterName: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar MetaData:
    :vartype MetaData: DataSetMetaDataType
    """

    data_type = NodeId(ObjectIds.JsonDataSetMetaDataMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    DataSetWriterId: 'ua.UInt16' = 0
    WriterGroupName: 'ua.String' = None
    DataSetWriterName: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    MetaData: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())


@dataclass(slots=True)
class JsonActionMetaDataMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar DataSetWriterName:
    :vartype DataSetWriterName: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar ActionTargets:
    :vartype ActionTargets: ActionTargetDataType
    :ivar Request:
    :vartype Request: DataSetMetaDataType
    :ivar Response:
    :vartype Response: DataSetMetaDataType
    :ivar ActionMethods:
    :vartype ActionMethods: ActionMethodDataType
    """

    data_type = NodeId(ObjectIds.JsonActionMetaDataMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    DataSetWriterId: 'ua.UInt16' = 0
    DataSetWriterName: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    ActionTargets: 'list[ua.ActionTargetDataType]' = field(default_factory=list)
    Request: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    Response: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    ActionMethods: 'list[ua.ActionMethodDataType]' = field(default_factory=list)


@dataclass(slots=True)
class OptionSet:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.40

    :ivar Value:
    :vartype Value: ByteString
    :ivar ValidBits:
    :vartype ValidBits: ByteString
    """

    data_type = NodeId(ObjectIds.OptionSet)

    Value: 'ua.ByteString' = None
    ValidBits: 'ua.ByteString' = None


@dataclass(slots=True)
class TimeZoneDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part3/8.28

    :ivar Offset:
    :vartype Offset: Int16
    :ivar DaylightSavingInOffset:
    :vartype DaylightSavingInOffset: Boolean
    """

    data_type = NodeId(ObjectIds.TimeZoneDataType)

    Offset: 'ua.Int16' = 0
    DaylightSavingInOffset: 'ua.Boolean' = True


@dataclass(slots=True)
class ApplicationDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.2

    :ivar ApplicationUri:
    :vartype ApplicationUri: String
    :ivar ProductUri:
    :vartype ProductUri: String
    :ivar ApplicationName:
    :vartype ApplicationName: LocalizedText
    :ivar ApplicationType:
    :vartype ApplicationType: ApplicationType
    :ivar GatewayServerUri:
    :vartype GatewayServerUri: String
    :ivar DiscoveryProfileUri:
    :vartype DiscoveryProfileUri: String
    :ivar DiscoveryUrls:
    :vartype DiscoveryUrls: String
    """

    data_type = NodeId(ObjectIds.ApplicationDescription)

    ApplicationUri: 'ua.String' = None
    ProductUri: 'ua.String' = None
    ApplicationName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    ApplicationType: 'ua.ApplicationType' = field(default_factory=lambda:ApplicationType.Server)
    GatewayServerUri: 'ua.String' = None
    DiscoveryProfileUri: 'ua.String' = None
    DiscoveryUrls: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class ApplicationIdentityDataType(BaseConfigurationRecordDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.21

    :ivar Name:
    :vartype Name: String
    :ivar RecordProperties:
    :vartype RecordProperties: KeyValuePair
    :ivar ApplicationUri:
    :vartype ApplicationUri: UriString
    :ivar ApplicationNames:
    :vartype ApplicationNames: LocalizedText
    :ivar AdditionalServers:
    :vartype AdditionalServers: ApplicationDescription
    """

    data_type = NodeId(ObjectIds.ApplicationIdentityDataType)

    Name: 'ua.String' = None
    RecordProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    ApplicationUri: 'ua.UriString' = None
    ApplicationNames: 'list[ua.LocalizedText]' = field(default_factory=list)
    AdditionalServers: 'list[ua.ApplicationDescription]' = field(default_factory=list)


@dataclass(slots=True)
class ApplicationConfigurationDataType(BaseConfigurationDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part12/7.10.19

    :ivar ConfigurationVersion:
    :vartype ConfigurationVersion: VersionTime
    :ivar ConfigurationProperties:
    :vartype ConfigurationProperties: KeyValuePair
    :ivar ApplicationIdentity:
    :vartype ApplicationIdentity: ApplicationIdentityDataType
    :ivar CertificateGroups:
    :vartype CertificateGroups: CertificateGroupDataType
    :ivar ServerEndpoints:
    :vartype ServerEndpoints: ServerEndpointDataType
    :ivar ClientEndpoints:
    :vartype ClientEndpoints: EndpointDataType
    :ivar SecuritySettings:
    :vartype SecuritySettings: SecuritySettingsDataType
    :ivar UserTokenSettings:
    :vartype UserTokenSettings: UserTokenSettingsDataType
    :ivar AuthorizationServices:
    :vartype AuthorizationServices: AuthorizationServiceConfigurationDataType
    """

    data_type = NodeId(ObjectIds.ApplicationConfigurationDataType)

    ConfigurationVersion: 'ua.VersionTime' = 0
    ConfigurationProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    ApplicationIdentity: 'ua.ApplicationIdentityDataType' = field(default_factory=lambda: ApplicationIdentityDataType())
    CertificateGroups: 'list[ua.CertificateGroupDataType]' = field(default_factory=list)
    ServerEndpoints: 'list[ua.ServerEndpointDataType]' = field(default_factory=list)
    ClientEndpoints: 'list[ua.EndpointDataType]' = field(default_factory=list)
    SecuritySettings: 'list[ua.SecuritySettingsDataType]' = field(default_factory=list)
    UserTokenSettings: 'list[ua.UserTokenSettingsDataType]' = field(default_factory=list)
    AuthorizationServices: 'list[ua.AuthorizationServiceConfigurationDataType]' = field(default_factory=list)


@dataclass(slots=True)
class JsonApplicationDescriptionMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar Description:
    :vartype Description: ApplicationDescription
    :ivar ServerCapabilities:
    :vartype ServerCapabilities: String
    """

    data_type = NodeId(ObjectIds.JsonApplicationDescriptionMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Description: 'ua.ApplicationDescription' = field(default_factory=lambda: ApplicationDescription())
    ServerCapabilities: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class RequestHeader:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.32

    :ivar AuthenticationToken:
    :vartype AuthenticationToken: SessionAuthenticationToken
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar RequestHandle:
    :vartype RequestHandle: IntegerId
    :ivar ReturnDiagnostics:
    :vartype ReturnDiagnostics: UInt32
    :ivar AuditEntryId:
    :vartype AuditEntryId: String
    :ivar TimeoutHint:
    :vartype TimeoutHint: UInt32
    :ivar AdditionalHeader:
    :vartype AdditionalHeader: ExtensionObject
    """

    data_type = NodeId(ObjectIds.RequestHeader)

    AuthenticationToken: 'ua.SessionAuthenticationToken' = field(default_factory=lambda: NodeId())
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    RequestHandle: 'ua.IntegerId' = 0
    ReturnDiagnostics: 'ua.UInt32' = 0
    AuditEntryId: 'ua.String' = None
    TimeoutHint: 'ua.UInt32' = 0
    AdditionalHeader: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class ResponseHeader:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.33

    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar RequestHandle:
    :vartype RequestHandle: IntegerId
    :ivar ServiceResult:
    :vartype ServiceResult: StatusCode
    :ivar ServiceDiagnostics:
    :vartype ServiceDiagnostics: DiagnosticInfo
    :ivar StringTable:
    :vartype StringTable: String
    :ivar AdditionalHeader:
    :vartype AdditionalHeader: ExtensionObject
    """

    data_type = NodeId(ObjectIds.ResponseHeader)

    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    RequestHandle: 'ua.IntegerId' = 0
    ServiceResult: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    ServiceDiagnostics: 'ua.DiagnosticInfo' = field(default_factory=lambda: DiagnosticInfo())
    StringTable: 'list[ua.String]' = field(default_factory=list)
    AdditionalHeader: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class ServiceFault:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.34

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    """

    data_type = NodeId(ObjectIds.ServiceFault)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ServiceFault_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())


@dataclass(slots=True)
class SessionlessInvokeRequestType:
    """
    :ivar UrisVersion:
    :vartype UrisVersion: VersionTime
    :ivar NamespaceUris:
    :vartype NamespaceUris: String
    :ivar ServerUris:
    :vartype ServerUris: String
    :ivar LocaleIds:
    :vartype LocaleIds: LocaleId
    :ivar ServiceId:
    :vartype ServiceId: UInt32
    """

    data_type = NodeId(ObjectIds.SessionlessInvokeRequestType)

    UrisVersion: 'ua.VersionTime' = 0
    NamespaceUris: 'list[ua.String]' = field(default_factory=list)
    ServerUris: 'list[ua.String]' = field(default_factory=list)
    LocaleIds: 'list[ua.LocaleId]' = field(default_factory=list)
    ServiceId: 'ua.UInt32' = 0


@dataclass(slots=True)
class SessionlessInvokeResponseType:
    """
    :ivar NamespaceUris:
    :vartype NamespaceUris: String
    :ivar ServerUris:
    :vartype ServerUris: String
    :ivar ServiceId:
    :vartype ServiceId: UInt32
    """

    data_type = NodeId(ObjectIds.SessionlessInvokeResponseType)

    NamespaceUris: 'list[ua.String]' = field(default_factory=list)
    ServerUris: 'list[ua.String]' = field(default_factory=list)
    ServiceId: 'ua.UInt32' = 0


@dataclass(slots=True)
class FindServersParameters:
    """
    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar LocaleIds:
    :vartype LocaleIds: LocaleId
    :ivar ServerUris:
    :vartype ServerUris: String
    """

    EndpointUrl: 'ua.String' = None
    LocaleIds: 'list[ua.LocaleId]' = field(default_factory=list)
    ServerUris: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class FindServersRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.2/#5.5.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: FindServersParameters
    """

    data_type = NodeId(ObjectIds.FindServersRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.FindServersRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.FindServersParameters' = field(default_factory=lambda: FindServersParameters())


@dataclass(slots=True)
class FindServersResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.2/#5.5.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Servers:
    :vartype Servers: ApplicationDescription
    """

    data_type = NodeId(ObjectIds.FindServersResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.FindServersResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Servers: 'list[ua.ApplicationDescription]' = field(default_factory=list)


@dataclass(slots=True)
class ServerOnNetwork:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.3/#5.5.3.2

    :ivar RecordId:
    :vartype RecordId: UInt32
    :ivar ServerName:
    :vartype ServerName: String
    :ivar DiscoveryUrl:
    :vartype DiscoveryUrl: String
    :ivar ServerCapabilities:
    :vartype ServerCapabilities: String
    """

    data_type = NodeId(ObjectIds.ServerOnNetwork)

    RecordId: 'ua.UInt32' = 0
    ServerName: 'ua.String' = None
    DiscoveryUrl: 'ua.String' = None
    ServerCapabilities: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class FindServersOnNetworkParameters:
    """
    :ivar StartingRecordId:
    :vartype StartingRecordId: Counter
    :ivar MaxRecordsToReturn:
    :vartype MaxRecordsToReturn: UInt32
    :ivar ServerCapabilityFilter:
    :vartype ServerCapabilityFilter: String
    """

    StartingRecordId: 'ua.Counter' = 0
    MaxRecordsToReturn: 'ua.UInt32' = 0
    ServerCapabilityFilter: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class FindServersOnNetworkRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.3/#5.5.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: FindServersOnNetworkParameters
    """

    data_type = NodeId(ObjectIds.FindServersOnNetworkRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.FindServersOnNetworkRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.FindServersOnNetworkParameters' = field(default_factory=lambda: FindServersOnNetworkParameters())


@dataclass(slots=True)
class FindServersOnNetworkResult:
    """
    :ivar LastCounterResetTime:
    :vartype LastCounterResetTime: UtcTime
    :ivar Servers:
    :vartype Servers: ServerOnNetwork
    """

    LastCounterResetTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Servers: 'list[ua.ServerOnNetwork]' = field(default_factory=list)


@dataclass(slots=True)
class FindServersOnNetworkResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.3/#5.5.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: FindServersOnNetworkResult
    """

    data_type = NodeId(ObjectIds.FindServersOnNetworkResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.FindServersOnNetworkResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.FindServersOnNetworkResult' = field(default_factory=lambda: FindServersOnNetworkResult())


@dataclass(slots=True)
class UserTokenPolicy:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.41

    :ivar PolicyId:
    :vartype PolicyId: String
    :ivar TokenType:
    :vartype TokenType: UserTokenType
    :ivar IssuedTokenType:
    :vartype IssuedTokenType: String
    :ivar IssuerEndpointUrl:
    :vartype IssuerEndpointUrl: String
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    """

    data_type = NodeId(ObjectIds.UserTokenPolicy)

    PolicyId: 'ua.String' = None
    TokenType: 'ua.UserTokenType' = field(default_factory=lambda:UserTokenType.Anonymous)
    IssuedTokenType: 'ua.String' = None
    IssuerEndpointUrl: 'ua.String' = None
    SecurityPolicyUri: 'ua.String' = None


@dataclass(slots=True)
class PubSubKeyPushTargetDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.12/#6.2.12.3

    :ivar ApplicationUri:
    :vartype ApplicationUri: String
    :ivar PushTargetFolder:
    :vartype PushTargetFolder: String
    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    :ivar UserTokenType:
    :vartype UserTokenType: UserTokenPolicy
    :ivar RequestedKeyCount:
    :vartype RequestedKeyCount: UInt16
    :ivar RetryInterval:
    :vartype RetryInterval: Duration
    :ivar PushTargetProperties:
    :vartype PushTargetProperties: KeyValuePair
    :ivar SecurityGroups:
    :vartype SecurityGroups: String
    """

    data_type = NodeId(ObjectIds.PubSubKeyPushTargetDataType)

    ApplicationUri: 'ua.String' = None
    PushTargetFolder: 'list[ua.String]' = field(default_factory=list)
    EndpointUrl: 'ua.String' = None
    SecurityPolicyUri: 'ua.String' = None
    UserTokenType: 'ua.UserTokenPolicy' = field(default_factory=lambda: UserTokenPolicy())
    RequestedKeyCount: 'ua.UInt16' = 0
    RetryInterval: 'ua.Duration' = 0
    PushTargetProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    SecurityGroups: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class EndpointDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.14

    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar Server:
    :vartype Server: ApplicationDescription
    :ivar ServerCertificate:
    :vartype ServerCertificate: ApplicationInstanceCertificate
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    :ivar UserIdentityTokens:
    :vartype UserIdentityTokens: UserTokenPolicy
    :ivar TransportProfileUri:
    :vartype TransportProfileUri: String
    :ivar SecurityLevel:
    :vartype SecurityLevel: Byte
    """

    data_type = NodeId(ObjectIds.EndpointDescription)

    EndpointUrl: 'ua.String' = None
    Server: 'ua.ApplicationDescription' = field(default_factory=lambda: ApplicationDescription())
    ServerCertificate: 'ua.ApplicationInstanceCertificate' = None
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityPolicyUri: 'ua.String' = None
    UserIdentityTokens: 'list[ua.UserTokenPolicy]' = field(default_factory=list)
    TransportProfileUri: 'ua.String' = None
    SecurityLevel: 'ua.Byte' = 0


@dataclass(slots=True)
class PubSubGroupDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.5/#6.2.5.7

    :ivar Name:
    :vartype Name: String
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityGroupId:
    :vartype SecurityGroupId: String
    :ivar SecurityKeyServices:
    :vartype SecurityKeyServices: EndpointDescription
    :ivar MaxNetworkMessageSize:
    :vartype MaxNetworkMessageSize: UInt32
    :ivar GroupProperties:
    :vartype GroupProperties: KeyValuePair
    """

    data_type = NodeId(ObjectIds.PubSubGroupDataType)

    Name: 'ua.String' = None
    Enabled: 'ua.Boolean' = True
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityGroupId: 'ua.String' = None
    SecurityKeyServices: 'list[ua.EndpointDescription]' = field(default_factory=list)
    MaxNetworkMessageSize: 'ua.UInt32' = 0
    GroupProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class WriterGroupDataType(PubSubGroupDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.6/#6.2.6.7.1

    :ivar Name:
    :vartype Name: String
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityGroupId:
    :vartype SecurityGroupId: String
    :ivar SecurityKeyServices:
    :vartype SecurityKeyServices: EndpointDescription
    :ivar MaxNetworkMessageSize:
    :vartype MaxNetworkMessageSize: UInt32
    :ivar GroupProperties:
    :vartype GroupProperties: KeyValuePair
    :ivar WriterGroupId:
    :vartype WriterGroupId: UInt16
    :ivar PublishingInterval:
    :vartype PublishingInterval: Duration
    :ivar KeepAliveTime:
    :vartype KeepAliveTime: Duration
    :ivar Priority:
    :vartype Priority: Byte
    :ivar LocaleIds:
    :vartype LocaleIds: LocaleId
    :ivar HeaderLayoutUri:
    :vartype HeaderLayoutUri: String
    :ivar TransportSettings:
    :vartype TransportSettings: WriterGroupTransportDataType
    :ivar MessageSettings:
    :vartype MessageSettings: WriterGroupMessageDataType
    :ivar DataSetWriters:
    :vartype DataSetWriters: DataSetWriterDataType
    """

    data_type = NodeId(ObjectIds.WriterGroupDataType)

    Name: 'ua.String' = None
    Enabled: 'ua.Boolean' = True
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityGroupId: 'ua.String' = None
    SecurityKeyServices: 'list[ua.EndpointDescription]' = field(default_factory=list)
    MaxNetworkMessageSize: 'ua.UInt32' = 0
    GroupProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    WriterGroupId: 'ua.UInt16' = 0
    PublishingInterval: 'ua.Duration' = 0
    KeepAliveTime: 'ua.Duration' = 0
    Priority: 'ua.Byte' = 0
    LocaleIds: 'list[ua.LocaleId]' = field(default_factory=list)
    HeaderLayoutUri: 'ua.String' = None
    TransportSettings: 'type[ua.WriterGroupTransportDataType]' = field(default_factory=lambda: WriterGroupTransportDataType())
    MessageSettings: 'type[ua.WriterGroupMessageDataType]' = field(default_factory=lambda: WriterGroupMessageDataType())
    DataSetWriters: 'list[ua.DataSetWriterDataType]' = field(default_factory=list)


@dataclass(slots=True)
class DataSetReaderDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.9/#6.2.9.13.1

    :ivar Name:
    :vartype Name: String
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar PublisherId:
    :vartype PublisherId: Variant
    :ivar WriterGroupId:
    :vartype WriterGroupId: UInt16
    :ivar DataSetWriterId:
    :vartype DataSetWriterId: UInt16
    :ivar DataSetMetaData:
    :vartype DataSetMetaData: DataSetMetaDataType
    :ivar DataSetFieldContentMask:
    :vartype DataSetFieldContentMask: DataSetFieldContentMask
    :ivar MessageReceiveTimeout:
    :vartype MessageReceiveTimeout: Duration
    :ivar KeyFrameCount:
    :vartype KeyFrameCount: UInt32
    :ivar HeaderLayoutUri:
    :vartype HeaderLayoutUri: String
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityGroupId:
    :vartype SecurityGroupId: String
    :ivar SecurityKeyServices:
    :vartype SecurityKeyServices: EndpointDescription
    :ivar DataSetReaderProperties:
    :vartype DataSetReaderProperties: KeyValuePair
    :ivar TransportSettings:
    :vartype TransportSettings: DataSetReaderTransportDataType
    :ivar MessageSettings:
    :vartype MessageSettings: DataSetReaderMessageDataType
    :ivar SubscribedDataSet:
    :vartype SubscribedDataSet: SubscribedDataSetDataType
    """

    data_type = NodeId(ObjectIds.DataSetReaderDataType)

    Name: 'ua.String' = None
    Enabled: 'ua.Boolean' = True
    PublisherId: 'ua.Variant' = field(default_factory=lambda: Variant())
    WriterGroupId: 'ua.UInt16' = 0
    DataSetWriterId: 'ua.UInt16' = 0
    DataSetMetaData: 'ua.DataSetMetaDataType' = field(default_factory=lambda: DataSetMetaDataType())
    DataSetFieldContentMask: 'ua.DataSetFieldContentMask' = field(default_factory=lambda:DataSetFieldContentMask(0))
    MessageReceiveTimeout: 'ua.Duration' = 0
    KeyFrameCount: 'ua.UInt32' = 0
    HeaderLayoutUri: 'ua.String' = None
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityGroupId: 'ua.String' = None
    SecurityKeyServices: 'list[ua.EndpointDescription]' = field(default_factory=list)
    DataSetReaderProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    TransportSettings: 'type[ua.DataSetReaderTransportDataType]' = field(default_factory=lambda: DataSetReaderTransportDataType())
    MessageSettings: 'type[ua.DataSetReaderMessageDataType]' = field(default_factory=lambda: DataSetReaderMessageDataType())
    SubscribedDataSet: 'type[ua.SubscribedDataSetDataType]' = field(default_factory=lambda: SubscribedDataSetDataType())


@dataclass(slots=True)
class ReaderGroupDataType(PubSubGroupDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.8/#6.2.8.2.1

    :ivar Name:
    :vartype Name: String
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityGroupId:
    :vartype SecurityGroupId: String
    :ivar SecurityKeyServices:
    :vartype SecurityKeyServices: EndpointDescription
    :ivar MaxNetworkMessageSize:
    :vartype MaxNetworkMessageSize: UInt32
    :ivar GroupProperties:
    :vartype GroupProperties: KeyValuePair
    :ivar TransportSettings:
    :vartype TransportSettings: ReaderGroupTransportDataType
    :ivar MessageSettings:
    :vartype MessageSettings: ReaderGroupMessageDataType
    :ivar DataSetReaders:
    :vartype DataSetReaders: DataSetReaderDataType
    """

    data_type = NodeId(ObjectIds.ReaderGroupDataType)

    Name: 'ua.String' = None
    Enabled: 'ua.Boolean' = True
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityGroupId: 'ua.String' = None
    SecurityKeyServices: 'list[ua.EndpointDescription]' = field(default_factory=list)
    MaxNetworkMessageSize: 'ua.UInt32' = 0
    GroupProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    TransportSettings: 'type[ua.ReaderGroupTransportDataType]' = field(default_factory=lambda: ReaderGroupTransportDataType())
    MessageSettings: 'type[ua.ReaderGroupMessageDataType]' = field(default_factory=lambda: ReaderGroupMessageDataType())
    DataSetReaders: 'list[ua.DataSetReaderDataType]' = field(default_factory=list)


@dataclass(slots=True)
class PubSubConnectionDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.7/#6.2.7.5.1

    :ivar Name:
    :vartype Name: String
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar PublisherId:
    :vartype PublisherId: Variant
    :ivar TransportProfileUri:
    :vartype TransportProfileUri: String
    :ivar Address:
    :vartype Address: NetworkAddressDataType
    :ivar ConnectionProperties:
    :vartype ConnectionProperties: KeyValuePair
    :ivar TransportSettings:
    :vartype TransportSettings: ConnectionTransportDataType
    :ivar WriterGroups:
    :vartype WriterGroups: WriterGroupDataType
    :ivar ReaderGroups:
    :vartype ReaderGroups: ReaderGroupDataType
    """

    data_type = NodeId(ObjectIds.PubSubConnectionDataType)

    Name: 'ua.String' = None
    Enabled: 'ua.Boolean' = True
    PublisherId: 'ua.Variant' = field(default_factory=lambda: Variant())
    TransportProfileUri: 'ua.String' = None
    Address: 'type[ua.NetworkAddressDataType]' = field(default_factory=lambda: NetworkAddressDataType())
    ConnectionProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)
    TransportSettings: 'type[ua.ConnectionTransportDataType]' = field(default_factory=lambda: ConnectionTransportDataType())
    WriterGroups: 'list[ua.WriterGroupDataType]' = field(default_factory=list)
    ReaderGroups: 'list[ua.ReaderGroupDataType]' = field(default_factory=list)


@dataclass(slots=True)
class PubSubConfigurationDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.12/#6.2.12.1

    :ivar PublishedDataSets:
    :vartype PublishedDataSets: PublishedDataSetDataType
    :ivar Connections:
    :vartype Connections: PubSubConnectionDataType
    :ivar Enabled:
    :vartype Enabled: Boolean
    """

    data_type = NodeId(ObjectIds.PubSubConfigurationDataType)

    PublishedDataSets: 'list[ua.PublishedDataSetDataType]' = field(default_factory=list)
    Connections: 'list[ua.PubSubConnectionDataType]' = field(default_factory=list)
    Enabled: 'ua.Boolean' = True


@dataclass(slots=True)
class JsonPubSubConnectionMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar Connection:
    :vartype Connection: PubSubConnectionDataType
    """

    data_type = NodeId(ObjectIds.JsonPubSubConnectionMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Connection: 'ua.PubSubConnectionDataType' = field(default_factory=lambda: PubSubConnectionDataType())


@dataclass(slots=True)
class JsonActionResponderMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar Connection:
    :vartype Connection: PubSubConnectionDataType
    """

    data_type = NodeId(ObjectIds.JsonActionResponderMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Connection: 'ua.PubSubConnectionDataType' = field(default_factory=lambda: PubSubConnectionDataType())


@dataclass(slots=True)
class PubSubConfiguration2DataType(PubSubConfigurationDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.12/#6.2.12.4

    :ivar PublishedDataSets:
    :vartype PublishedDataSets: PublishedDataSetDataType
    :ivar Connections:
    :vartype Connections: PubSubConnectionDataType
    :ivar Enabled:
    :vartype Enabled: Boolean
    :ivar SubscribedDataSets:
    :vartype SubscribedDataSets: StandaloneSubscribedDataSetDataType
    :ivar DataSetClasses:
    :vartype DataSetClasses: DataSetMetaDataType
    :ivar DefaultSecurityKeyServices:
    :vartype DefaultSecurityKeyServices: EndpointDescription
    :ivar SecurityGroups:
    :vartype SecurityGroups: SecurityGroupDataType
    :ivar PubSubKeyPushTargets:
    :vartype PubSubKeyPushTargets: PubSubKeyPushTargetDataType
    :ivar ConfigurationVersion:
    :vartype ConfigurationVersion: VersionTime
    :ivar ConfigurationProperties:
    :vartype ConfigurationProperties: KeyValuePair
    """

    data_type = NodeId(ObjectIds.PubSubConfiguration2DataType)

    PublishedDataSets: 'list[ua.PublishedDataSetDataType]' = field(default_factory=list)
    Connections: 'list[ua.PubSubConnectionDataType]' = field(default_factory=list)
    Enabled: 'ua.Boolean' = True
    SubscribedDataSets: 'list[ua.StandaloneSubscribedDataSetDataType]' = field(default_factory=list)
    DataSetClasses: 'list[ua.DataSetMetaDataType]' = field(default_factory=list)
    DefaultSecurityKeyServices: 'list[ua.EndpointDescription]' = field(default_factory=list)
    SecurityGroups: 'list[ua.SecurityGroupDataType]' = field(default_factory=list)
    PubSubKeyPushTargets: 'list[ua.PubSubKeyPushTargetDataType]' = field(default_factory=list)
    ConfigurationVersion: 'ua.VersionTime' = 0
    ConfigurationProperties: 'list[ua.KeyValuePair]' = field(default_factory=list)


@dataclass(slots=True)
class JsonServerEndpointsMessage:
    """
    :ivar MessageId:
    :vartype MessageId: String
    :ivar MessageType:
    :vartype MessageType: String
    :ivar PublisherId:
    :vartype PublisherId: String
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar Description:
    :vartype Description: ApplicationDescription
    :ivar Endpoints:
    :vartype Endpoints: EndpointDescription
    """

    data_type = NodeId(ObjectIds.JsonServerEndpointsMessage)

    MessageId: 'ua.String' = None
    MessageType: 'ua.String' = None
    PublisherId: 'ua.String' = None
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Description: 'ua.ApplicationDescription' = field(default_factory=lambda: ApplicationDescription())
    Endpoints: 'list[ua.EndpointDescription]' = field(default_factory=list)


@dataclass(slots=True)
class GetEndpointsParameters:
    """
    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar LocaleIds:
    :vartype LocaleIds: LocaleId
    :ivar ProfileUris:
    :vartype ProfileUris: String
    """

    EndpointUrl: 'ua.String' = None
    LocaleIds: 'list[ua.LocaleId]' = field(default_factory=list)
    ProfileUris: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class GetEndpointsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.4/#5.5.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: GetEndpointsParameters
    """

    data_type = NodeId(ObjectIds.GetEndpointsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.GetEndpointsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.GetEndpointsParameters' = field(default_factory=lambda: GetEndpointsParameters())


@dataclass(slots=True)
class GetEndpointsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.4/#5.5.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Endpoints:
    :vartype Endpoints: EndpointDescription
    """

    data_type = NodeId(ObjectIds.GetEndpointsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.GetEndpointsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Endpoints: 'list[ua.EndpointDescription]' = field(default_factory=list)


@dataclass(slots=True)
class RegisteredServer:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.31

    :ivar ServerUri:
    :vartype ServerUri: String
    :ivar ProductUri:
    :vartype ProductUri: String
    :ivar ServerNames:
    :vartype ServerNames: LocalizedText
    :ivar ServerType:
    :vartype ServerType: ApplicationType
    :ivar GatewayServerUri:
    :vartype GatewayServerUri: String
    :ivar DiscoveryUrls:
    :vartype DiscoveryUrls: String
    :ivar SemaphoreFilePath:
    :vartype SemaphoreFilePath: String
    :ivar IsOnline:
    :vartype IsOnline: Boolean
    """

    data_type = NodeId(ObjectIds.RegisteredServer)

    ServerUri: 'ua.String' = None
    ProductUri: 'ua.String' = None
    ServerNames: 'list[ua.LocalizedText]' = field(default_factory=list)
    ServerType: 'ua.ApplicationType' = field(default_factory=lambda:ApplicationType.Server)
    GatewayServerUri: 'ua.String' = None
    DiscoveryUrls: 'list[ua.String]' = field(default_factory=list)
    SemaphoreFilePath: 'ua.String' = None
    IsOnline: 'ua.Boolean' = True


@dataclass(slots=True)
class RegisterServerRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.5/#5.5.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Server:
    :vartype Server: RegisteredServer
    """

    data_type = NodeId(ObjectIds.RegisterServerRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RegisterServerRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Server: 'ua.RegisteredServer' = field(default_factory=lambda: RegisteredServer())


@dataclass(slots=True)
class RegisterServerResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.5/#5.5.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    """

    data_type = NodeId(ObjectIds.RegisterServerResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RegisterServerResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())


@dataclass(slots=True)
class DiscoveryConfiguration:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.13.1

    """

    data_type = NodeId(ObjectIds.DiscoveryConfiguration)


@dataclass(slots=True)
class MdnsDiscoveryConfiguration(DiscoveryConfiguration):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.13.2

    :ivar MdnsServerName:
    :vartype MdnsServerName: String
    :ivar ServerCapabilities:
    :vartype ServerCapabilities: String
    """

    data_type = NodeId(ObjectIds.MdnsDiscoveryConfiguration)

    MdnsServerName: 'ua.String' = None
    ServerCapabilities: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class RegisterServer2Parameters:
    """
    :ivar Server:
    :vartype Server: RegisteredServer
    :ivar DiscoveryConfiguration:
    :vartype DiscoveryConfiguration: ExtensionObject
    """

    Server: 'ua.RegisteredServer' = field(default_factory=lambda: RegisteredServer())
    DiscoveryConfiguration: 'list[ua.ExtensionObject]' = field(default_factory=list)


@dataclass(slots=True)
class RegisterServer2Request:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.6/#5.5.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: RegisterServer2Parameters
    """

    data_type = NodeId(ObjectIds.RegisterServer2Request)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RegisterServer2Request_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.RegisterServer2Parameters' = field(default_factory=lambda: RegisterServer2Parameters())


@dataclass(slots=True)
class RegisterServer2Response:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.5.6/#5.5.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar ConfigurationResults:
    :vartype ConfigurationResults: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.RegisterServer2Response)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RegisterServer2Response_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    ConfigurationResults: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class ChannelSecurityToken:
    """
    :ivar ChannelId:
    :vartype ChannelId: UInt32
    :ivar TokenId:
    :vartype TokenId: UInt32
    :ivar CreatedAt:
    :vartype CreatedAt: UtcTime
    :ivar RevisedLifetime:
    :vartype RevisedLifetime: UInt32
    """

    data_type = NodeId(ObjectIds.ChannelSecurityToken)

    ChannelId: 'ua.UInt32' = 0
    TokenId: 'ua.UInt32' = 0
    CreatedAt: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    RevisedLifetime: 'ua.UInt32' = 0


@dataclass(slots=True)
class OpenSecureChannelParameters:
    """
    :ivar ClientProtocolVersion:
    :vartype ClientProtocolVersion: UInt32
    :ivar RequestType:
    :vartype RequestType: SecurityTokenRequestType
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar ClientNonce:
    :vartype ClientNonce: ByteString
    :ivar RequestedLifetime:
    :vartype RequestedLifetime: UInt32
    """

    ClientProtocolVersion: 'ua.UInt32' = 0
    RequestType: 'ua.SecurityTokenRequestType' = field(default_factory=lambda:SecurityTokenRequestType.Issue)
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    ClientNonce: 'ua.ByteString' = None
    RequestedLifetime: 'ua.UInt32' = 0


@dataclass(slots=True)
class OpenSecureChannelRequest:
    """
    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: OpenSecureChannelParameters
    """

    data_type = NodeId(ObjectIds.OpenSecureChannelRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.OpenSecureChannelRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.OpenSecureChannelParameters' = field(default_factory=lambda: OpenSecureChannelParameters())


@dataclass(slots=True)
class OpenSecureChannelResult:
    """
    :ivar ServerProtocolVersion:
    :vartype ServerProtocolVersion: UInt32
    :ivar SecurityToken:
    :vartype SecurityToken: ChannelSecurityToken
    :ivar ServerNonce:
    :vartype ServerNonce: ByteString
    """

    ServerProtocolVersion: 'ua.UInt32' = 0
    SecurityToken: 'ua.ChannelSecurityToken' = field(default_factory=lambda: ChannelSecurityToken())
    ServerNonce: 'ua.ByteString' = None


@dataclass(slots=True)
class OpenSecureChannelResponse:
    """
    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: OpenSecureChannelResult
    """

    data_type = NodeId(ObjectIds.OpenSecureChannelResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.OpenSecureChannelResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.OpenSecureChannelResult' = field(default_factory=lambda: OpenSecureChannelResult())


@dataclass(slots=True)
class CloseSecureChannelRequest:
    """
    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    """

    data_type = NodeId(ObjectIds.CloseSecureChannelRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CloseSecureChannelRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())


@dataclass(slots=True)
class CloseSecureChannelResponse:
    """
    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    """

    data_type = NodeId(ObjectIds.CloseSecureChannelResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CloseSecureChannelResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())


@dataclass(slots=True)
class SignedSoftwareCertificate:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.37

    :ivar CertificateData:
    :vartype CertificateData: ByteString
    :ivar Signature:
    :vartype Signature: ByteString
    """

    data_type = NodeId(ObjectIds.SignedSoftwareCertificate)

    CertificateData: 'ua.ByteString' = None
    Signature: 'ua.ByteString' = None


@dataclass(slots=True)
class SignatureData:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.36

    :ivar Algorithm:
    :vartype Algorithm: String
    :ivar Signature:
    :vartype Signature: ByteString
    """

    data_type = NodeId(ObjectIds.SignatureData)

    Algorithm: 'ua.String' = None
    Signature: 'ua.ByteString' = None


@dataclass(slots=True)
class CreateSessionParameters:
    """
    :ivar ClientDescription:
    :vartype ClientDescription: ApplicationDescription
    :ivar ServerUri:
    :vartype ServerUri: String
    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar SessionName:
    :vartype SessionName: String
    :ivar ClientNonce:
    :vartype ClientNonce: ByteString
    :ivar ClientCertificate:
    :vartype ClientCertificate: ApplicationInstanceCertificate
    :ivar RequestedSessionTimeout:
    :vartype RequestedSessionTimeout: Duration
    :ivar MaxResponseMessageSize:
    :vartype MaxResponseMessageSize: UInt32
    """

    ClientDescription: 'ua.ApplicationDescription' = field(default_factory=lambda: ApplicationDescription())
    ServerUri: 'ua.String' = None
    EndpointUrl: 'ua.String' = None
    SessionName: 'ua.String' = None
    ClientNonce: 'ua.ByteString' = None
    ClientCertificate: 'ua.ApplicationInstanceCertificate' = None
    RequestedSessionTimeout: 'ua.Duration' = 0
    MaxResponseMessageSize: 'ua.UInt32' = 0


@dataclass(slots=True)
class CreateSessionRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.2/#5.7.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: CreateSessionParameters
    """

    data_type = NodeId(ObjectIds.CreateSessionRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CreateSessionRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.CreateSessionParameters' = field(default_factory=lambda: CreateSessionParameters())


@dataclass(slots=True)
class CreateSessionResult:
    """
    :ivar SessionId:
    :vartype SessionId: NodeId
    :ivar AuthenticationToken:
    :vartype AuthenticationToken: SessionAuthenticationToken
    :ivar RevisedSessionTimeout:
    :vartype RevisedSessionTimeout: Duration
    :ivar ServerNonce:
    :vartype ServerNonce: ByteString
    :ivar ServerCertificate:
    :vartype ServerCertificate: ApplicationInstanceCertificate
    :ivar ServerEndpoints:
    :vartype ServerEndpoints: EndpointDescription
    :ivar ServerSoftwareCertificates:
    :vartype ServerSoftwareCertificates: SignedSoftwareCertificate
    :ivar ServerSignature:
    :vartype ServerSignature: SignatureData
    :ivar MaxRequestMessageSize:
    :vartype MaxRequestMessageSize: UInt32
    """

    SessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AuthenticationToken: 'ua.SessionAuthenticationToken' = field(default_factory=lambda: NodeId())
    RevisedSessionTimeout: 'ua.Duration' = 0
    ServerNonce: 'ua.ByteString' = None
    ServerCertificate: 'ua.ApplicationInstanceCertificate' = None
    ServerEndpoints: 'list[ua.EndpointDescription]' = field(default_factory=list)
    ServerSoftwareCertificates: 'list[ua.SignedSoftwareCertificate]' = field(default_factory=list)
    ServerSignature: 'ua.SignatureData' = field(default_factory=lambda: SignatureData())
    MaxRequestMessageSize: 'ua.UInt32' = 0


@dataclass(slots=True)
class CreateSessionResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.2/#5.7.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: CreateSessionResult
    """

    data_type = NodeId(ObjectIds.CreateSessionResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CreateSessionResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.CreateSessionResult' = field(default_factory=lambda: CreateSessionResult())


@dataclass(slots=True)
class UserIdentityToken:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.40.1

    :ivar PolicyId:
    :vartype PolicyId: String
    """

    data_type = NodeId(ObjectIds.UserIdentityToken)

    PolicyId: 'ua.String' = None


@dataclass(slots=True)
class AnonymousIdentityToken(UserIdentityToken):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.40.3

    :ivar PolicyId:
    :vartype PolicyId: String
    """

    data_type = NodeId(ObjectIds.AnonymousIdentityToken)

    PolicyId: 'ua.String' = None


@dataclass(slots=True)
class UserNameIdentityToken(UserIdentityToken):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.40.4

    :ivar PolicyId:
    :vartype PolicyId: String
    :ivar UserName:
    :vartype UserName: String
    :ivar Password:
    :vartype Password: ByteString
    :ivar EncryptionAlgorithm:
    :vartype EncryptionAlgorithm: String
    """

    data_type = NodeId(ObjectIds.UserNameIdentityToken)

    PolicyId: 'ua.String' = None
    UserName: 'ua.String' = None
    Password: 'ua.ByteString' = None
    EncryptionAlgorithm: 'ua.String' = None


@dataclass(slots=True)
class X509IdentityToken(UserIdentityToken):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.40.5

    :ivar PolicyId:
    :vartype PolicyId: String
    :ivar CertificateData:
    :vartype CertificateData: ByteString
    """

    data_type = NodeId(ObjectIds.X509IdentityToken)

    PolicyId: 'ua.String' = None
    CertificateData: 'ua.ByteString' = None


@dataclass(slots=True)
class IssuedIdentityToken(UserIdentityToken):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.40.6

    :ivar PolicyId:
    :vartype PolicyId: String
    :ivar TokenData:
    :vartype TokenData: ByteString
    :ivar EncryptionAlgorithm:
    :vartype EncryptionAlgorithm: String
    """

    data_type = NodeId(ObjectIds.IssuedIdentityToken)

    PolicyId: 'ua.String' = None
    TokenData: 'ua.ByteString' = None
    EncryptionAlgorithm: 'ua.String' = None


@dataclass(slots=True)
class ActivateSessionParameters:
    """
    :ivar ClientSignature:
    :vartype ClientSignature: SignatureData
    :ivar ClientSoftwareCertificates:
    :vartype ClientSoftwareCertificates: SignedSoftwareCertificate
    :ivar LocaleIds:
    :vartype LocaleIds: LocaleId
    :ivar UserIdentityToken:
    :vartype UserIdentityToken: ExtensionObject
    :ivar UserTokenSignature:
    :vartype UserTokenSignature: SignatureData
    """

    ClientSignature: 'ua.SignatureData' = field(default_factory=lambda: SignatureData())
    ClientSoftwareCertificates: 'list[ua.SignedSoftwareCertificate]' = field(default_factory=list)
    LocaleIds: 'list[ua.LocaleId]' = field(default_factory=list)
    UserIdentityToken: 'ua.ExtensionObject' = ExtensionObject()
    UserTokenSignature: 'ua.SignatureData' = field(default_factory=lambda: SignatureData())


@dataclass(slots=True)
class ActivateSessionRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.3/#5.7.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: ActivateSessionParameters
    """

    data_type = NodeId(ObjectIds.ActivateSessionRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ActivateSessionRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.ActivateSessionParameters' = field(default_factory=lambda: ActivateSessionParameters())


@dataclass(slots=True)
class ActivateSessionResult:
    """
    :ivar ServerNonce:
    :vartype ServerNonce: ByteString
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    ServerNonce: 'ua.ByteString' = None
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class ActivateSessionResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.3/#5.7.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: ActivateSessionResult
    """

    data_type = NodeId(ObjectIds.ActivateSessionResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ActivateSessionResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.ActivateSessionResult' = field(default_factory=lambda: ActivateSessionResult())


@dataclass(slots=True)
class CloseSessionRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.4/#5.7.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar DeleteSubscriptions:
    :vartype DeleteSubscriptions: Boolean
    """

    data_type = NodeId(ObjectIds.CloseSessionRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CloseSessionRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    DeleteSubscriptions: 'ua.Boolean' = True


@dataclass(slots=True)
class CloseSessionResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.4/#5.7.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    """

    data_type = NodeId(ObjectIds.CloseSessionResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CloseSessionResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())


@dataclass(slots=True)
class CancelParameters:
    """
    :ivar RequestHandle:
    :vartype RequestHandle: IntegerId
    """

    RequestHandle: 'ua.IntegerId' = 0


@dataclass(slots=True)
class CancelRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.5/#5.7.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: CancelParameters
    """

    data_type = NodeId(ObjectIds.CancelRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CancelRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.CancelParameters' = field(default_factory=lambda: CancelParameters())


@dataclass(slots=True)
class CancelResult:
    """
    :ivar CancelCount:
    :vartype CancelCount: UInt32
    """

    CancelCount: 'ua.UInt32' = 0


@dataclass(slots=True)
class CancelResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.7.5/#5.7.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: CancelResult
    """

    data_type = NodeId(ObjectIds.CancelResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CancelResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.CancelResult' = field(default_factory=lambda: CancelResult())


@dataclass(slots=True)
class NodeAttributes:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.1

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    """

    data_type = NodeId(ObjectIds.NodeAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0


@dataclass(slots=True)
class ObjectAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.2

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar EventNotifier:
    :vartype EventNotifier: Byte
    """

    data_type = NodeId(ObjectIds.ObjectAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    EventNotifier: 'ua.Byte' = 0


@dataclass(slots=True)
class VariableAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.3

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar Value:
    :vartype Value: Variant
    :ivar DataType:
    :vartype DataType: NodeId
    :ivar ValueRank:
    :vartype ValueRank: Int32
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: UInt32
    :ivar AccessLevel:
    :vartype AccessLevel: Byte
    :ivar UserAccessLevel:
    :vartype UserAccessLevel: Byte
    :ivar MinimumSamplingInterval:
    :vartype MinimumSamplingInterval: Duration
    :ivar Historizing:
    :vartype Historizing: Boolean
    """

    data_type = NodeId(ObjectIds.VariableAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    Value: 'ua.Variant' = field(default_factory=lambda: Variant())
    DataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ValueRank: 'ua.Int32' = 0
    ArrayDimensions: 'list[ua.UInt32]' = field(default_factory=list)
    AccessLevel: 'ua.Byte' = 0
    UserAccessLevel: 'ua.Byte' = 0
    MinimumSamplingInterval: 'ua.Duration' = 0
    Historizing: 'ua.Boolean' = True


@dataclass(slots=True)
class MethodAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.4

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar Executable:
    :vartype Executable: Boolean
    :ivar UserExecutable:
    :vartype UserExecutable: Boolean
    """

    data_type = NodeId(ObjectIds.MethodAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    Executable: 'ua.Boolean' = True
    UserExecutable: 'ua.Boolean' = True


@dataclass(slots=True)
class ObjectTypeAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.5

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar IsAbstract:
    :vartype IsAbstract: Boolean
    """

    data_type = NodeId(ObjectIds.ObjectTypeAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    IsAbstract: 'ua.Boolean' = True


@dataclass(slots=True)
class VariableTypeAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.6

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar Value:
    :vartype Value: Variant
    :ivar DataType:
    :vartype DataType: NodeId
    :ivar ValueRank:
    :vartype ValueRank: Int32
    :ivar ArrayDimensions:
    :vartype ArrayDimensions: UInt32
    :ivar IsAbstract:
    :vartype IsAbstract: Boolean
    """

    data_type = NodeId(ObjectIds.VariableTypeAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    Value: 'ua.Variant' = field(default_factory=lambda: Variant())
    DataType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ValueRank: 'ua.Int32' = 0
    ArrayDimensions: 'list[ua.UInt32]' = field(default_factory=list)
    IsAbstract: 'ua.Boolean' = True


@dataclass(slots=True)
class ReferenceTypeAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.7

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar IsAbstract:
    :vartype IsAbstract: Boolean
    :ivar Symmetric:
    :vartype Symmetric: Boolean
    :ivar InverseName:
    :vartype InverseName: LocalizedText
    """

    data_type = NodeId(ObjectIds.ReferenceTypeAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    IsAbstract: 'ua.Boolean' = True
    Symmetric: 'ua.Boolean' = True
    InverseName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class DataTypeAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.8

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar IsAbstract:
    :vartype IsAbstract: Boolean
    """

    data_type = NodeId(ObjectIds.DataTypeAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    IsAbstract: 'ua.Boolean' = True


@dataclass(slots=True)
class ViewAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.9

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar ContainsNoLoops:
    :vartype ContainsNoLoops: Boolean
    :ivar EventNotifier:
    :vartype EventNotifier: Byte
    """

    data_type = NodeId(ObjectIds.ViewAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    ContainsNoLoops: 'ua.Boolean' = True
    EventNotifier: 'ua.Byte' = 0


@dataclass(slots=True)
class GenericAttributeValue:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.10

    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar Value:
    :vartype Value: Variant
    """

    data_type = NodeId(ObjectIds.GenericAttributeValue)

    AttributeId: 'ua.IntegerId' = 0
    Value: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class GenericAttributes(NodeAttributes):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.24.10

    :ivar SpecifiedAttributes:
    :vartype SpecifiedAttributes: UInt32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    :ivar WriteMask:
    :vartype WriteMask: UInt32
    :ivar UserWriteMask:
    :vartype UserWriteMask: UInt32
    :ivar AttributeValues:
    :vartype AttributeValues: GenericAttributeValue
    """

    data_type = NodeId(ObjectIds.GenericAttributes)

    SpecifiedAttributes: 'ua.UInt32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    WriteMask: 'ua.UInt32' = 0
    UserWriteMask: 'ua.UInt32' = 0
    AttributeValues: 'list[ua.GenericAttributeValue]' = field(default_factory=list)


@dataclass(slots=True)
class AddNodesItem:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.2/#5.8.2.2

    :ivar ParentNodeId:
    :vartype ParentNodeId: ExpandedNodeId
    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: NodeId
    :ivar RequestedNewNodeId:
    :vartype RequestedNewNodeId: ExpandedNodeId
    :ivar BrowseName:
    :vartype BrowseName: QualifiedName
    :ivar NodeClass:
    :vartype NodeClass: NodeClass
    :ivar NodeAttributes:
    :vartype NodeAttributes: ExtensionObject
    :ivar TypeDefinition:
    :vartype TypeDefinition: ExpandedNodeId
    """

    data_type = NodeId(ObjectIds.AddNodesItem)

    ParentNodeId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    ReferenceTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    RequestedNewNodeId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    BrowseName: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    NodeClass: 'ua.NodeClass' = field(default_factory=lambda:NodeClass.Unspecified)
    NodeAttributes: 'ua.ExtensionObject' = ExtensionObject()
    TypeDefinition: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())


@dataclass(slots=True)
class AddNodesResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.2/#5.8.2.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar AddedNodeId:
    :vartype AddedNodeId: NodeId
    """

    data_type = NodeId(ObjectIds.AddNodesResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    AddedNodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())


@dataclass(slots=True)
class AddNodesParameters:
    """
    :ivar NodesToAdd:
    :vartype NodesToAdd: AddNodesItem
    """

    NodesToAdd: 'list[ua.AddNodesItem]' = field(default_factory=list)


@dataclass(slots=True)
class AddNodesRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.2/#5.8.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: AddNodesParameters
    """

    data_type = NodeId(ObjectIds.AddNodesRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.AddNodesRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.AddNodesParameters' = field(default_factory=lambda: AddNodesParameters())


@dataclass(slots=True)
class AddNodesResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.2/#5.8.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: AddNodesResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.AddNodesResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.AddNodesResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.AddNodesResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class AddReferencesItem:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.3/#5.8.3.2

    :ivar SourceNodeId:
    :vartype SourceNodeId: NodeId
    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: NodeId
    :ivar IsForward:
    :vartype IsForward: Boolean
    :ivar TargetServerUri:
    :vartype TargetServerUri: String
    :ivar TargetNodeId:
    :vartype TargetNodeId: ExpandedNodeId
    :ivar TargetNodeClass:
    :vartype TargetNodeClass: NodeClass
    """

    data_type = NodeId(ObjectIds.AddReferencesItem)

    SourceNodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ReferenceTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsForward: 'ua.Boolean' = True
    TargetServerUri: 'ua.String' = None
    TargetNodeId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    TargetNodeClass: 'ua.NodeClass' = field(default_factory=lambda:NodeClass.Unspecified)


@dataclass(slots=True)
class AddReferencesParameters:
    """
    :ivar ReferencesToAdd:
    :vartype ReferencesToAdd: AddReferencesItem
    """

    ReferencesToAdd: 'list[ua.AddReferencesItem]' = field(default_factory=list)


@dataclass(slots=True)
class AddReferencesRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.3/#5.8.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: AddReferencesParameters
    """

    data_type = NodeId(ObjectIds.AddReferencesRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.AddReferencesRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.AddReferencesParameters' = field(default_factory=lambda: AddReferencesParameters())


@dataclass(slots=True)
class AddReferencesResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.3/#5.8.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.AddReferencesResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.AddReferencesResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteNodesItem:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.4/#5.8.4.2

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar DeleteTargetReferences:
    :vartype DeleteTargetReferences: Boolean
    """

    data_type = NodeId(ObjectIds.DeleteNodesItem)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    DeleteTargetReferences: 'ua.Boolean' = True


@dataclass(slots=True)
class DeleteNodesParameters:
    """
    :ivar NodesToDelete:
    :vartype NodesToDelete: DeleteNodesItem
    """

    NodesToDelete: 'list[ua.DeleteNodesItem]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteNodesRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.4/#5.8.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: DeleteNodesParameters
    """

    data_type = NodeId(ObjectIds.DeleteNodesRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteNodesRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.DeleteNodesParameters' = field(default_factory=lambda: DeleteNodesParameters())


@dataclass(slots=True)
class DeleteNodesResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.4/#5.8.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.DeleteNodesResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteNodesResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteReferencesItem:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.5/#5.8.5.1

    :ivar SourceNodeId:
    :vartype SourceNodeId: NodeId
    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: NodeId
    :ivar IsForward:
    :vartype IsForward: Boolean
    :ivar TargetNodeId:
    :vartype TargetNodeId: ExpandedNodeId
    :ivar DeleteBidirectional:
    :vartype DeleteBidirectional: Boolean
    """

    data_type = NodeId(ObjectIds.DeleteReferencesItem)

    SourceNodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ReferenceTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsForward: 'ua.Boolean' = True
    TargetNodeId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    DeleteBidirectional: 'ua.Boolean' = True


@dataclass(slots=True)
class DeleteReferencesParameters:
    """
    :ivar ReferencesToDelete:
    :vartype ReferencesToDelete: DeleteReferencesItem
    """

    ReferencesToDelete: 'list[ua.DeleteReferencesItem]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteReferencesRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.5/#5.8.5.1

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: DeleteReferencesParameters
    """

    data_type = NodeId(ObjectIds.DeleteReferencesRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteReferencesRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.DeleteReferencesParameters' = field(default_factory=lambda: DeleteReferencesParameters())


@dataclass(slots=True)
class DeleteReferencesResult:
    """
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteReferencesResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.8.5/#5.8.5.1

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: DeleteReferencesResult
    """

    data_type = NodeId(ObjectIds.DeleteReferencesResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteReferencesResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.DeleteReferencesResult' = field(default_factory=lambda: DeleteReferencesResult())


@dataclass(slots=True)
class ViewDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.44

    :ivar ViewId:
    :vartype ViewId: NodeId
    :ivar Timestamp:
    :vartype Timestamp: UtcTime
    :ivar ViewVersion:
    :vartype ViewVersion: UInt32
    """

    data_type = NodeId(ObjectIds.ViewDescription)

    ViewId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Timestamp: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    ViewVersion: 'ua.UInt32' = 0


@dataclass(slots=True)
class BrowseDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.2/#5.9.2.2

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar BrowseDirection:
    :vartype BrowseDirection: BrowseDirection
    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: NodeId
    :ivar IncludeSubtypes:
    :vartype IncludeSubtypes: Boolean
    :ivar NodeClassMask:
    :vartype NodeClassMask: UInt32
    :ivar ResultMask:
    :vartype ResultMask: UInt32
    """

    data_type = NodeId(ObjectIds.BrowseDescription)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    BrowseDirection: 'ua.BrowseDirection' = field(default_factory=lambda:BrowseDirection.Forward)
    ReferenceTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IncludeSubtypes: 'ua.Boolean' = True
    NodeClassMask: 'ua.UInt32' = 0
    ResultMask: 'ua.UInt32' = 0


@dataclass(slots=True)
class ReferenceDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.29

    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: NodeId
    :ivar IsForward:
    :vartype IsForward: Boolean
    :ivar NodeId:
    :vartype NodeId: ExpandedNodeId
    :ivar BrowseName:
    :vartype BrowseName: QualifiedName
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar NodeClass:
    :vartype NodeClass: NodeClass
    :ivar TypeDefinition:
    :vartype TypeDefinition: ExpandedNodeId
    """

    data_type = NodeId(ObjectIds.ReferenceDescription)

    ReferenceTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsForward: 'ua.Boolean' = True
    NodeId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    BrowseName: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    NodeClass: 'ua.NodeClass' = field(default_factory=lambda:NodeClass.Unspecified)
    TypeDefinition: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())


@dataclass(slots=True)
class BrowseResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.6

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar ContinuationPoint:
    :vartype ContinuationPoint: ContinuationPoint
    :ivar References:
    :vartype References: ReferenceDescription
    """

    data_type = NodeId(ObjectIds.BrowseResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    ContinuationPoint: 'ua.ContinuationPoint' = None
    References: 'list[ua.ReferenceDescription]' = field(default_factory=list)


@dataclass(slots=True)
class BrowseParameters:
    """
    :ivar View:
    :vartype View: ViewDescription
    :ivar RequestedMaxReferencesPerNode:
    :vartype RequestedMaxReferencesPerNode: Counter
    :ivar NodesToBrowse:
    :vartype NodesToBrowse: BrowseDescription
    """

    View: 'ua.ViewDescription' = field(default_factory=lambda: ViewDescription())
    RequestedMaxReferencesPerNode: 'ua.Counter' = 0
    NodesToBrowse: 'list[ua.BrowseDescription]' = field(default_factory=list)


@dataclass(slots=True)
class BrowseRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.2/#5.9.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: BrowseParameters
    """

    data_type = NodeId(ObjectIds.BrowseRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.BrowseRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.BrowseParameters' = field(default_factory=lambda: BrowseParameters())


@dataclass(slots=True)
class BrowseResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.2/#5.9.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: BrowseResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.BrowseResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.BrowseResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.BrowseResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class BrowseNextParameters:
    """
    :ivar ReleaseContinuationPoints:
    :vartype ReleaseContinuationPoints: Boolean
    :ivar ContinuationPoints:
    :vartype ContinuationPoints: ContinuationPoint
    """

    ReleaseContinuationPoints: 'ua.Boolean' = True
    ContinuationPoints: 'list[ua.ContinuationPoint]' = field(default_factory=list)


@dataclass(slots=True)
class BrowseNextRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.3/#5.9.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: BrowseNextParameters
    """

    data_type = NodeId(ObjectIds.BrowseNextRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.BrowseNextRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.BrowseNextParameters' = field(default_factory=lambda: BrowseNextParameters())


@dataclass(slots=True)
class BrowseNextResult:
    """
    :ivar Results:
    :vartype Results: BrowseResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    Results: 'list[ua.BrowseResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class BrowseNextResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.3/#5.9.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: BrowseNextResult
    """

    data_type = NodeId(ObjectIds.BrowseNextResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.BrowseNextResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.BrowseNextResult' = field(default_factory=lambda: BrowseNextResult())


@dataclass(slots=True)
class BrowsePath:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.4/#5.9.4.2

    :ivar StartingNode:
    :vartype StartingNode: NodeId
    :ivar RelativePath:
    :vartype RelativePath: RelativePath
    """

    data_type = NodeId(ObjectIds.BrowsePath)

    StartingNode: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    RelativePath: 'ua.RelativePath' = field(default_factory=lambda: RelativePath())


@dataclass(slots=True)
class BrowsePathTarget:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.4/#5.9.4.2

    :ivar TargetId:
    :vartype TargetId: ExpandedNodeId
    :ivar RemainingPathIndex:
    :vartype RemainingPathIndex: Index
    """

    data_type = NodeId(ObjectIds.BrowsePathTarget)

    TargetId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    RemainingPathIndex: 'ua.Index' = 0


@dataclass(slots=True)
class BrowsePathResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.4/#5.9.4.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar Targets:
    :vartype Targets: BrowsePathTarget
    """

    data_type = NodeId(ObjectIds.BrowsePathResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    Targets: 'list[ua.BrowsePathTarget]' = field(default_factory=list)


@dataclass(slots=True)
class TranslateBrowsePathsToNodeIdsParameters:
    """
    :ivar BrowsePaths:
    :vartype BrowsePaths: BrowsePath
    """

    BrowsePaths: 'list[ua.BrowsePath]' = field(default_factory=list)


@dataclass(slots=True)
class TranslateBrowsePathsToNodeIdsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.4/#5.9.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: TranslateBrowsePathsToNodeIdsParameters
    """

    data_type = NodeId(ObjectIds.TranslateBrowsePathsToNodeIdsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.TranslateBrowsePathsToNodeIdsParameters' = field(default_factory=lambda: TranslateBrowsePathsToNodeIdsParameters())


@dataclass(slots=True)
class TranslateBrowsePathsToNodeIdsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.4/#5.9.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: BrowsePathResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.TranslateBrowsePathsToNodeIdsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.BrowsePathResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class RegisterNodesParameters:
    """
    :ivar NodesToRegister:
    :vartype NodesToRegister: NodeId
    """

    NodesToRegister: 'list[ua.NodeId]' = field(default_factory=list)


@dataclass(slots=True)
class RegisterNodesRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.5/#5.9.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: RegisterNodesParameters
    """

    data_type = NodeId(ObjectIds.RegisterNodesRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RegisterNodesRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.RegisterNodesParameters' = field(default_factory=lambda: RegisterNodesParameters())


@dataclass(slots=True)
class RegisterNodesResult:
    """
    :ivar RegisteredNodeIds:
    :vartype RegisteredNodeIds: NodeId
    """

    RegisteredNodeIds: 'list[ua.NodeId]' = field(default_factory=list)


@dataclass(slots=True)
class RegisterNodesResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.5/#5.9.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: RegisterNodesResult
    """

    data_type = NodeId(ObjectIds.RegisterNodesResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RegisterNodesResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.RegisterNodesResult' = field(default_factory=lambda: RegisterNodesResult())


@dataclass(slots=True)
class UnregisterNodesParameters:
    """
    :ivar NodesToUnregister:
    :vartype NodesToUnregister: NodeId
    """

    NodesToUnregister: 'list[ua.NodeId]' = field(default_factory=list)


@dataclass(slots=True)
class UnregisterNodesRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.6/#5.9.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: UnregisterNodesParameters
    """

    data_type = NodeId(ObjectIds.UnregisterNodesRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.UnregisterNodesRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.UnregisterNodesParameters' = field(default_factory=lambda: UnregisterNodesParameters())


@dataclass(slots=True)
class UnregisterNodesResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.9.6/#5.9.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    """

    data_type = NodeId(ObjectIds.UnregisterNodesResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.UnregisterNodesResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())


@dataclass(slots=True)
class EndpointConfiguration:
    """
    :ivar OperationTimeout:
    :vartype OperationTimeout: Int32
    :ivar UseBinaryEncoding:
    :vartype UseBinaryEncoding: Boolean
    :ivar MaxStringLength:
    :vartype MaxStringLength: Int32
    :ivar MaxByteStringLength:
    :vartype MaxByteStringLength: Int32
    :ivar MaxArrayLength:
    :vartype MaxArrayLength: Int32
    :ivar MaxMessageSize:
    :vartype MaxMessageSize: Int32
    :ivar MaxBufferSize:
    :vartype MaxBufferSize: Int32
    :ivar ChannelLifetime:
    :vartype ChannelLifetime: Int32
    :ivar SecurityTokenLifetime:
    :vartype SecurityTokenLifetime: Int32
    """

    data_type = NodeId(ObjectIds.EndpointConfiguration)

    OperationTimeout: 'ua.Int32' = 0
    UseBinaryEncoding: 'ua.Boolean' = True
    MaxStringLength: 'ua.Int32' = 0
    MaxByteStringLength: 'ua.Int32' = 0
    MaxArrayLength: 'ua.Int32' = 0
    MaxMessageSize: 'ua.Int32' = 0
    MaxBufferSize: 'ua.Int32' = 0
    ChannelLifetime: 'ua.Int32' = 0
    SecurityTokenLifetime: 'ua.Int32' = 0


@dataclass(slots=True)
class QueryDataDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.3/#5.10.3.1

    :ivar RelativePath:
    :vartype RelativePath: RelativePath
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    """

    data_type = NodeId(ObjectIds.QueryDataDescription)

    RelativePath: 'ua.RelativePath' = field(default_factory=lambda: RelativePath())
    AttributeId: 'ua.IntegerId' = 0
    IndexRange: 'ua.NumericRange' = None


@dataclass(slots=True)
class NodeTypeDescription:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.3/#5.10.3.1

    :ivar TypeDefinitionNode:
    :vartype TypeDefinitionNode: ExpandedNodeId
    :ivar IncludeSubTypes:
    :vartype IncludeSubTypes: Boolean
    :ivar DataToReturn:
    :vartype DataToReturn: QueryDataDescription
    """

    data_type = NodeId(ObjectIds.NodeTypeDescription)

    TypeDefinitionNode: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    IncludeSubTypes: 'ua.Boolean' = True
    DataToReturn: 'list[ua.QueryDataDescription]' = field(default_factory=list)


@dataclass(slots=True)
class QueryDataSet:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/B.2.5

    :ivar NodeId:
    :vartype NodeId: ExpandedNodeId
    :ivar TypeDefinitionNode:
    :vartype TypeDefinitionNode: ExpandedNodeId
    :ivar Values:
    :vartype Values: Variant
    """

    data_type = NodeId(ObjectIds.QueryDataSet)

    NodeId: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    TypeDefinitionNode: 'ua.ExpandedNodeId' = field(default_factory=lambda: ExpandedNodeId())
    Values: 'list[ua.Variant]' = field(default_factory=list)


@dataclass(slots=True)
class NodeReference:
    """
    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar ReferenceTypeId:
    :vartype ReferenceTypeId: NodeId
    :ivar IsForward:
    :vartype IsForward: Boolean
    :ivar ReferencedNodeIds:
    :vartype ReferencedNodeIds: NodeId
    """

    data_type = NodeId(ObjectIds.NodeReference)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ReferenceTypeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsForward: 'ua.Boolean' = True
    ReferencedNodeIds: 'list[ua.NodeId]' = field(default_factory=list)


@dataclass(slots=True)
class ContentFilterElement:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.1

    :ivar FilterOperator:
    :vartype FilterOperator: FilterOperator
    :ivar FilterOperands:
    :vartype FilterOperands: ExtensionObject
    """

    data_type = NodeId(ObjectIds.ContentFilterElement)

    FilterOperator: 'ua.FilterOperator' = field(default_factory=lambda:FilterOperator.Equals)
    FilterOperands: 'list[ua.ExtensionObject]' = field(default_factory=list)


@dataclass(slots=True)
class ContentFilter:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.1

    :ivar Elements:
    :vartype Elements: ContentFilterElement
    """

    data_type = NodeId(ObjectIds.ContentFilter)

    Elements: 'list[ua.ContentFilterElement]' = field(default_factory=list)


@dataclass(slots=True)
class FilterOperand:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.4

    """

    data_type = NodeId(ObjectIds.FilterOperand)


@dataclass(slots=True)
class ElementOperand(FilterOperand):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.4/#7.7.4.2

    :ivar Index:
    :vartype Index: UInt32
    """

    data_type = NodeId(ObjectIds.ElementOperand)

    Index: 'ua.UInt32' = 0


@dataclass(slots=True)
class LiteralOperand(FilterOperand):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.4/#7.7.4.3

    :ivar Value:
    :vartype Value: Variant
    """

    data_type = NodeId(ObjectIds.LiteralOperand)

    Value: 'ua.Variant' = field(default_factory=lambda: Variant())


@dataclass(slots=True)
class AttributeOperand(FilterOperand):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.4/#7.7.4.4

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar Alias:
    :vartype Alias: String
    :ivar BrowsePath:
    :vartype BrowsePath: RelativePath
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    """

    data_type = NodeId(ObjectIds.AttributeOperand)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Alias: 'ua.String' = None
    BrowsePath: 'ua.RelativePath' = field(default_factory=lambda: RelativePath())
    AttributeId: 'ua.IntegerId' = 0
    IndexRange: 'ua.NumericRange' = None


@dataclass(slots=True)
class SimpleAttributeOperand(FilterOperand):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.4/#7.7.4.5

    :ivar TypeDefinitionId:
    :vartype TypeDefinitionId: NodeId
    :ivar BrowsePath:
    :vartype BrowsePath: QualifiedName
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    """

    data_type = NodeId(ObjectIds.SimpleAttributeOperand)

    TypeDefinitionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    BrowsePath: 'list[ua.QualifiedName]' = field(default_factory=list)
    AttributeId: 'ua.IntegerId' = 0
    IndexRange: 'ua.NumericRange' = None


@dataclass(slots=True)
class PublishedEventsDataType(PublishedDataSetSourceDataType):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part14/6.2.3/#6.2.3.8.4

    :ivar EventNotifier:
    :vartype EventNotifier: NodeId
    :ivar SelectedFields:
    :vartype SelectedFields: SimpleAttributeOperand
    :ivar Filter:
    :vartype Filter: ContentFilter
    """

    data_type = NodeId(ObjectIds.PublishedEventsDataType)

    EventNotifier: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    SelectedFields: 'list[ua.SimpleAttributeOperand]' = field(default_factory=list)
    Filter: 'ua.ContentFilter' = field(default_factory=lambda: ContentFilter())


@dataclass(slots=True)
class ContentFilterElementResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar OperandStatusCodes:
    :vartype OperandStatusCodes: StatusCode
    :ivar OperandDiagnosticInfos:
    :vartype OperandDiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.ContentFilterElementResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    OperandStatusCodes: 'list[ua.StatusCode]' = field(default_factory=list)
    OperandDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class ContentFilterResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.7.2

    :ivar ElementResults:
    :vartype ElementResults: ContentFilterElementResult
    :ivar ElementDiagnosticInfos:
    :vartype ElementDiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.ContentFilterResult)

    ElementResults: 'list[ua.ContentFilterElementResult]' = field(default_factory=list)
    ElementDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class ParsingResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.3/#5.10.3.1

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar DataStatusCodes:
    :vartype DataStatusCodes: StatusCode
    :ivar DataDiagnosticInfos:
    :vartype DataDiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.ParsingResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    DataStatusCodes: 'list[ua.StatusCode]' = field(default_factory=list)
    DataDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class QueryFirstParameters:
    """
    :ivar View:
    :vartype View: ViewDescription
    :ivar NodeTypes:
    :vartype NodeTypes: NodeTypeDescription
    :ivar Filter:
    :vartype Filter: ContentFilter
    :ivar MaxDataSetsToReturn:
    :vartype MaxDataSetsToReturn: Counter
    :ivar MaxReferencesToReturn:
    :vartype MaxReferencesToReturn: Counter
    """

    View: 'ua.ViewDescription' = field(default_factory=lambda: ViewDescription())
    NodeTypes: 'list[ua.NodeTypeDescription]' = field(default_factory=list)
    Filter: 'ua.ContentFilter' = field(default_factory=lambda: ContentFilter())
    MaxDataSetsToReturn: 'ua.Counter' = 0
    MaxReferencesToReturn: 'ua.Counter' = 0


@dataclass(slots=True)
class QueryFirstRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.3/#5.10.3.1

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: QueryFirstParameters
    """

    data_type = NodeId(ObjectIds.QueryFirstRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.QueryFirstRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.QueryFirstParameters' = field(default_factory=lambda: QueryFirstParameters())


@dataclass(slots=True)
class QueryFirstResult:
    """
    :ivar QueryDataSets:
    :vartype QueryDataSets: QueryDataSet
    :ivar ContinuationPoint:
    :vartype ContinuationPoint: ContinuationPoint
    :ivar ParsingResults:
    :vartype ParsingResults: ParsingResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    :ivar FilterResult:
    :vartype FilterResult: ContentFilterResult
    """

    QueryDataSets: 'list[ua.QueryDataSet]' = field(default_factory=list)
    ContinuationPoint: 'ua.ContinuationPoint' = None
    ParsingResults: 'list[ua.ParsingResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)
    FilterResult: 'ua.ContentFilterResult' = field(default_factory=lambda: ContentFilterResult())


@dataclass(slots=True)
class QueryFirstResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.3/#5.10.3.1

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: QueryFirstResult
    """

    data_type = NodeId(ObjectIds.QueryFirstResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.QueryFirstResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.QueryFirstResult' = field(default_factory=lambda: QueryFirstResult())


@dataclass(slots=True)
class QueryNextParameters:
    """
    :ivar ReleaseContinuationPoint:
    :vartype ReleaseContinuationPoint: Boolean
    :ivar ContinuationPoint:
    :vartype ContinuationPoint: ContinuationPoint
    """

    ReleaseContinuationPoint: 'ua.Boolean' = True
    ContinuationPoint: 'ua.ContinuationPoint' = None


@dataclass(slots=True)
class QueryNextRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.4/#5.10.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: QueryNextParameters
    """

    data_type = NodeId(ObjectIds.QueryNextRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.QueryNextRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.QueryNextParameters' = field(default_factory=lambda: QueryNextParameters())


@dataclass(slots=True)
class QueryNextResult:
    """
    :ivar QueryDataSets:
    :vartype QueryDataSets: QueryDataSet
    :ivar RevisedContinuationPoint:
    :vartype RevisedContinuationPoint: ContinuationPoint
    """

    QueryDataSets: 'list[ua.QueryDataSet]' = field(default_factory=list)
    RevisedContinuationPoint: 'ua.ContinuationPoint' = None


@dataclass(slots=True)
class QueryNextResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.10.4/#5.10.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: QueryNextResult
    """

    data_type = NodeId(ObjectIds.QueryNextResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.QueryNextResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.QueryNextResult' = field(default_factory=lambda: QueryNextResult())


@dataclass(slots=True)
class ReadValueId:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.28

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    :ivar DataEncoding:
    :vartype DataEncoding: QualifiedName
    """

    data_type = NodeId(ObjectIds.ReadValueId)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AttributeId: 'ua.IntegerId' = 0
    IndexRange: 'ua.NumericRange' = None
    DataEncoding: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())


@dataclass(slots=True)
class ReadParameters:
    """
    :ivar MaxAge:
    :vartype MaxAge: Duration
    :ivar TimestampsToReturn:
    :vartype TimestampsToReturn: TimestampsToReturn
    :ivar NodesToRead:
    :vartype NodesToRead: ReadValueId
    """

    MaxAge: 'ua.Duration' = 0
    TimestampsToReturn: 'ua.TimestampsToReturn' = field(default_factory=lambda:TimestampsToReturn.Source)
    NodesToRead: 'list[ua.ReadValueId]' = field(default_factory=list)


@dataclass(slots=True)
class ReadRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.2/#5.11.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: ReadParameters
    """

    data_type = NodeId(ObjectIds.ReadRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ReadRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.ReadParameters' = field(default_factory=lambda: ReadParameters())


@dataclass(slots=True)
class ReadResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.2/#5.11.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: DataValue
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.ReadResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ReadResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.DataValue]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryReadValueId:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.3/#5.11.3.2

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    :ivar DataEncoding:
    :vartype DataEncoding: QualifiedName
    :ivar ContinuationPoint:
    :vartype ContinuationPoint: ContinuationPoint
    """

    data_type = NodeId(ObjectIds.HistoryReadValueId)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IndexRange: 'ua.NumericRange' = None
    DataEncoding: 'ua.QualifiedName' = field(default_factory=lambda: QualifiedName())
    ContinuationPoint: 'ua.ContinuationPoint' = None


@dataclass(slots=True)
class HistoryReadResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.3/#5.11.3.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar ContinuationPoint:
    :vartype ContinuationPoint: ContinuationPoint
    :ivar HistoryData:
    :vartype HistoryData: ExtensionObject
    """

    data_type = NodeId(ObjectIds.HistoryReadResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    ContinuationPoint: 'ua.ContinuationPoint' = None
    HistoryData: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class HistoryReadDetails:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.1

    """

    data_type = NodeId(ObjectIds.HistoryReadDetails)


@dataclass(slots=True)
class SortRuleElement:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.7

    :ivar SortOrder:
    :vartype SortOrder: SortOrderType
    :ivar EventField:
    :vartype EventField: SimpleAttributeOperand
    """

    data_type = NodeId(ObjectIds.SortRuleElement)

    SortOrder: 'ua.SortOrderType' = field(default_factory=lambda:SortOrderType.Ascending)
    EventField: 'ua.SimpleAttributeOperand' = field(default_factory=lambda: SimpleAttributeOperand())


@dataclass(slots=True)
class ReadRawModifiedDetails(HistoryReadDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.3/#6.5.3.1

    :ivar IsReadModified:
    :vartype IsReadModified: Boolean
    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar EndTime:
    :vartype EndTime: UtcTime
    :ivar NumValuesPerNode:
    :vartype NumValuesPerNode: Counter
    :ivar ReturnBounds:
    :vartype ReturnBounds: Boolean
    """

    data_type = NodeId(ObjectIds.ReadRawModifiedDetails)

    IsReadModified: 'ua.Boolean' = True
    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    EndTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    NumValuesPerNode: 'ua.Counter' = 0
    ReturnBounds: 'ua.Boolean' = True


@dataclass(slots=True)
class ReadAtTimeDetails(HistoryReadDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.5/#6.5.5.1

    :ivar ReqTimes:
    :vartype ReqTimes: UtcTime
    :ivar UseSimpleBounds:
    :vartype UseSimpleBounds: Boolean
    """

    data_type = NodeId(ObjectIds.ReadAtTimeDetails)

    ReqTimes: 'list[ua.UtcTime]' = field(default_factory=list)
    UseSimpleBounds: 'ua.Boolean' = True


@dataclass(slots=True)
class ReadAnnotationDataDetails(HistoryReadDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.6/#6.5.6.1

    :ivar ReqTimes:
    :vartype ReqTimes: UtcTime
    """

    data_type = NodeId(ObjectIds.ReadAnnotationDataDetails)

    ReqTimes: 'list[ua.UtcTime]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryData:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.2

    :ivar DataValues:
    :vartype DataValues: DataValue
    """

    data_type = NodeId(ObjectIds.HistoryData)

    DataValues: 'list[ua.DataValue]' = field(default_factory=list)


@dataclass(slots=True)
class ModificationInfo:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.5

    :ivar ModificationTime:
    :vartype ModificationTime: UtcTime
    :ivar UpdateType:
    :vartype UpdateType: HistoryUpdateType
    :ivar UserName:
    :vartype UserName: String
    """

    data_type = NodeId(ObjectIds.ModificationInfo)

    ModificationTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    UpdateType: 'ua.HistoryUpdateType' = field(default_factory=lambda:HistoryUpdateType.Insert)
    UserName: 'ua.String' = None


@dataclass(slots=True)
class HistoryModifiedData(HistoryData):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.3

    :ivar DataValues:
    :vartype DataValues: DataValue
    :ivar ModificationInfos:
    :vartype ModificationInfos: ModificationInfo
    """

    data_type = NodeId(ObjectIds.HistoryModifiedData)

    DataValues: 'list[ua.DataValue]' = field(default_factory=list)
    ModificationInfos: 'list[ua.ModificationInfo]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryReadParameters:
    """
    :ivar HistoryReadDetails:
    :vartype HistoryReadDetails: ExtensionObject
    :ivar TimestampsToReturn:
    :vartype TimestampsToReturn: TimestampsToReturn
    :ivar ReleaseContinuationPoints:
    :vartype ReleaseContinuationPoints: Boolean
    :ivar NodesToRead:
    :vartype NodesToRead: HistoryReadValueId
    """

    HistoryReadDetails: 'ua.ExtensionObject' = ExtensionObject()
    TimestampsToReturn: 'ua.TimestampsToReturn' = field(default_factory=lambda:TimestampsToReturn.Source)
    ReleaseContinuationPoints: 'ua.Boolean' = True
    NodesToRead: 'list[ua.HistoryReadValueId]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryReadRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.3/#5.11.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: HistoryReadParameters
    """

    data_type = NodeId(ObjectIds.HistoryReadRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.HistoryReadRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.HistoryReadParameters' = field(default_factory=lambda: HistoryReadParameters())


@dataclass(slots=True)
class HistoryReadResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.3/#5.11.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: HistoryReadResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.HistoryReadResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.HistoryReadResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.HistoryReadResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class WriteValue:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.4/#5.11.4.2

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar AttributeId:
    :vartype AttributeId: IntegerId
    :ivar IndexRange:
    :vartype IndexRange: NumericRange
    :ivar Value:
    :vartype Value: DataValue
    """

    data_type = NodeId(ObjectIds.WriteValue)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AttributeId: 'ua.IntegerId' = 0
    IndexRange: 'ua.NumericRange' = None
    Value: 'ua.DataValue' = field(default_factory=lambda: DataValue())


@dataclass(slots=True)
class WriteParameters:
    """
    :ivar NodesToWrite:
    :vartype NodesToWrite: WriteValue
    """

    NodesToWrite: 'list[ua.WriteValue]' = field(default_factory=list)


@dataclass(slots=True)
class WriteRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.4/#5.11.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: WriteParameters
    """

    data_type = NodeId(ObjectIds.WriteRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.WriteRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.WriteParameters' = field(default_factory=lambda: WriteParameters())


@dataclass(slots=True)
class WriteResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.4/#5.11.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.WriteResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.WriteResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryUpdateDetails:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.1

    """

    data_type = NodeId(ObjectIds.HistoryUpdateDetails)


@dataclass(slots=True)
class UpdateDataDetails(HistoryUpdateDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.2/#6.9.2.1

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar PerformInsertReplace:
    :vartype PerformInsertReplace: PerformUpdateType
    :ivar UpdateValues:
    :vartype UpdateValues: DataValue
    """

    data_type = NodeId(ObjectIds.UpdateDataDetails)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    PerformInsertReplace: 'ua.PerformUpdateType' = field(default_factory=lambda:PerformUpdateType.Insert)
    UpdateValues: 'list[ua.DataValue]' = field(default_factory=list)


@dataclass(slots=True)
class UpdateStructureDataDetails(HistoryUpdateDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.3/#6.9.3.1

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar PerformInsertReplace:
    :vartype PerformInsertReplace: PerformUpdateType
    :ivar UpdateValues:
    :vartype UpdateValues: DataValue
    """

    data_type = NodeId(ObjectIds.UpdateStructureDataDetails)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    PerformInsertReplace: 'ua.PerformUpdateType' = field(default_factory=lambda:PerformUpdateType.Insert)
    UpdateValues: 'list[ua.DataValue]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteRawModifiedDetails(HistoryUpdateDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.5/#6.9.5.1

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar IsDeleteModified:
    :vartype IsDeleteModified: Boolean
    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar EndTime:
    :vartype EndTime: UtcTime
    """

    data_type = NodeId(ObjectIds.DeleteRawModifiedDetails)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    IsDeleteModified: 'ua.Boolean' = True
    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    EndTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(slots=True)
class DeleteAtTimeDetails(HistoryUpdateDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.6/#6.9.6.1

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar ReqTimes:
    :vartype ReqTimes: UtcTime
    """

    data_type = NodeId(ObjectIds.DeleteAtTimeDetails)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ReqTimes: 'list[ua.UtcTime]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteEventDetails(HistoryUpdateDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.7/#6.9.7.1

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar EventIds:
    :vartype EventIds: ByteString
    """

    data_type = NodeId(ObjectIds.DeleteEventDetails)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    EventIds: 'list[ua.ByteString]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryUpdateResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.5/#5.11.5.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar OperationResults:
    :vartype OperationResults: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.HistoryUpdateResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    OperationResults: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryUpdateParameters:
    """
    :ivar HistoryUpdateDetails:
    :vartype HistoryUpdateDetails: ExtensionObject
    """

    HistoryUpdateDetails: 'list[ua.ExtensionObject]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryUpdateRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.5/#5.11.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: HistoryUpdateParameters
    """

    data_type = NodeId(ObjectIds.HistoryUpdateRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.HistoryUpdateRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.HistoryUpdateParameters' = field(default_factory=lambda: HistoryUpdateParameters())


@dataclass(slots=True)
class HistoryUpdateResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.11.5/#5.11.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: HistoryUpdateResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.HistoryUpdateResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.HistoryUpdateResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.HistoryUpdateResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class CallMethodRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.12.2/#5.12.2.2

    :ivar ObjectId:
    :vartype ObjectId: NodeId
    :ivar MethodId:
    :vartype MethodId: NodeId
    :ivar InputArguments:
    :vartype InputArguments: Variant
    """

    data_type = NodeId(ObjectIds.CallMethodRequest)

    ObjectId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    MethodId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    InputArguments: 'list[ua.Variant]' = field(default_factory=list)


@dataclass(slots=True)
class CallMethodResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.12.2/#5.12.2.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar InputArgumentResults:
    :vartype InputArgumentResults: StatusCode
    :ivar InputArgumentDiagnosticInfos:
    :vartype InputArgumentDiagnosticInfos: DiagnosticInfo
    :ivar OutputArguments:
    :vartype OutputArguments: Variant
    """

    data_type = NodeId(ObjectIds.CallMethodResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    InputArgumentResults: 'list[ua.StatusCode]' = field(default_factory=list)
    InputArgumentDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)
    OutputArguments: 'list[ua.Variant]' = field(default_factory=list)


@dataclass(slots=True)
class CallParameters:
    """
    :ivar MethodsToCall:
    :vartype MethodsToCall: CallMethodRequest
    """

    MethodsToCall: 'list[ua.CallMethodRequest]' = field(default_factory=list)


@dataclass(slots=True)
class CallRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.12.2/#5.12.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: CallParameters
    """

    data_type = NodeId(ObjectIds.CallRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CallRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.CallParameters' = field(default_factory=lambda: CallParameters())


@dataclass(slots=True)
class CallResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.12.2/#5.12.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: CallMethodResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.CallResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CallResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.CallMethodResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class MonitoringFilter:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.1

    """

    data_type = NodeId(ObjectIds.MonitoringFilter)


@dataclass(slots=True)
class DataChangeFilter(MonitoringFilter):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.2

    :ivar Trigger:
    :vartype Trigger: DataChangeTrigger
    :ivar DeadbandType:
    :vartype DeadbandType: UInt32
    :ivar DeadbandValue:
    :vartype DeadbandValue: Double
    """

    data_type = NodeId(ObjectIds.DataChangeFilter)

    Trigger: 'ua.DataChangeTrigger' = field(default_factory=lambda:DataChangeTrigger.Status)
    DeadbandType: 'ua.UInt32' = 0
    DeadbandValue: 'ua.Double' = 0


@dataclass(slots=True)
class EventFilter(MonitoringFilter):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.3

    :ivar SelectClauses:
    :vartype SelectClauses: SimpleAttributeOperand
    :ivar WhereClause:
    :vartype WhereClause: ContentFilter
    """

    data_type = NodeId(ObjectIds.EventFilter)

    SelectClauses: 'list[ua.SimpleAttributeOperand]' = field(default_factory=list)
    WhereClause: 'ua.ContentFilter' = field(default_factory=lambda: ContentFilter())


@dataclass(slots=True)
class ReadEventDetails(HistoryReadDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.2/#6.5.2.1

    :ivar NumValuesPerNode:
    :vartype NumValuesPerNode: Counter
    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar EndTime:
    :vartype EndTime: UtcTime
    :ivar Filter:
    :vartype Filter: EventFilter
    """

    data_type = NodeId(ObjectIds.ReadEventDetails)

    NumValuesPerNode: 'ua.Counter' = 0
    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    EndTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Filter: 'ua.EventFilter' = field(default_factory=lambda: EventFilter())


@dataclass(slots=True)
class ReadEventDetails2(ReadEventDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.2/#6.5.2.3

    :ivar NumValuesPerNode:
    :vartype NumValuesPerNode: Counter
    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar EndTime:
    :vartype EndTime: UtcTime
    :ivar Filter:
    :vartype Filter: EventFilter
    :ivar ReadModified:
    :vartype ReadModified: Boolean
    """

    data_type = NodeId(ObjectIds.ReadEventDetails2)

    NumValuesPerNode: 'ua.Counter' = 0
    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    EndTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Filter: 'ua.EventFilter' = field(default_factory=lambda: EventFilter())
    ReadModified: 'ua.Boolean' = True


@dataclass(slots=True)
class ReadEventDetailsSorted(ReadEventDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.5.2/#6.5.2.5

    :ivar NumValuesPerNode:
    :vartype NumValuesPerNode: Counter
    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar EndTime:
    :vartype EndTime: UtcTime
    :ivar Filter:
    :vartype Filter: EventFilter
    :ivar SortClause:
    :vartype SortClause: SortRuleElement
    """

    data_type = NodeId(ObjectIds.ReadEventDetailsSorted)

    NumValuesPerNode: 'ua.Counter' = 0
    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    EndTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    Filter: 'ua.EventFilter' = field(default_factory=lambda: EventFilter())
    SortClause: 'list[ua.SortRuleElement]' = field(default_factory=list)


@dataclass(slots=True)
class AggregateConfiguration:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.4

    :ivar UseServerCapabilitiesDefaults:
    :vartype UseServerCapabilitiesDefaults: Boolean
    :ivar TreatUncertainAsBad:
    :vartype TreatUncertainAsBad: Boolean
    :ivar PercentDataBad:
    :vartype PercentDataBad: Byte
    :ivar PercentDataGood:
    :vartype PercentDataGood: Byte
    :ivar UseSlopedExtrapolation:
    :vartype UseSlopedExtrapolation: Boolean
    """

    data_type = NodeId(ObjectIds.AggregateConfiguration)

    UseServerCapabilitiesDefaults: 'ua.Boolean' = True
    TreatUncertainAsBad: 'ua.Boolean' = True
    PercentDataBad: 'ua.Byte' = 0
    PercentDataGood: 'ua.Byte' = 0
    UseSlopedExtrapolation: 'ua.Boolean' = True


@dataclass(slots=True)
class ReadProcessedDetails(HistoryReadDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part13/5.2.2

    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar EndTime:
    :vartype EndTime: UtcTime
    :ivar ProcessingInterval:
    :vartype ProcessingInterval: Duration
    :ivar AggregateType:
    :vartype AggregateType: NodeId
    :ivar AggregateConfiguration:
    :vartype AggregateConfiguration: AggregateConfiguration
    """

    data_type = NodeId(ObjectIds.ReadProcessedDetails)

    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    EndTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    ProcessingInterval: 'ua.Duration' = 0
    AggregateType: 'list[ua.NodeId]' = field(default_factory=list)
    AggregateConfiguration: 'ua.AggregateConfiguration' = field(default_factory=lambda: AggregateConfiguration())


@dataclass(slots=True)
class AggregateFilter(MonitoringFilter):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.4

    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar AggregateType:
    :vartype AggregateType: NodeId
    :ivar ProcessingInterval:
    :vartype ProcessingInterval: Duration
    :ivar AggregateConfiguration:
    :vartype AggregateConfiguration: AggregateConfiguration
    """

    data_type = NodeId(ObjectIds.AggregateFilter)

    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    AggregateType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ProcessingInterval: 'ua.Duration' = 0
    AggregateConfiguration: 'ua.AggregateConfiguration' = field(default_factory=lambda: AggregateConfiguration())


@dataclass(slots=True)
class MonitoringFilterResult:
    """
    """

    data_type = NodeId(ObjectIds.MonitoringFilterResult)


@dataclass(slots=True)
class EventFilterResult(MonitoringFilterResult):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.3

    :ivar SelectClauseResults:
    :vartype SelectClauseResults: StatusCode
    :ivar SelectClauseDiagnosticInfos:
    :vartype SelectClauseDiagnosticInfos: DiagnosticInfo
    :ivar WhereClauseResult:
    :vartype WhereClauseResult: ContentFilterResult
    """

    data_type = NodeId(ObjectIds.EventFilterResult)

    SelectClauseResults: 'list[ua.StatusCode]' = field(default_factory=list)
    SelectClauseDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)
    WhereClauseResult: 'ua.ContentFilterResult' = field(default_factory=lambda: ContentFilterResult())


@dataclass(slots=True)
class AggregateFilterResult(MonitoringFilterResult):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.22.4

    :ivar RevisedStartTime:
    :vartype RevisedStartTime: UtcTime
    :ivar RevisedProcessingInterval:
    :vartype RevisedProcessingInterval: Duration
    :ivar RevisedAggregateConfiguration:
    :vartype RevisedAggregateConfiguration: AggregateConfiguration
    """

    data_type = NodeId(ObjectIds.AggregateFilterResult)

    RevisedStartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    RevisedProcessingInterval: 'ua.Duration' = 0
    RevisedAggregateConfiguration: 'ua.AggregateConfiguration' = field(default_factory=lambda: AggregateConfiguration())


@dataclass(slots=True)
class MonitoringParameters:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.21

    :ivar ClientHandle:
    :vartype ClientHandle: IntegerId
    :ivar SamplingInterval:
    :vartype SamplingInterval: Duration
    :ivar Filter:
    :vartype Filter: ExtensionObject
    :ivar QueueSize:
    :vartype QueueSize: Counter
    :ivar DiscardOldest:
    :vartype DiscardOldest: Boolean
    """

    data_type = NodeId(ObjectIds.MonitoringParameters)

    ClientHandle: 'ua.IntegerId' = 0
    SamplingInterval: 'ua.Duration' = 0
    Filter: 'ua.ExtensionObject' = ExtensionObject()
    QueueSize: 'ua.Counter' = 0
    DiscardOldest: 'ua.Boolean' = True


@dataclass(slots=True)
class MonitoredItemCreateRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.2/#5.13.2.2

    :ivar ItemToMonitor:
    :vartype ItemToMonitor: ReadValueId
    :ivar MonitoringMode:
    :vartype MonitoringMode: MonitoringMode
    :ivar RequestedParameters:
    :vartype RequestedParameters: MonitoringParameters
    """

    data_type = NodeId(ObjectIds.MonitoredItemCreateRequest)

    ItemToMonitor: 'ua.ReadValueId' = field(default_factory=lambda: ReadValueId())
    MonitoringMode: 'ua.MonitoringMode' = field(default_factory=lambda:MonitoringMode.Disabled)
    RequestedParameters: 'ua.MonitoringParameters' = field(default_factory=lambda: MonitoringParameters())


@dataclass(slots=True)
class MonitoredItemCreateResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.2/#5.13.2.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar MonitoredItemId:
    :vartype MonitoredItemId: IntegerId
    :ivar RevisedSamplingInterval:
    :vartype RevisedSamplingInterval: Duration
    :ivar RevisedQueueSize:
    :vartype RevisedQueueSize: Counter
    :ivar FilterResult:
    :vartype FilterResult: ExtensionObject
    """

    data_type = NodeId(ObjectIds.MonitoredItemCreateResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    MonitoredItemId: 'ua.IntegerId' = 0
    RevisedSamplingInterval: 'ua.Duration' = 0
    RevisedQueueSize: 'ua.Counter' = 0
    FilterResult: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class CreateMonitoredItemsParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar TimestampsToReturn:
    :vartype TimestampsToReturn: TimestampsToReturn
    :ivar ItemsToCreate:
    :vartype ItemsToCreate: MonitoredItemCreateRequest
    """

    SubscriptionId: 'ua.IntegerId' = 0
    TimestampsToReturn: 'ua.TimestampsToReturn' = field(default_factory=lambda:TimestampsToReturn.Source)
    ItemsToCreate: 'list[ua.MonitoredItemCreateRequest]' = field(default_factory=list)


@dataclass(slots=True)
class CreateMonitoredItemsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.2/#5.13.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: CreateMonitoredItemsParameters
    """

    data_type = NodeId(ObjectIds.CreateMonitoredItemsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CreateMonitoredItemsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.CreateMonitoredItemsParameters' = field(default_factory=lambda: CreateMonitoredItemsParameters())


@dataclass(slots=True)
class CreateMonitoredItemsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.2/#5.13.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: MonitoredItemCreateResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.CreateMonitoredItemsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CreateMonitoredItemsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.MonitoredItemCreateResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class MonitoredItemModifyRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.3/#5.13.3.2

    :ivar MonitoredItemId:
    :vartype MonitoredItemId: IntegerId
    :ivar RequestedParameters:
    :vartype RequestedParameters: MonitoringParameters
    """

    data_type = NodeId(ObjectIds.MonitoredItemModifyRequest)

    MonitoredItemId: 'ua.IntegerId' = 0
    RequestedParameters: 'ua.MonitoringParameters' = field(default_factory=lambda: MonitoringParameters())


@dataclass(slots=True)
class MonitoredItemModifyResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.3/#5.13.3.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar RevisedSamplingInterval:
    :vartype RevisedSamplingInterval: Duration
    :ivar RevisedQueueSize:
    :vartype RevisedQueueSize: Counter
    :ivar FilterResult:
    :vartype FilterResult: ExtensionObject
    """

    data_type = NodeId(ObjectIds.MonitoredItemModifyResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    RevisedSamplingInterval: 'ua.Duration' = 0
    RevisedQueueSize: 'ua.Counter' = 0
    FilterResult: 'ua.ExtensionObject' = ExtensionObject()


@dataclass(slots=True)
class ModifyMonitoredItemsParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar TimestampsToReturn:
    :vartype TimestampsToReturn: TimestampsToReturn
    :ivar ItemsToModify:
    :vartype ItemsToModify: MonitoredItemModifyRequest
    """

    SubscriptionId: 'ua.IntegerId' = 0
    TimestampsToReturn: 'ua.TimestampsToReturn' = field(default_factory=lambda:TimestampsToReturn.Source)
    ItemsToModify: 'list[ua.MonitoredItemModifyRequest]' = field(default_factory=list)


@dataclass(slots=True)
class ModifyMonitoredItemsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.3/#5.13.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: ModifyMonitoredItemsParameters
    """

    data_type = NodeId(ObjectIds.ModifyMonitoredItemsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ModifyMonitoredItemsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.ModifyMonitoredItemsParameters' = field(default_factory=lambda: ModifyMonitoredItemsParameters())


@dataclass(slots=True)
class ModifyMonitoredItemsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.3/#5.13.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: MonitoredItemModifyResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.ModifyMonitoredItemsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ModifyMonitoredItemsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.MonitoredItemModifyResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class SetMonitoringModeParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar MonitoringMode:
    :vartype MonitoringMode: MonitoringMode
    :ivar MonitoredItemIds:
    :vartype MonitoredItemIds: IntegerId
    """

    SubscriptionId: 'ua.IntegerId' = 0
    MonitoringMode: 'ua.MonitoringMode' = field(default_factory=lambda:MonitoringMode.Disabled)
    MonitoredItemIds: 'list[ua.IntegerId]' = field(default_factory=list)


@dataclass(slots=True)
class SetMonitoringModeRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.4/#5.13.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: SetMonitoringModeParameters
    """

    data_type = NodeId(ObjectIds.SetMonitoringModeRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.SetMonitoringModeRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.SetMonitoringModeParameters' = field(default_factory=lambda: SetMonitoringModeParameters())


@dataclass(slots=True)
class SetMonitoringModeResult:
    """
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class SetMonitoringModeResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.4/#5.13.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: SetMonitoringModeResult
    """

    data_type = NodeId(ObjectIds.SetMonitoringModeResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.SetMonitoringModeResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.SetMonitoringModeResult' = field(default_factory=lambda: SetMonitoringModeResult())


@dataclass(slots=True)
class SetTriggeringParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar TriggeringItemId:
    :vartype TriggeringItemId: IntegerId
    :ivar LinksToAdd:
    :vartype LinksToAdd: IntegerId
    :ivar LinksToRemove:
    :vartype LinksToRemove: IntegerId
    """

    SubscriptionId: 'ua.IntegerId' = 0
    TriggeringItemId: 'ua.IntegerId' = 0
    LinksToAdd: 'list[ua.IntegerId]' = field(default_factory=list)
    LinksToRemove: 'list[ua.IntegerId]' = field(default_factory=list)


@dataclass(slots=True)
class SetTriggeringRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.5/#5.13.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: SetTriggeringParameters
    """

    data_type = NodeId(ObjectIds.SetTriggeringRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.SetTriggeringRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.SetTriggeringParameters' = field(default_factory=lambda: SetTriggeringParameters())


@dataclass(slots=True)
class SetTriggeringResult:
    """
    :ivar AddResults:
    :vartype AddResults: StatusCode
    :ivar AddDiagnosticInfos:
    :vartype AddDiagnosticInfos: DiagnosticInfo
    :ivar RemoveResults:
    :vartype RemoveResults: StatusCode
    :ivar RemoveDiagnosticInfos:
    :vartype RemoveDiagnosticInfos: DiagnosticInfo
    """

    AddResults: 'list[ua.StatusCode]' = field(default_factory=list)
    AddDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)
    RemoveResults: 'list[ua.StatusCode]' = field(default_factory=list)
    RemoveDiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class SetTriggeringResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.5/#5.13.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: SetTriggeringResult
    """

    data_type = NodeId(ObjectIds.SetTriggeringResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.SetTriggeringResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.SetTriggeringResult' = field(default_factory=lambda: SetTriggeringResult())


@dataclass(slots=True)
class DeleteMonitoredItemsParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar MonitoredItemIds:
    :vartype MonitoredItemIds: IntegerId
    """

    SubscriptionId: 'ua.IntegerId' = 0
    MonitoredItemIds: 'list[ua.IntegerId]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteMonitoredItemsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.6/#5.13.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: DeleteMonitoredItemsParameters
    """

    data_type = NodeId(ObjectIds.DeleteMonitoredItemsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteMonitoredItemsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.DeleteMonitoredItemsParameters' = field(default_factory=lambda: DeleteMonitoredItemsParameters())


@dataclass(slots=True)
class DeleteMonitoredItemsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.13.6/#5.13.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.DeleteMonitoredItemsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteMonitoredItemsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class CreateSubscriptionParameters:
    """
    :ivar RequestedPublishingInterval:
    :vartype RequestedPublishingInterval: Duration
    :ivar RequestedLifetimeCount:
    :vartype RequestedLifetimeCount: Counter
    :ivar RequestedMaxKeepAliveCount:
    :vartype RequestedMaxKeepAliveCount: Counter
    :ivar MaxNotificationsPerPublish:
    :vartype MaxNotificationsPerPublish: Counter
    :ivar PublishingEnabled:
    :vartype PublishingEnabled: Boolean
    :ivar Priority:
    :vartype Priority: Byte
    """

    RequestedPublishingInterval: 'ua.Duration' = 0
    RequestedLifetimeCount: 'ua.Counter' = 0
    RequestedMaxKeepAliveCount: 'ua.Counter' = 0
    MaxNotificationsPerPublish: 'ua.Counter' = 0
    PublishingEnabled: 'ua.Boolean' = True
    Priority: 'ua.Byte' = 0


@dataclass(slots=True)
class CreateSubscriptionRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.2/#5.14.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: CreateSubscriptionParameters
    """

    data_type = NodeId(ObjectIds.CreateSubscriptionRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CreateSubscriptionRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.CreateSubscriptionParameters' = field(default_factory=lambda: CreateSubscriptionParameters())


@dataclass(slots=True)
class CreateSubscriptionResult:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar RevisedPublishingInterval:
    :vartype RevisedPublishingInterval: Duration
    :ivar RevisedLifetimeCount:
    :vartype RevisedLifetimeCount: Counter
    :ivar RevisedMaxKeepAliveCount:
    :vartype RevisedMaxKeepAliveCount: Counter
    """

    SubscriptionId: 'ua.IntegerId' = 0
    RevisedPublishingInterval: 'ua.Duration' = 0
    RevisedLifetimeCount: 'ua.Counter' = 0
    RevisedMaxKeepAliveCount: 'ua.Counter' = 0


@dataclass(slots=True)
class CreateSubscriptionResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.2/#5.14.2.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: CreateSubscriptionResult
    """

    data_type = NodeId(ObjectIds.CreateSubscriptionResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.CreateSubscriptionResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.CreateSubscriptionResult' = field(default_factory=lambda: CreateSubscriptionResult())


@dataclass(slots=True)
class ModifySubscriptionParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar RequestedPublishingInterval:
    :vartype RequestedPublishingInterval: Duration
    :ivar RequestedLifetimeCount:
    :vartype RequestedLifetimeCount: Counter
    :ivar RequestedMaxKeepAliveCount:
    :vartype RequestedMaxKeepAliveCount: Counter
    :ivar MaxNotificationsPerPublish:
    :vartype MaxNotificationsPerPublish: Counter
    :ivar Priority:
    :vartype Priority: Byte
    """

    SubscriptionId: 'ua.IntegerId' = 0
    RequestedPublishingInterval: 'ua.Duration' = 0
    RequestedLifetimeCount: 'ua.Counter' = 0
    RequestedMaxKeepAliveCount: 'ua.Counter' = 0
    MaxNotificationsPerPublish: 'ua.Counter' = 0
    Priority: 'ua.Byte' = 0


@dataclass(slots=True)
class ModifySubscriptionRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.3/#5.14.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: ModifySubscriptionParameters
    """

    data_type = NodeId(ObjectIds.ModifySubscriptionRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ModifySubscriptionRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.ModifySubscriptionParameters' = field(default_factory=lambda: ModifySubscriptionParameters())


@dataclass(slots=True)
class ModifySubscriptionResult:
    """
    :ivar RevisedPublishingInterval:
    :vartype RevisedPublishingInterval: Duration
    :ivar RevisedLifetimeCount:
    :vartype RevisedLifetimeCount: Counter
    :ivar RevisedMaxKeepAliveCount:
    :vartype RevisedMaxKeepAliveCount: Counter
    """

    RevisedPublishingInterval: 'ua.Duration' = 0
    RevisedLifetimeCount: 'ua.Counter' = 0
    RevisedMaxKeepAliveCount: 'ua.Counter' = 0


@dataclass(slots=True)
class ModifySubscriptionResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.3/#5.14.3.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: ModifySubscriptionResult
    """

    data_type = NodeId(ObjectIds.ModifySubscriptionResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.ModifySubscriptionResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.ModifySubscriptionResult' = field(default_factory=lambda: ModifySubscriptionResult())


@dataclass(slots=True)
class SetPublishingModeParameters:
    """
    :ivar PublishingEnabled:
    :vartype PublishingEnabled: Boolean
    :ivar SubscriptionIds:
    :vartype SubscriptionIds: IntegerId
    """

    PublishingEnabled: 'ua.Boolean' = True
    SubscriptionIds: 'list[ua.IntegerId]' = field(default_factory=list)


@dataclass(slots=True)
class SetPublishingModeRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.4/#5.14.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: SetPublishingModeParameters
    """

    data_type = NodeId(ObjectIds.SetPublishingModeRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.SetPublishingModeRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.SetPublishingModeParameters' = field(default_factory=lambda: SetPublishingModeParameters())


@dataclass(slots=True)
class SetPublishingModeResult:
    """
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class SetPublishingModeResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.4/#5.14.4.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: SetPublishingModeResult
    """

    data_type = NodeId(ObjectIds.SetPublishingModeResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.SetPublishingModeResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.SetPublishingModeResult' = field(default_factory=lambda: SetPublishingModeResult())


@dataclass(slots=True)
class NotificationMessage:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.26

    :ivar SequenceNumber:
    :vartype SequenceNumber: Counter
    :ivar PublishTime:
    :vartype PublishTime: UtcTime
    :ivar NotificationData:
    :vartype NotificationData: ExtensionObject
    """

    data_type = NodeId(ObjectIds.NotificationMessage)

    SequenceNumber: 'ua.Counter' = 0
    PublishTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    NotificationData: 'list[ua.ExtensionObject]' = field(default_factory=list)


@dataclass(slots=True)
class NotificationData:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.25.1

    """

    data_type = NodeId(ObjectIds.NotificationData)


@dataclass(slots=True)
class MonitoredItemNotification:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.25.2

    :ivar ClientHandle:
    :vartype ClientHandle: IntegerId
    :ivar Value:
    :vartype Value: DataValue
    """

    data_type = NodeId(ObjectIds.MonitoredItemNotification)

    ClientHandle: 'ua.IntegerId' = 0
    Value: 'ua.DataValue' = field(default_factory=lambda: DataValue())


@dataclass(slots=True)
class DataChangeNotification(NotificationData):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.25.2

    :ivar MonitoredItems:
    :vartype MonitoredItems: MonitoredItemNotification
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.DataChangeNotification)

    MonitoredItems: 'list[ua.MonitoredItemNotification]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class EventFieldList:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.25.3

    :ivar ClientHandle:
    :vartype ClientHandle: IntegerId
    :ivar EventFields:
    :vartype EventFields: Variant
    """

    data_type = NodeId(ObjectIds.EventFieldList)

    ClientHandle: 'ua.IntegerId' = 0
    EventFields: 'list[ua.Variant]' = field(default_factory=list)


@dataclass(slots=True)
class EventNotificationList(NotificationData):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.25.3

    :ivar Events:
    :vartype Events: EventFieldList
    """

    data_type = NodeId(ObjectIds.EventNotificationList)

    Events: 'list[ua.EventFieldList]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryEventFieldList:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.4

    :ivar EventFields:
    :vartype EventFields: Variant
    """

    data_type = NodeId(ObjectIds.HistoryEventFieldList)

    EventFields: 'list[ua.Variant]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryEvent:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.4

    :ivar Events:
    :vartype Events: HistoryEventFieldList
    """

    data_type = NodeId(ObjectIds.HistoryEvent)

    Events: 'list[ua.HistoryEventFieldList]' = field(default_factory=list)


@dataclass(slots=True)
class HistoryModifiedEvent(HistoryEvent):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.5

    :ivar Events:
    :vartype Events: HistoryEventFieldList
    :ivar ModificationInfos:
    :vartype ModificationInfos: ModificationInfo
    """

    data_type = NodeId(ObjectIds.HistoryModifiedEvent)

    Events: 'list[ua.HistoryEventFieldList]' = field(default_factory=list)
    ModificationInfos: 'list[ua.ModificationInfo]' = field(default_factory=list)


@dataclass(slots=True)
class UpdateEventDetails(HistoryUpdateDetails):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.9.4/#6.9.4.1

    :ivar NodeId:
    :vartype NodeId: NodeId
    :ivar PerformInsertReplace:
    :vartype PerformInsertReplace: PerformUpdateType
    :ivar Filter:
    :vartype Filter: EventFilter
    :ivar EventData:
    :vartype EventData: HistoryEventFieldList
    """

    data_type = NodeId(ObjectIds.UpdateEventDetails)

    NodeId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    PerformInsertReplace: 'ua.PerformUpdateType' = field(default_factory=lambda:PerformUpdateType.Insert)
    Filter: 'ua.EventFilter' = field(default_factory=lambda: EventFilter())
    EventData: 'list[ua.HistoryEventFieldList]' = field(default_factory=list)


@dataclass(slots=True)
class StatusChangeNotification(NotificationData):
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/7.25.4

    :ivar Status:
    :vartype Status: StatusCode
    :ivar DiagnosticInfo:
    :vartype DiagnosticInfo: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.StatusChangeNotification)

    Status: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    DiagnosticInfo: 'ua.DiagnosticInfo' = field(default_factory=lambda: DiagnosticInfo())


@dataclass(slots=True)
class SubscriptionAcknowledgement:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.5/#5.14.5.2

    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar SequenceNumber:
    :vartype SequenceNumber: Counter
    """

    data_type = NodeId(ObjectIds.SubscriptionAcknowledgement)

    SubscriptionId: 'ua.IntegerId' = 0
    SequenceNumber: 'ua.Counter' = 0


@dataclass(slots=True)
class PublishParameters:
    """
    :ivar SubscriptionAcknowledgements:
    :vartype SubscriptionAcknowledgements: SubscriptionAcknowledgement
    """

    SubscriptionAcknowledgements: 'list[ua.SubscriptionAcknowledgement]' = field(default_factory=list)


@dataclass(slots=True)
class PublishRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.5/#5.14.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: PublishParameters
    """

    data_type = NodeId(ObjectIds.PublishRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.PublishRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.PublishParameters' = field(default_factory=lambda: PublishParameters())


@dataclass(slots=True)
class PublishResult:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar AvailableSequenceNumbers:
    :vartype AvailableSequenceNumbers: Counter
    :ivar MoreNotifications:
    :vartype MoreNotifications: Boolean
    :ivar NotificationMessage:
    :vartype NotificationMessage: NotificationMessage
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    SubscriptionId: 'ua.IntegerId' = 0
    AvailableSequenceNumbers: 'list[ua.Counter]' = field(default_factory=list)
    MoreNotifications: 'ua.Boolean' = True
    NotificationMessage: 'ua.NotificationMessage' = field(default_factory=lambda: NotificationMessage())
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class PublishResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.5/#5.14.5.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: PublishResult
    """

    data_type = NodeId(ObjectIds.PublishResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.PublishResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.PublishResult' = field(default_factory=lambda: PublishResult())


@dataclass(slots=True)
class RepublishParameters:
    """
    :ivar SubscriptionId:
    :vartype SubscriptionId: IntegerId
    :ivar RetransmitSequenceNumber:
    :vartype RetransmitSequenceNumber: Counter
    """

    SubscriptionId: 'ua.IntegerId' = 0
    RetransmitSequenceNumber: 'ua.Counter' = 0


@dataclass(slots=True)
class RepublishRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.6/#5.14.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: RepublishParameters
    """

    data_type = NodeId(ObjectIds.RepublishRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RepublishRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.RepublishParameters' = field(default_factory=lambda: RepublishParameters())


@dataclass(slots=True)
class RepublishResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.6/#5.14.6.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar NotificationMessage:
    :vartype NotificationMessage: NotificationMessage
    """

    data_type = NodeId(ObjectIds.RepublishResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.RepublishResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    NotificationMessage: 'ua.NotificationMessage' = field(default_factory=lambda: NotificationMessage())


@dataclass(slots=True)
class TransferResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.7/#5.14.7.2

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar AvailableSequenceNumbers:
    :vartype AvailableSequenceNumbers: Counter
    """

    data_type = NodeId(ObjectIds.TransferResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    AvailableSequenceNumbers: 'list[ua.Counter]' = field(default_factory=list)


@dataclass(slots=True)
class TransferSubscriptionsParameters:
    """
    :ivar SubscriptionIds:
    :vartype SubscriptionIds: IntegerId
    :ivar SendInitialValues:
    :vartype SendInitialValues: Boolean
    """

    SubscriptionIds: 'list[ua.IntegerId]' = field(default_factory=list)
    SendInitialValues: 'ua.Boolean' = True


@dataclass(slots=True)
class TransferSubscriptionsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.7/#5.14.7.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: TransferSubscriptionsParameters
    """

    data_type = NodeId(ObjectIds.TransferSubscriptionsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.TransferSubscriptionsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.TransferSubscriptionsParameters' = field(default_factory=lambda: TransferSubscriptionsParameters())


@dataclass(slots=True)
class TransferSubscriptionsResult:
    """
    :ivar Results:
    :vartype Results: TransferResult
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    Results: 'list[ua.TransferResult]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class TransferSubscriptionsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.7/#5.14.7.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Parameters:
    :vartype Parameters: TransferSubscriptionsResult
    """

    data_type = NodeId(ObjectIds.TransferSubscriptionsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.TransferSubscriptionsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Parameters: 'ua.TransferSubscriptionsResult' = field(default_factory=lambda: TransferSubscriptionsResult())


@dataclass(slots=True)
class DeleteSubscriptionsParameters:
    """
    :ivar SubscriptionIds:
    :vartype SubscriptionIds: IntegerId
    """

    SubscriptionIds: 'list[ua.IntegerId]' = field(default_factory=list)


@dataclass(slots=True)
class DeleteSubscriptionsRequest:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.8/#5.14.8.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar RequestHeader:
    :vartype RequestHeader: RequestHeader
    :ivar Parameters:
    :vartype Parameters: DeleteSubscriptionsParameters
    """

    data_type = NodeId(ObjectIds.DeleteSubscriptionsRequest)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteSubscriptionsRequest_Encoding_DefaultBinary)
    RequestHeader: 'ua.RequestHeader' = field(default_factory=lambda: RequestHeader())
    Parameters: 'ua.DeleteSubscriptionsParameters' = field(default_factory=lambda: DeleteSubscriptionsParameters())


@dataclass(slots=True)
class DeleteSubscriptionsResponse:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part4/5.14.8/#5.14.8.2

    :ivar TypeId:
    :vartype TypeId: NodeId
    :ivar ResponseHeader:
    :vartype ResponseHeader: ResponseHeader
    :ivar Results:
    :vartype Results: StatusCode
    :ivar DiagnosticInfos:
    :vartype DiagnosticInfos: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.DeleteSubscriptionsResponse)

    TypeId: 'ua.NodeId' = FourByteNodeId(ObjectIds.DeleteSubscriptionsResponse_Encoding_DefaultBinary)
    ResponseHeader: 'ua.ResponseHeader' = field(default_factory=lambda: ResponseHeader())
    Results: 'list[ua.StatusCode]' = field(default_factory=list)
    DiagnosticInfos: 'list[ua.DiagnosticInfo]' = field(default_factory=list)


@dataclass(slots=True)
class BuildInfo:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.4

    :ivar ProductUri:
    :vartype ProductUri: String
    :ivar ManufacturerName:
    :vartype ManufacturerName: String
    :ivar ProductName:
    :vartype ProductName: String
    :ivar SoftwareVersion:
    :vartype SoftwareVersion: String
    :ivar BuildNumber:
    :vartype BuildNumber: String
    :ivar BuildDate:
    :vartype BuildDate: UtcTime
    """

    data_type = NodeId(ObjectIds.BuildInfo)

    ProductUri: 'ua.String' = None
    ManufacturerName: 'ua.String' = None
    ProductName: 'ua.String' = None
    SoftwareVersion: 'ua.String' = None
    BuildNumber: 'ua.String' = None
    BuildDate: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass(slots=True)
class RedundantServerDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.7

    :ivar ServerId:
    :vartype ServerId: String
    :ivar ServiceLevel:
    :vartype ServiceLevel: Byte
    :ivar ServerState:
    :vartype ServerState: ServerState
    """

    data_type = NodeId(ObjectIds.RedundantServerDataType)

    ServerId: 'ua.String' = None
    ServiceLevel: 'ua.Byte' = 0
    ServerState: 'ua.ServerState' = field(default_factory=lambda:ServerState.Running)


@dataclass(slots=True)
class EndpointUrlListDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.20

    :ivar EndpointUrlList:
    :vartype EndpointUrlList: String
    """

    data_type = NodeId(ObjectIds.EndpointUrlListDataType)

    EndpointUrlList: 'list[ua.String]' = field(default_factory=list)


@dataclass(slots=True)
class NetworkGroupDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.19

    :ivar ServerUri:
    :vartype ServerUri: String
    :ivar NetworkPaths:
    :vartype NetworkPaths: EndpointUrlListDataType
    """

    data_type = NodeId(ObjectIds.NetworkGroupDataType)

    ServerUri: 'ua.String' = None
    NetworkPaths: 'list[ua.EndpointUrlListDataType]' = field(default_factory=list)


@dataclass(slots=True)
class SamplingIntervalDiagnosticsDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.8

    :ivar SamplingInterval:
    :vartype SamplingInterval: Duration
    :ivar MonitoredItemCount:
    :vartype MonitoredItemCount: UInt32
    :ivar MaxMonitoredItemCount:
    :vartype MaxMonitoredItemCount: UInt32
    :ivar DisabledMonitoredItemCount:
    :vartype DisabledMonitoredItemCount: UInt32
    """

    data_type = NodeId(ObjectIds.SamplingIntervalDiagnosticsDataType)

    SamplingInterval: 'ua.Duration' = 0
    MonitoredItemCount: 'ua.UInt32' = 0
    MaxMonitoredItemCount: 'ua.UInt32' = 0
    DisabledMonitoredItemCount: 'ua.UInt32' = 0


@dataclass(slots=True)
class ServerDiagnosticsSummaryDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.9

    :ivar ServerViewCount:
    :vartype ServerViewCount: UInt32
    :ivar CurrentSessionCount:
    :vartype CurrentSessionCount: UInt32
    :ivar CumulatedSessionCount:
    :vartype CumulatedSessionCount: UInt32
    :ivar SecurityRejectedSessionCount:
    :vartype SecurityRejectedSessionCount: UInt32
    :ivar RejectedSessionCount:
    :vartype RejectedSessionCount: UInt32
    :ivar SessionTimeoutCount:
    :vartype SessionTimeoutCount: UInt32
    :ivar SessionAbortCount:
    :vartype SessionAbortCount: UInt32
    :ivar CurrentSubscriptionCount:
    :vartype CurrentSubscriptionCount: UInt32
    :ivar CumulatedSubscriptionCount:
    :vartype CumulatedSubscriptionCount: UInt32
    :ivar PublishingIntervalCount:
    :vartype PublishingIntervalCount: UInt32
    :ivar SecurityRejectedRequestsCount:
    :vartype SecurityRejectedRequestsCount: UInt32
    :ivar RejectedRequestsCount:
    :vartype RejectedRequestsCount: UInt32
    """

    data_type = NodeId(ObjectIds.ServerDiagnosticsSummaryDataType)

    ServerViewCount: 'ua.UInt32' = 0
    CurrentSessionCount: 'ua.UInt32' = 0
    CumulatedSessionCount: 'ua.UInt32' = 0
    SecurityRejectedSessionCount: 'ua.UInt32' = 0
    RejectedSessionCount: 'ua.UInt32' = 0
    SessionTimeoutCount: 'ua.UInt32' = 0
    SessionAbortCount: 'ua.UInt32' = 0
    CurrentSubscriptionCount: 'ua.UInt32' = 0
    CumulatedSubscriptionCount: 'ua.UInt32' = 0
    PublishingIntervalCount: 'ua.UInt32' = 0
    SecurityRejectedRequestsCount: 'ua.UInt32' = 0
    RejectedRequestsCount: 'ua.UInt32' = 0


@dataclass(slots=True)
class ServerStatusDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.10

    :ivar StartTime:
    :vartype StartTime: UtcTime
    :ivar CurrentTime:
    :vartype CurrentTime: UtcTime
    :ivar State:
    :vartype State: ServerState
    :ivar BuildInfo:
    :vartype BuildInfo: BuildInfo
    :ivar SecondsTillShutdown:
    :vartype SecondsTillShutdown: UInt32
    :ivar ShutdownReason:
    :vartype ShutdownReason: LocalizedText
    """

    data_type = NodeId(ObjectIds.ServerStatusDataType)

    StartTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    CurrentTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    State: 'ua.ServerState' = field(default_factory=lambda:ServerState.Running)
    BuildInfo: 'ua.BuildInfo' = field(default_factory=lambda: BuildInfo())
    SecondsTillShutdown: 'ua.UInt32' = 0
    ShutdownReason: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class SessionSecurityDiagnosticsDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.12

    :ivar SessionId:
    :vartype SessionId: NodeId
    :ivar ClientUserIdOfSession:
    :vartype ClientUserIdOfSession: String
    :ivar ClientUserIdHistory:
    :vartype ClientUserIdHistory: String
    :ivar AuthenticationMechanism:
    :vartype AuthenticationMechanism: String
    :ivar Encoding:
    :vartype Encoding: String
    :ivar TransportProtocol:
    :vartype TransportProtocol: String
    :ivar SecurityMode:
    :vartype SecurityMode: MessageSecurityMode
    :ivar SecurityPolicyUri:
    :vartype SecurityPolicyUri: String
    :ivar ClientCertificate:
    :vartype ClientCertificate: ByteString
    """

    data_type = NodeId(ObjectIds.SessionSecurityDiagnosticsDataType)

    SessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    ClientUserIdOfSession: 'ua.String' = None
    ClientUserIdHistory: 'list[ua.String]' = field(default_factory=list)
    AuthenticationMechanism: 'ua.String' = None
    Encoding: Byte = field(default=0, repr=False, init=False, compare=False)
    TransportProtocol: 'ua.String' = None
    SecurityMode: 'ua.MessageSecurityMode' = field(default_factory=lambda:MessageSecurityMode.Invalid)
    SecurityPolicyUri: 'ua.String' = None
    ClientCertificate: 'ua.ByteString' = None


@dataclass(slots=True)
class ServiceCounterDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.13

    :ivar TotalCount:
    :vartype TotalCount: UInt32
    :ivar ErrorCount:
    :vartype ErrorCount: UInt32
    """

    data_type = NodeId(ObjectIds.ServiceCounterDataType)

    TotalCount: 'ua.UInt32' = 0
    ErrorCount: 'ua.UInt32' = 0


@dataclass(slots=True)
class SessionDiagnosticsDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.11

    :ivar SessionId:
    :vartype SessionId: NodeId
    :ivar SessionName:
    :vartype SessionName: String
    :ivar ClientDescription:
    :vartype ClientDescription: ApplicationDescription
    :ivar ServerUri:
    :vartype ServerUri: String
    :ivar EndpointUrl:
    :vartype EndpointUrl: String
    :ivar LocaleIds:
    :vartype LocaleIds: LocaleId
    :ivar ActualSessionTimeout:
    :vartype ActualSessionTimeout: Duration
    :ivar MaxResponseMessageSize:
    :vartype MaxResponseMessageSize: UInt32
    :ivar ClientConnectionTime:
    :vartype ClientConnectionTime: UtcTime
    :ivar ClientLastContactTime:
    :vartype ClientLastContactTime: UtcTime
    :ivar CurrentSubscriptionsCount:
    :vartype CurrentSubscriptionsCount: UInt32
    :ivar CurrentMonitoredItemsCount:
    :vartype CurrentMonitoredItemsCount: UInt32
    :ivar CurrentPublishRequestsInQueue:
    :vartype CurrentPublishRequestsInQueue: UInt32
    :ivar TotalRequestCount:
    :vartype TotalRequestCount: ServiceCounterDataType
    :ivar UnauthorizedRequestCount:
    :vartype UnauthorizedRequestCount: UInt32
    :ivar ReadCount:
    :vartype ReadCount: ServiceCounterDataType
    :ivar HistoryReadCount:
    :vartype HistoryReadCount: ServiceCounterDataType
    :ivar WriteCount:
    :vartype WriteCount: ServiceCounterDataType
    :ivar HistoryUpdateCount:
    :vartype HistoryUpdateCount: ServiceCounterDataType
    :ivar CallCount:
    :vartype CallCount: ServiceCounterDataType
    :ivar CreateMonitoredItemsCount:
    :vartype CreateMonitoredItemsCount: ServiceCounterDataType
    :ivar ModifyMonitoredItemsCount:
    :vartype ModifyMonitoredItemsCount: ServiceCounterDataType
    :ivar SetMonitoringModeCount:
    :vartype SetMonitoringModeCount: ServiceCounterDataType
    :ivar SetTriggeringCount:
    :vartype SetTriggeringCount: ServiceCounterDataType
    :ivar DeleteMonitoredItemsCount:
    :vartype DeleteMonitoredItemsCount: ServiceCounterDataType
    :ivar CreateSubscriptionCount:
    :vartype CreateSubscriptionCount: ServiceCounterDataType
    :ivar ModifySubscriptionCount:
    :vartype ModifySubscriptionCount: ServiceCounterDataType
    :ivar SetPublishingModeCount:
    :vartype SetPublishingModeCount: ServiceCounterDataType
    :ivar PublishCount:
    :vartype PublishCount: ServiceCounterDataType
    :ivar RepublishCount:
    :vartype RepublishCount: ServiceCounterDataType
    :ivar TransferSubscriptionsCount:
    :vartype TransferSubscriptionsCount: ServiceCounterDataType
    :ivar DeleteSubscriptionsCount:
    :vartype DeleteSubscriptionsCount: ServiceCounterDataType
    :ivar AddNodesCount:
    :vartype AddNodesCount: ServiceCounterDataType
    :ivar AddReferencesCount:
    :vartype AddReferencesCount: ServiceCounterDataType
    :ivar DeleteNodesCount:
    :vartype DeleteNodesCount: ServiceCounterDataType
    :ivar DeleteReferencesCount:
    :vartype DeleteReferencesCount: ServiceCounterDataType
    :ivar BrowseCount:
    :vartype BrowseCount: ServiceCounterDataType
    :ivar BrowseNextCount:
    :vartype BrowseNextCount: ServiceCounterDataType
    :ivar TranslateBrowsePathsToNodeIdsCount:
    :vartype TranslateBrowsePathsToNodeIdsCount: ServiceCounterDataType
    :ivar QueryFirstCount:
    :vartype QueryFirstCount: ServiceCounterDataType
    :ivar QueryNextCount:
    :vartype QueryNextCount: ServiceCounterDataType
    :ivar RegisterNodesCount:
    :vartype RegisterNodesCount: ServiceCounterDataType
    :ivar UnregisterNodesCount:
    :vartype UnregisterNodesCount: ServiceCounterDataType
    """

    data_type = NodeId(ObjectIds.SessionDiagnosticsDataType)

    SessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    SessionName: 'ua.String' = None
    ClientDescription: 'ua.ApplicationDescription' = field(default_factory=lambda: ApplicationDescription())
    ServerUri: 'ua.String' = None
    EndpointUrl: 'ua.String' = None
    LocaleIds: 'list[ua.LocaleId]' = field(default_factory=list)
    ActualSessionTimeout: 'ua.Duration' = 0
    MaxResponseMessageSize: 'ua.UInt32' = 0
    ClientConnectionTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    ClientLastContactTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    CurrentSubscriptionsCount: 'ua.UInt32' = 0
    CurrentMonitoredItemsCount: 'ua.UInt32' = 0
    CurrentPublishRequestsInQueue: 'ua.UInt32' = 0
    TotalRequestCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    UnauthorizedRequestCount: 'ua.UInt32' = 0
    ReadCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    HistoryReadCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    WriteCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    HistoryUpdateCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    CallCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    CreateMonitoredItemsCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    ModifyMonitoredItemsCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    SetMonitoringModeCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    SetTriggeringCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    DeleteMonitoredItemsCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    CreateSubscriptionCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    ModifySubscriptionCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    SetPublishingModeCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    PublishCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    RepublishCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    TransferSubscriptionsCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    DeleteSubscriptionsCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    AddNodesCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    AddReferencesCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    DeleteNodesCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    DeleteReferencesCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    BrowseCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    BrowseNextCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    TranslateBrowsePathsToNodeIdsCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    QueryFirstCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    QueryNextCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    RegisterNodesCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())
    UnregisterNodesCount: 'ua.ServiceCounterDataType' = field(default_factory=lambda: ServiceCounterDataType())


@dataclass(slots=True)
class StatusResult:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.14

    :ivar StatusCode:
    :vartype StatusCode: StatusCode
    :ivar DiagnosticInfo:
    :vartype DiagnosticInfo: DiagnosticInfo
    """

    data_type = NodeId(ObjectIds.StatusResult)

    StatusCode: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())
    DiagnosticInfo: 'ua.DiagnosticInfo' = field(default_factory=lambda: DiagnosticInfo())


@dataclass(slots=True)
class SubscriptionDiagnosticsDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.15

    :ivar SessionId:
    :vartype SessionId: NodeId
    :ivar SubscriptionId:
    :vartype SubscriptionId: UInt32
    :ivar Priority:
    :vartype Priority: Byte
    :ivar PublishingInterval:
    :vartype PublishingInterval: Duration
    :ivar MaxKeepAliveCount:
    :vartype MaxKeepAliveCount: UInt32
    :ivar MaxLifetimeCount:
    :vartype MaxLifetimeCount: UInt32
    :ivar MaxNotificationsPerPublish:
    :vartype MaxNotificationsPerPublish: UInt32
    :ivar PublishingEnabled:
    :vartype PublishingEnabled: Boolean
    :ivar ModifyCount:
    :vartype ModifyCount: UInt32
    :ivar EnableCount:
    :vartype EnableCount: UInt32
    :ivar DisableCount:
    :vartype DisableCount: UInt32
    :ivar RepublishRequestCount:
    :vartype RepublishRequestCount: UInt32
    :ivar RepublishMessageRequestCount:
    :vartype RepublishMessageRequestCount: UInt32
    :ivar RepublishMessageCount:
    :vartype RepublishMessageCount: UInt32
    :ivar TransferRequestCount:
    :vartype TransferRequestCount: UInt32
    :ivar TransferredToAltClientCount:
    :vartype TransferredToAltClientCount: UInt32
    :ivar TransferredToSameClientCount:
    :vartype TransferredToSameClientCount: UInt32
    :ivar PublishRequestCount:
    :vartype PublishRequestCount: UInt32
    :ivar DataChangeNotificationsCount:
    :vartype DataChangeNotificationsCount: UInt32
    :ivar EventNotificationsCount:
    :vartype EventNotificationsCount: UInt32
    :ivar NotificationsCount:
    :vartype NotificationsCount: UInt32
    :ivar LatePublishRequestCount:
    :vartype LatePublishRequestCount: UInt32
    :ivar CurrentKeepAliveCount:
    :vartype CurrentKeepAliveCount: UInt32
    :ivar CurrentLifetimeCount:
    :vartype CurrentLifetimeCount: UInt32
    :ivar UnacknowledgedMessageCount:
    :vartype UnacknowledgedMessageCount: UInt32
    :ivar DiscardedMessageCount:
    :vartype DiscardedMessageCount: UInt32
    :ivar MonitoredItemCount:
    :vartype MonitoredItemCount: UInt32
    :ivar DisabledMonitoredItemCount:
    :vartype DisabledMonitoredItemCount: UInt32
    :ivar MonitoringQueueOverflowCount:
    :vartype MonitoringQueueOverflowCount: UInt32
    :ivar NextSequenceNumber:
    :vartype NextSequenceNumber: UInt32
    :ivar EventQueueOverflowCount:
    :vartype EventQueueOverflowCount: UInt32
    """

    data_type = NodeId(ObjectIds.SubscriptionDiagnosticsDataType)

    SessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    SubscriptionId: 'ua.UInt32' = 0
    Priority: 'ua.Byte' = 0
    PublishingInterval: 'ua.Duration' = 0
    MaxKeepAliveCount: 'ua.UInt32' = 0
    MaxLifetimeCount: 'ua.UInt32' = 0
    MaxNotificationsPerPublish: 'ua.UInt32' = 0
    PublishingEnabled: 'ua.Boolean' = True
    ModifyCount: 'ua.UInt32' = 0
    EnableCount: 'ua.UInt32' = 0
    DisableCount: 'ua.UInt32' = 0
    RepublishRequestCount: 'ua.UInt32' = 0
    RepublishMessageRequestCount: 'ua.UInt32' = 0
    RepublishMessageCount: 'ua.UInt32' = 0
    TransferRequestCount: 'ua.UInt32' = 0
    TransferredToAltClientCount: 'ua.UInt32' = 0
    TransferredToSameClientCount: 'ua.UInt32' = 0
    PublishRequestCount: 'ua.UInt32' = 0
    DataChangeNotificationsCount: 'ua.UInt32' = 0
    EventNotificationsCount: 'ua.UInt32' = 0
    NotificationsCount: 'ua.UInt32' = 0
    LatePublishRequestCount: 'ua.UInt32' = 0
    CurrentKeepAliveCount: 'ua.UInt32' = 0
    CurrentLifetimeCount: 'ua.UInt32' = 0
    UnacknowledgedMessageCount: 'ua.UInt32' = 0
    DiscardedMessageCount: 'ua.UInt32' = 0
    MonitoredItemCount: 'ua.UInt32' = 0
    DisabledMonitoredItemCount: 'ua.UInt32' = 0
    MonitoringQueueOverflowCount: 'ua.UInt32' = 0
    NextSequenceNumber: 'ua.UInt32' = 0
    EventQueueOverflowCount: 'ua.UInt32' = 0


@dataclass(slots=True)
class ModelChangeStructureDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.16

    :ivar Affected:
    :vartype Affected: NodeId
    :ivar AffectedType:
    :vartype AffectedType: NodeId
    :ivar Verb:
    :vartype Verb: Byte
    """

    data_type = NodeId(ObjectIds.ModelChangeStructureDataType)

    Affected: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AffectedType: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    Verb: 'ua.Byte' = 0


@dataclass(slots=True)
class SemanticChangeStructureDataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part5/12.17

    :ivar Affected:
    :vartype Affected: NodeId
    :ivar AffectedType:
    :vartype AffectedType: NodeId
    """

    data_type = NodeId(ObjectIds.SemanticChangeStructureDataType)

    Affected: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    AffectedType: 'ua.NodeId' = field(default_factory=lambda: NodeId())


@dataclass(slots=True)
class Range:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.2

    :ivar Low:
    :vartype Low: Double
    :ivar High:
    :vartype High: Double
    """

    data_type = NodeId(ObjectIds.Range)

    Low: 'ua.Double' = 0
    High: 'ua.Double' = 0


@dataclass(slots=True)
class EUInformation:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.4/#5.6.4.3

    :ivar NamespaceUri:
    :vartype NamespaceUri: String
    :ivar UnitId:
    :vartype UnitId: Int32
    :ivar DisplayName:
    :vartype DisplayName: LocalizedText
    :ivar Description:
    :vartype Description: LocalizedText
    """

    data_type = NodeId(ObjectIds.EUInformation)

    NamespaceUri: 'ua.String' = None
    UnitId: 'ua.Int32' = 0
    DisplayName: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    Description: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())


@dataclass(slots=True)
class ComplexNumberType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.5

    :ivar Real:
    :vartype Real: Float
    :ivar Imaginary:
    :vartype Imaginary: Float
    """

    data_type = NodeId(ObjectIds.ComplexNumberType)

    Real: 'ua.Float' = 0
    Imaginary: 'ua.Float' = 0


@dataclass(slots=True)
class DoubleComplexNumberType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.6

    :ivar Real:
    :vartype Real: Double
    :ivar Imaginary:
    :vartype Imaginary: Double
    """

    data_type = NodeId(ObjectIds.DoubleComplexNumberType)

    Real: 'ua.Double' = 0
    Imaginary: 'ua.Double' = 0


@dataclass(slots=True)
class AxisInformation:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.7

    :ivar EngineeringUnits:
    :vartype EngineeringUnits: EUInformation
    :ivar EURange:
    :vartype EURange: Range
    :ivar Title:
    :vartype Title: LocalizedText
    :ivar AxisScaleType:
    :vartype AxisScaleType: AxisScaleEnumeration
    :ivar AxisSteps:
    :vartype AxisSteps: Double
    """

    data_type = NodeId(ObjectIds.AxisInformation)

    EngineeringUnits: 'ua.EUInformation' = field(default_factory=lambda: EUInformation())
    EURange: 'ua.Range' = field(default_factory=lambda: Range())
    Title: 'ua.LocalizedText' = field(default_factory=lambda: LocalizedText())
    AxisScaleType: 'ua.AxisScaleEnumeration' = field(default_factory=lambda:AxisScaleEnumeration.Linear)
    AxisSteps: 'list[ua.Double]' = field(default_factory=list)


@dataclass(slots=True)
class XVType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part8/5.6.9

    :ivar X:
    :vartype X: Double
    :ivar Value:
    :vartype Value: Float
    """

    data_type = NodeId(ObjectIds.XVType)

    X: 'ua.Double' = 0
    Value: 'ua.Float' = 0


@dataclass(slots=True)
class ProgramDiagnosticDataType:
    """
    :ivar CreateSessionId:
    :vartype CreateSessionId: NodeId
    :ivar CreateClientName:
    :vartype CreateClientName: String
    :ivar InvocationCreationTime:
    :vartype InvocationCreationTime: UtcTime
    :ivar LastTransitionTime:
    :vartype LastTransitionTime: UtcTime
    :ivar LastMethodCall:
    :vartype LastMethodCall: String
    :ivar LastMethodSessionId:
    :vartype LastMethodSessionId: NodeId
    :ivar LastMethodInputArguments:
    :vartype LastMethodInputArguments: Argument
    :ivar LastMethodOutputArguments:
    :vartype LastMethodOutputArguments: Argument
    :ivar LastMethodCallTime:
    :vartype LastMethodCallTime: UtcTime
    :ivar LastMethodReturnStatus:
    :vartype LastMethodReturnStatus: StatusResult
    """

    data_type = NodeId(ObjectIds.ProgramDiagnosticDataType)

    CreateSessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    CreateClientName: 'ua.String' = None
    InvocationCreationTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    LastTransitionTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    LastMethodCall: 'ua.String' = None
    LastMethodSessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    LastMethodInputArguments: 'list[ua.Argument]' = field(default_factory=list)
    LastMethodOutputArguments: 'list[ua.Argument]' = field(default_factory=list)
    LastMethodCallTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    LastMethodReturnStatus: 'ua.StatusResult' = field(default_factory=lambda: StatusResult())


@dataclass(slots=True)
class ProgramDiagnostic2DataType:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part10/5.2.8

    :ivar CreateSessionId:
    :vartype CreateSessionId: NodeId
    :ivar CreateClientName:
    :vartype CreateClientName: String
    :ivar InvocationCreationTime:
    :vartype InvocationCreationTime: UtcTime
    :ivar LastTransitionTime:
    :vartype LastTransitionTime: UtcTime
    :ivar LastMethodCall:
    :vartype LastMethodCall: String
    :ivar LastMethodSessionId:
    :vartype LastMethodSessionId: NodeId
    :ivar LastMethodInputArguments:
    :vartype LastMethodInputArguments: Argument
    :ivar LastMethodOutputArguments:
    :vartype LastMethodOutputArguments: Argument
    :ivar LastMethodInputValues:
    :vartype LastMethodInputValues: Variant
    :ivar LastMethodOutputValues:
    :vartype LastMethodOutputValues: Variant
    :ivar LastMethodCallTime:
    :vartype LastMethodCallTime: UtcTime
    :ivar LastMethodReturnStatus:
    :vartype LastMethodReturnStatus: StatusCode
    """

    data_type = NodeId(ObjectIds.ProgramDiagnostic2DataType)

    CreateSessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    CreateClientName: 'ua.String' = None
    InvocationCreationTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    LastTransitionTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    LastMethodCall: 'ua.String' = None
    LastMethodSessionId: 'ua.NodeId' = field(default_factory=lambda: NodeId())
    LastMethodInputArguments: 'list[ua.Argument]' = field(default_factory=list)
    LastMethodOutputArguments: 'list[ua.Argument]' = field(default_factory=list)
    LastMethodInputValues: 'list[ua.Variant]' = field(default_factory=list)
    LastMethodOutputValues: 'list[ua.Variant]' = field(default_factory=list)
    LastMethodCallTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))
    LastMethodReturnStatus: 'ua.StatusCode' = field(default_factory=lambda: StatusCode())


@dataclass(slots=True)
class Annotation:
    """
    https://reference.opcfoundation.org/v105/Core/docs/Part11/6.6.6

    :ivar Message:
    :vartype Message: String
    :ivar UserName:
    :vartype UserName: String
    :ivar AnnotationTime:
    :vartype AnnotationTime: UtcTime
    """

    data_type = NodeId(ObjectIds.Annotation)

    Message: 'ua.String' = None
    UserName: 'ua.String' = None
    AnnotationTime: 'ua.UtcTime' = field(default_factory=lambda: datetime.now(timezone.utc))


nid = FourByteNodeId(ObjectIds.Union_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Union
typeid_by_extension_objects[Union] = nid
nid = FourByteNodeId(ObjectIds.KeyValuePair_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = KeyValuePair
typeid_by_extension_objects[KeyValuePair] = nid
nid = FourByteNodeId(ObjectIds.AdditionalParametersType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AdditionalParametersType
typeid_by_extension_objects[AdditionalParametersType] = nid
nid = FourByteNodeId(ObjectIds.EphemeralKeyType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EphemeralKeyType
typeid_by_extension_objects[EphemeralKeyType] = nid
nid = FourByteNodeId(ObjectIds.EndpointType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EndpointType
typeid_by_extension_objects[EndpointType] = nid
nid = FourByteNodeId(ObjectIds.BitFieldDefinition_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BitFieldDefinition
typeid_by_extension_objects[BitFieldDefinition] = nid
nid = FourByteNodeId(ObjectIds.RationalNumber_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RationalNumber
typeid_by_extension_objects[RationalNumber] = nid
nid = FourByteNodeId(ObjectIds.Vector_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Vector
typeid_by_extension_objects[Vector] = nid
nid = FourByteNodeId(ObjectIds.ThreeDVector_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ThreeDVector
typeid_by_extension_objects[ThreeDVector] = nid
nid = FourByteNodeId(ObjectIds.CartesianCoordinates_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CartesianCoordinates
typeid_by_extension_objects[CartesianCoordinates] = nid
nid = FourByteNodeId(ObjectIds.ThreeDCartesianCoordinates_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ThreeDCartesianCoordinates
typeid_by_extension_objects[ThreeDCartesianCoordinates] = nid
nid = FourByteNodeId(ObjectIds.Orientation_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Orientation
typeid_by_extension_objects[Orientation] = nid
nid = FourByteNodeId(ObjectIds.ThreeDOrientation_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ThreeDOrientation
typeid_by_extension_objects[ThreeDOrientation] = nid
nid = FourByteNodeId(ObjectIds.Frame_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Frame
typeid_by_extension_objects[Frame] = nid
nid = FourByteNodeId(ObjectIds.ThreeDFrame_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ThreeDFrame
typeid_by_extension_objects[ThreeDFrame] = nid
nid = FourByteNodeId(ObjectIds.IdentityMappingRuleType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = IdentityMappingRuleType
typeid_by_extension_objects[IdentityMappingRuleType] = nid
nid = FourByteNodeId(ObjectIds.CurrencyUnitType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CurrencyUnitType
typeid_by_extension_objects[CurrencyUnitType] = nid
nid = FourByteNodeId(ObjectIds.AnnotationDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AnnotationDataType
typeid_by_extension_objects[AnnotationDataType] = nid
nid = FourByteNodeId(ObjectIds.LinearConversionDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LinearConversionDataType
typeid_by_extension_objects[LinearConversionDataType] = nid
nid = FourByteNodeId(ObjectIds.QuantityDimension_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QuantityDimension
typeid_by_extension_objects[QuantityDimension] = nid
nid = FourByteNodeId(ObjectIds.TrustListDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TrustListDataType
typeid_by_extension_objects[TrustListDataType] = nid
nid = FourByteNodeId(ObjectIds.BaseConfigurationDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BaseConfigurationDataType
typeid_by_extension_objects[BaseConfigurationDataType] = nid
nid = FourByteNodeId(ObjectIds.BaseConfigurationRecordDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BaseConfigurationRecordDataType
typeid_by_extension_objects[BaseConfigurationRecordDataType] = nid
nid = FourByteNodeId(ObjectIds.CertificateGroupDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CertificateGroupDataType
typeid_by_extension_objects[CertificateGroupDataType] = nid
nid = FourByteNodeId(ObjectIds.ConfigurationUpdateTargetType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ConfigurationUpdateTargetType
typeid_by_extension_objects[ConfigurationUpdateTargetType] = nid
nid = FourByteNodeId(ObjectIds.TransactionErrorType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TransactionErrorType
typeid_by_extension_objects[TransactionErrorType] = nid
nid = FourByteNodeId(ObjectIds.EndpointDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EndpointDataType
typeid_by_extension_objects[EndpointDataType] = nid
nid = FourByteNodeId(ObjectIds.ServerEndpointDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServerEndpointDataType
typeid_by_extension_objects[ServerEndpointDataType] = nid
nid = FourByteNodeId(ObjectIds.SecuritySettingsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SecuritySettingsDataType
typeid_by_extension_objects[SecuritySettingsDataType] = nid
nid = FourByteNodeId(ObjectIds.UserTokenSettingsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UserTokenSettingsDataType
typeid_by_extension_objects[UserTokenSettingsDataType] = nid
nid = FourByteNodeId(ObjectIds.ServiceCertificateDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServiceCertificateDataType
typeid_by_extension_objects[ServiceCertificateDataType] = nid
nid = FourByteNodeId(ObjectIds.AuthorizationServiceConfigurationDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AuthorizationServiceConfigurationDataType
typeid_by_extension_objects[AuthorizationServiceConfigurationDataType] = nid
nid = FourByteNodeId(ObjectIds.DecimalDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DecimalDataType
typeid_by_extension_objects[DecimalDataType] = nid
nid = FourByteNodeId(ObjectIds.DataTypeDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataTypeDescription
typeid_by_extension_objects[DataTypeDescription] = nid
nid = FourByteNodeId(ObjectIds.SimpleTypeDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SimpleTypeDescription
typeid_by_extension_objects[SimpleTypeDescription] = nid
nid = FourByteNodeId(ObjectIds.PortableQualifiedName_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PortableQualifiedName
typeid_by_extension_objects[PortableQualifiedName] = nid
nid = FourByteNodeId(ObjectIds.UnsignedRationalNumber_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UnsignedRationalNumber
typeid_by_extension_objects[UnsignedRationalNumber] = nid
nid = FourByteNodeId(ObjectIds.FieldMetaData_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FieldMetaData
typeid_by_extension_objects[FieldMetaData] = nid
nid = FourByteNodeId(ObjectIds.ConfigurationVersionDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ConfigurationVersionDataType
typeid_by_extension_objects[ConfigurationVersionDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedDataSetSourceDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedDataSetSourceDataType
typeid_by_extension_objects[PublishedDataSetSourceDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedVariableDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedVariableDataType
typeid_by_extension_objects[PublishedVariableDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedDataItemsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedDataItemsDataType
typeid_by_extension_objects[PublishedDataItemsDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedDataSetCustomSourceDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedDataSetCustomSourceDataType
typeid_by_extension_objects[PublishedDataSetCustomSourceDataType] = nid
nid = FourByteNodeId(ObjectIds.ActionTargetDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ActionTargetDataType
typeid_by_extension_objects[ActionTargetDataType] = nid
nid = FourByteNodeId(ObjectIds.ActionMethodDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ActionMethodDataType
typeid_by_extension_objects[ActionMethodDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetWriterTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetWriterTransportDataType
typeid_by_extension_objects[DataSetWriterTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetWriterMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetWriterMessageDataType
typeid_by_extension_objects[DataSetWriterMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetWriterDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetWriterDataType
typeid_by_extension_objects[DataSetWriterDataType] = nid
nid = FourByteNodeId(ObjectIds.WriterGroupTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = WriterGroupTransportDataType
typeid_by_extension_objects[WriterGroupTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.WriterGroupMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = WriterGroupMessageDataType
typeid_by_extension_objects[WriterGroupMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.ConnectionTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ConnectionTransportDataType
typeid_by_extension_objects[ConnectionTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.NetworkAddressDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NetworkAddressDataType
typeid_by_extension_objects[NetworkAddressDataType] = nid
nid = FourByteNodeId(ObjectIds.NetworkAddressUrlDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NetworkAddressUrlDataType
typeid_by_extension_objects[NetworkAddressUrlDataType] = nid
nid = FourByteNodeId(ObjectIds.ReaderGroupTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReaderGroupTransportDataType
typeid_by_extension_objects[ReaderGroupTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.ReaderGroupMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReaderGroupMessageDataType
typeid_by_extension_objects[ReaderGroupMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetReaderTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetReaderTransportDataType
typeid_by_extension_objects[DataSetReaderTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetReaderMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetReaderMessageDataType
typeid_by_extension_objects[DataSetReaderMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.SubscribedDataSetDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SubscribedDataSetDataType
typeid_by_extension_objects[SubscribedDataSetDataType] = nid
nid = FourByteNodeId(ObjectIds.FieldTargetDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FieldTargetDataType
typeid_by_extension_objects[FieldTargetDataType] = nid
nid = FourByteNodeId(ObjectIds.TargetVariablesDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TargetVariablesDataType
typeid_by_extension_objects[TargetVariablesDataType] = nid
nid = FourByteNodeId(ObjectIds.StandaloneSubscribedDataSetRefDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StandaloneSubscribedDataSetRefDataType
typeid_by_extension_objects[StandaloneSubscribedDataSetRefDataType] = nid
nid = FourByteNodeId(ObjectIds.UadpWriterGroupMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UadpWriterGroupMessageDataType
typeid_by_extension_objects[UadpWriterGroupMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.UadpDataSetWriterMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UadpDataSetWriterMessageDataType
typeid_by_extension_objects[UadpDataSetWriterMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.UadpDataSetReaderMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UadpDataSetReaderMessageDataType
typeid_by_extension_objects[UadpDataSetReaderMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.JsonWriterGroupMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = JsonWriterGroupMessageDataType
typeid_by_extension_objects[JsonWriterGroupMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.JsonDataSetWriterMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = JsonDataSetWriterMessageDataType
typeid_by_extension_objects[JsonDataSetWriterMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.JsonDataSetReaderMessageDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = JsonDataSetReaderMessageDataType
typeid_by_extension_objects[JsonDataSetReaderMessageDataType] = nid
nid = FourByteNodeId(ObjectIds.QosDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QosDataType
typeid_by_extension_objects[QosDataType] = nid
nid = FourByteNodeId(ObjectIds.TransmitQosDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TransmitQosDataType
typeid_by_extension_objects[TransmitQosDataType] = nid
nid = FourByteNodeId(ObjectIds.TransmitQosPriorityDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TransmitQosPriorityDataType
typeid_by_extension_objects[TransmitQosPriorityDataType] = nid
nid = FourByteNodeId(ObjectIds.ReceiveQosDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReceiveQosDataType
typeid_by_extension_objects[ReceiveQosDataType] = nid
nid = FourByteNodeId(ObjectIds.ReceiveQosPriorityDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReceiveQosPriorityDataType
typeid_by_extension_objects[ReceiveQosPriorityDataType] = nid
nid = FourByteNodeId(ObjectIds.DatagramConnectionTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DatagramConnectionTransportDataType
typeid_by_extension_objects[DatagramConnectionTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.DatagramConnectionTransport2DataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DatagramConnectionTransport2DataType
typeid_by_extension_objects[DatagramConnectionTransport2DataType] = nid
nid = FourByteNodeId(ObjectIds.DatagramWriterGroupTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DatagramWriterGroupTransportDataType
typeid_by_extension_objects[DatagramWriterGroupTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.DatagramWriterGroupTransport2DataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DatagramWriterGroupTransport2DataType
typeid_by_extension_objects[DatagramWriterGroupTransport2DataType] = nid
nid = FourByteNodeId(ObjectIds.DatagramDataSetReaderTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DatagramDataSetReaderTransportDataType
typeid_by_extension_objects[DatagramDataSetReaderTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.DtlsPubSubConnectionDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DtlsPubSubConnectionDataType
typeid_by_extension_objects[DtlsPubSubConnectionDataType] = nid
nid = FourByteNodeId(ObjectIds.BrokerConnectionTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrokerConnectionTransportDataType
typeid_by_extension_objects[BrokerConnectionTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.BrokerWriterGroupTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrokerWriterGroupTransportDataType
typeid_by_extension_objects[BrokerWriterGroupTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.BrokerDataSetWriterTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrokerDataSetWriterTransportDataType
typeid_by_extension_objects[BrokerDataSetWriterTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.BrokerDataSetReaderTransportDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrokerDataSetReaderTransportDataType
typeid_by_extension_objects[BrokerDataSetReaderTransportDataType] = nid
nid = FourByteNodeId(ObjectIds.PubSubConfigurationRefDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubConfigurationRefDataType
typeid_by_extension_objects[PubSubConfigurationRefDataType] = nid
nid = FourByteNodeId(ObjectIds.PubSubConfigurationValueDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubConfigurationValueDataType
typeid_by_extension_objects[PubSubConfigurationValueDataType] = nid
nid = FourByteNodeId(ObjectIds.AliasNameDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AliasNameDataType
typeid_by_extension_objects[AliasNameDataType] = nid
nid = FourByteNodeId(ObjectIds.AliasNameVerboseDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AliasNameVerboseDataType
typeid_by_extension_objects[AliasNameVerboseDataType] = nid
nid = FourByteNodeId(ObjectIds.AliasCategoryUpdateDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AliasCategoryUpdateDataType
typeid_by_extension_objects[AliasCategoryUpdateDataType] = nid
nid = FourByteNodeId(ObjectIds.AliasUpdateDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AliasUpdateDataType
typeid_by_extension_objects[AliasUpdateDataType] = nid
nid = FourByteNodeId(ObjectIds.UserManagementDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UserManagementDataType
typeid_by_extension_objects[UserManagementDataType] = nid
nid = FourByteNodeId(ObjectIds.PriorityMappingEntryType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PriorityMappingEntryType
typeid_by_extension_objects[PriorityMappingEntryType] = nid
nid = FourByteNodeId(ObjectIds.LldpManagementAddressTxPortType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LldpManagementAddressTxPortType
typeid_by_extension_objects[LldpManagementAddressTxPortType] = nid
nid = FourByteNodeId(ObjectIds.LldpManagementAddressType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LldpManagementAddressType
typeid_by_extension_objects[LldpManagementAddressType] = nid
nid = FourByteNodeId(ObjectIds.LldpTlvType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LldpTlvType
typeid_by_extension_objects[LldpTlvType] = nid
nid = FourByteNodeId(ObjectIds.ReferenceDescriptionDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReferenceDescriptionDataType
typeid_by_extension_objects[ReferenceDescriptionDataType] = nid
nid = FourByteNodeId(ObjectIds.ReferenceListEntryDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReferenceListEntryDataType
typeid_by_extension_objects[ReferenceListEntryDataType] = nid
nid = FourByteNodeId(ObjectIds.SpanContextDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SpanContextDataType
typeid_by_extension_objects[SpanContextDataType] = nid
nid = FourByteNodeId(ObjectIds.TraceContextDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TraceContextDataType
typeid_by_extension_objects[TraceContextDataType] = nid
nid = FourByteNodeId(ObjectIds.NameValuePair_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NameValuePair
typeid_by_extension_objects[NameValuePair] = nid
nid = FourByteNodeId(ObjectIds.LogRecord_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LogRecord
typeid_by_extension_objects[LogRecord] = nid
nid = FourByteNodeId(ObjectIds.LogRecordsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LogRecordsDataType
typeid_by_extension_objects[LogRecordsDataType] = nid
nid = FourByteNodeId(ObjectIds.RolePermissionType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RolePermissionType
typeid_by_extension_objects[RolePermissionType] = nid
nid = FourByteNodeId(ObjectIds.SubscribedDataSetMirrorDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SubscribedDataSetMirrorDataType
typeid_by_extension_objects[SubscribedDataSetMirrorDataType] = nid
nid = FourByteNodeId(ObjectIds.SecurityGroupDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SecurityGroupDataType
typeid_by_extension_objects[SecurityGroupDataType] = nid
nid = FourByteNodeId(ObjectIds.DataTypeDefinition_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataTypeDefinition
typeid_by_extension_objects[DataTypeDefinition] = nid
nid = FourByteNodeId(ObjectIds.StructureField_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StructureField
typeid_by_extension_objects[StructureField] = nid
nid = FourByteNodeId(ObjectIds.StructureDefinition_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StructureDefinition
typeid_by_extension_objects[StructureDefinition] = nid
nid = FourByteNodeId(ObjectIds.StructureDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StructureDescription
typeid_by_extension_objects[StructureDescription] = nid
nid = FourByteNodeId(ObjectIds.Argument_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Argument
typeid_by_extension_objects[Argument] = nid
nid = FourByteNodeId(ObjectIds.EnumValueType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EnumValueType
typeid_by_extension_objects[EnumValueType] = nid
nid = FourByteNodeId(ObjectIds.EnumField_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EnumField
typeid_by_extension_objects[EnumField] = nid
nid = FourByteNodeId(ObjectIds.EnumDefinition_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EnumDefinition
typeid_by_extension_objects[EnumDefinition] = nid
nid = FourByteNodeId(ObjectIds.EnumDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EnumDescription
typeid_by_extension_objects[EnumDescription] = nid
nid = FourByteNodeId(ObjectIds.DataTypeSchemaHeader_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataTypeSchemaHeader
typeid_by_extension_objects[DataTypeSchemaHeader] = nid
nid = FourByteNodeId(ObjectIds.UABinaryFileDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UABinaryFileDataType
typeid_by_extension_objects[UABinaryFileDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetMetaDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetMetaDataType
typeid_by_extension_objects[DataSetMetaDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedDataSetDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedDataSetDataType
typeid_by_extension_objects[PublishedDataSetDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedActionDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedActionDataType
typeid_by_extension_objects[PublishedActionDataType] = nid
nid = FourByteNodeId(ObjectIds.PublishedActionMethodDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedActionMethodDataType
typeid_by_extension_objects[PublishedActionMethodDataType] = nid
nid = FourByteNodeId(ObjectIds.StandaloneSubscribedDataSetDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StandaloneSubscribedDataSetDataType
typeid_by_extension_objects[StandaloneSubscribedDataSetDataType] = nid
nid = FourByteNodeId(ObjectIds.OptionSet_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = OptionSet
typeid_by_extension_objects[OptionSet] = nid
nid = FourByteNodeId(ObjectIds.TimeZoneDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TimeZoneDataType
typeid_by_extension_objects[TimeZoneDataType] = nid
nid = FourByteNodeId(ObjectIds.ApplicationDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ApplicationDescription
typeid_by_extension_objects[ApplicationDescription] = nid
nid = FourByteNodeId(ObjectIds.ApplicationIdentityDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ApplicationIdentityDataType
typeid_by_extension_objects[ApplicationIdentityDataType] = nid
nid = FourByteNodeId(ObjectIds.ApplicationConfigurationDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ApplicationConfigurationDataType
typeid_by_extension_objects[ApplicationConfigurationDataType] = nid
nid = FourByteNodeId(ObjectIds.RequestHeader_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RequestHeader
typeid_by_extension_objects[RequestHeader] = nid
nid = FourByteNodeId(ObjectIds.ResponseHeader_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ResponseHeader
typeid_by_extension_objects[ResponseHeader] = nid
nid = FourByteNodeId(ObjectIds.ServiceFault_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServiceFault
typeid_by_extension_objects[ServiceFault] = nid
nid = FourByteNodeId(ObjectIds.SessionlessInvokeRequestType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SessionlessInvokeRequestType
typeid_by_extension_objects[SessionlessInvokeRequestType] = nid
nid = FourByteNodeId(ObjectIds.SessionlessInvokeResponseType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SessionlessInvokeResponseType
typeid_by_extension_objects[SessionlessInvokeResponseType] = nid
nid = FourByteNodeId(ObjectIds.FindServersRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FindServersRequest
typeid_by_extension_objects[FindServersRequest] = nid
nid = FourByteNodeId(ObjectIds.FindServersResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FindServersResponse
typeid_by_extension_objects[FindServersResponse] = nid
nid = FourByteNodeId(ObjectIds.ServerOnNetwork_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServerOnNetwork
typeid_by_extension_objects[ServerOnNetwork] = nid
nid = FourByteNodeId(ObjectIds.FindServersOnNetworkRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FindServersOnNetworkRequest
typeid_by_extension_objects[FindServersOnNetworkRequest] = nid
nid = FourByteNodeId(ObjectIds.FindServersOnNetworkResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FindServersOnNetworkResponse
typeid_by_extension_objects[FindServersOnNetworkResponse] = nid
nid = FourByteNodeId(ObjectIds.UserTokenPolicy_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UserTokenPolicy
typeid_by_extension_objects[UserTokenPolicy] = nid
nid = FourByteNodeId(ObjectIds.PubSubKeyPushTargetDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubKeyPushTargetDataType
typeid_by_extension_objects[PubSubKeyPushTargetDataType] = nid
nid = FourByteNodeId(ObjectIds.EndpointDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EndpointDescription
typeid_by_extension_objects[EndpointDescription] = nid
nid = FourByteNodeId(ObjectIds.PubSubGroupDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubGroupDataType
typeid_by_extension_objects[PubSubGroupDataType] = nid
nid = FourByteNodeId(ObjectIds.WriterGroupDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = WriterGroupDataType
typeid_by_extension_objects[WriterGroupDataType] = nid
nid = FourByteNodeId(ObjectIds.DataSetReaderDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataSetReaderDataType
typeid_by_extension_objects[DataSetReaderDataType] = nid
nid = FourByteNodeId(ObjectIds.ReaderGroupDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReaderGroupDataType
typeid_by_extension_objects[ReaderGroupDataType] = nid
nid = FourByteNodeId(ObjectIds.PubSubConnectionDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubConnectionDataType
typeid_by_extension_objects[PubSubConnectionDataType] = nid
nid = FourByteNodeId(ObjectIds.PubSubConfigurationDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubConfigurationDataType
typeid_by_extension_objects[PubSubConfigurationDataType] = nid
nid = FourByteNodeId(ObjectIds.PubSubConfiguration2DataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PubSubConfiguration2DataType
typeid_by_extension_objects[PubSubConfiguration2DataType] = nid
nid = FourByteNodeId(ObjectIds.GetEndpointsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = GetEndpointsRequest
typeid_by_extension_objects[GetEndpointsRequest] = nid
nid = FourByteNodeId(ObjectIds.GetEndpointsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = GetEndpointsResponse
typeid_by_extension_objects[GetEndpointsResponse] = nid
nid = FourByteNodeId(ObjectIds.RegisteredServer_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisteredServer
typeid_by_extension_objects[RegisteredServer] = nid
nid = FourByteNodeId(ObjectIds.RegisterServerRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisterServerRequest
typeid_by_extension_objects[RegisterServerRequest] = nid
nid = FourByteNodeId(ObjectIds.RegisterServerResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisterServerResponse
typeid_by_extension_objects[RegisterServerResponse] = nid
nid = FourByteNodeId(ObjectIds.DiscoveryConfiguration_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DiscoveryConfiguration
typeid_by_extension_objects[DiscoveryConfiguration] = nid
nid = FourByteNodeId(ObjectIds.MdnsDiscoveryConfiguration_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MdnsDiscoveryConfiguration
typeid_by_extension_objects[MdnsDiscoveryConfiguration] = nid
nid = FourByteNodeId(ObjectIds.RegisterServer2Request_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisterServer2Request
typeid_by_extension_objects[RegisterServer2Request] = nid
nid = FourByteNodeId(ObjectIds.RegisterServer2Response_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisterServer2Response
typeid_by_extension_objects[RegisterServer2Response] = nid
nid = FourByteNodeId(ObjectIds.ChannelSecurityToken_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ChannelSecurityToken
typeid_by_extension_objects[ChannelSecurityToken] = nid
nid = FourByteNodeId(ObjectIds.OpenSecureChannelRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = OpenSecureChannelRequest
typeid_by_extension_objects[OpenSecureChannelRequest] = nid
nid = FourByteNodeId(ObjectIds.OpenSecureChannelResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = OpenSecureChannelResponse
typeid_by_extension_objects[OpenSecureChannelResponse] = nid
nid = FourByteNodeId(ObjectIds.CloseSecureChannelRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CloseSecureChannelRequest
typeid_by_extension_objects[CloseSecureChannelRequest] = nid
nid = FourByteNodeId(ObjectIds.CloseSecureChannelResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CloseSecureChannelResponse
typeid_by_extension_objects[CloseSecureChannelResponse] = nid
nid = FourByteNodeId(ObjectIds.SignedSoftwareCertificate_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SignedSoftwareCertificate
typeid_by_extension_objects[SignedSoftwareCertificate] = nid
nid = FourByteNodeId(ObjectIds.SignatureData_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SignatureData
typeid_by_extension_objects[SignatureData] = nid
nid = FourByteNodeId(ObjectIds.CreateSessionRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CreateSessionRequest
typeid_by_extension_objects[CreateSessionRequest] = nid
nid = FourByteNodeId(ObjectIds.CreateSessionResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CreateSessionResponse
typeid_by_extension_objects[CreateSessionResponse] = nid
nid = FourByteNodeId(ObjectIds.UserIdentityToken_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UserIdentityToken
typeid_by_extension_objects[UserIdentityToken] = nid
nid = FourByteNodeId(ObjectIds.AnonymousIdentityToken_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AnonymousIdentityToken
typeid_by_extension_objects[AnonymousIdentityToken] = nid
nid = FourByteNodeId(ObjectIds.UserNameIdentityToken_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UserNameIdentityToken
typeid_by_extension_objects[UserNameIdentityToken] = nid
nid = FourByteNodeId(ObjectIds.X509IdentityToken_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = X509IdentityToken
typeid_by_extension_objects[X509IdentityToken] = nid
nid = FourByteNodeId(ObjectIds.IssuedIdentityToken_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = IssuedIdentityToken
typeid_by_extension_objects[IssuedIdentityToken] = nid
nid = FourByteNodeId(ObjectIds.ActivateSessionRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ActivateSessionRequest
typeid_by_extension_objects[ActivateSessionRequest] = nid
nid = FourByteNodeId(ObjectIds.ActivateSessionResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ActivateSessionResponse
typeid_by_extension_objects[ActivateSessionResponse] = nid
nid = FourByteNodeId(ObjectIds.CloseSessionRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CloseSessionRequest
typeid_by_extension_objects[CloseSessionRequest] = nid
nid = FourByteNodeId(ObjectIds.CloseSessionResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CloseSessionResponse
typeid_by_extension_objects[CloseSessionResponse] = nid
nid = FourByteNodeId(ObjectIds.CancelRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CancelRequest
typeid_by_extension_objects[CancelRequest] = nid
nid = FourByteNodeId(ObjectIds.CancelResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CancelResponse
typeid_by_extension_objects[CancelResponse] = nid
nid = FourByteNodeId(ObjectIds.NodeAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NodeAttributes
typeid_by_extension_objects[NodeAttributes] = nid
nid = FourByteNodeId(ObjectIds.ObjectAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ObjectAttributes
typeid_by_extension_objects[ObjectAttributes] = nid
nid = FourByteNodeId(ObjectIds.VariableAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = VariableAttributes
typeid_by_extension_objects[VariableAttributes] = nid
nid = FourByteNodeId(ObjectIds.MethodAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MethodAttributes
typeid_by_extension_objects[MethodAttributes] = nid
nid = FourByteNodeId(ObjectIds.ObjectTypeAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ObjectTypeAttributes
typeid_by_extension_objects[ObjectTypeAttributes] = nid
nid = FourByteNodeId(ObjectIds.VariableTypeAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = VariableTypeAttributes
typeid_by_extension_objects[VariableTypeAttributes] = nid
nid = FourByteNodeId(ObjectIds.ReferenceTypeAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReferenceTypeAttributes
typeid_by_extension_objects[ReferenceTypeAttributes] = nid
nid = FourByteNodeId(ObjectIds.DataTypeAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataTypeAttributes
typeid_by_extension_objects[DataTypeAttributes] = nid
nid = FourByteNodeId(ObjectIds.ViewAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ViewAttributes
typeid_by_extension_objects[ViewAttributes] = nid
nid = FourByteNodeId(ObjectIds.GenericAttributeValue_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = GenericAttributeValue
typeid_by_extension_objects[GenericAttributeValue] = nid
nid = FourByteNodeId(ObjectIds.GenericAttributes_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = GenericAttributes
typeid_by_extension_objects[GenericAttributes] = nid
nid = FourByteNodeId(ObjectIds.AddNodesItem_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddNodesItem
typeid_by_extension_objects[AddNodesItem] = nid
nid = FourByteNodeId(ObjectIds.AddNodesResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddNodesResult
typeid_by_extension_objects[AddNodesResult] = nid
nid = FourByteNodeId(ObjectIds.AddNodesRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddNodesRequest
typeid_by_extension_objects[AddNodesRequest] = nid
nid = FourByteNodeId(ObjectIds.AddNodesResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddNodesResponse
typeid_by_extension_objects[AddNodesResponse] = nid
nid = FourByteNodeId(ObjectIds.AddReferencesItem_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddReferencesItem
typeid_by_extension_objects[AddReferencesItem] = nid
nid = FourByteNodeId(ObjectIds.AddReferencesRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddReferencesRequest
typeid_by_extension_objects[AddReferencesRequest] = nid
nid = FourByteNodeId(ObjectIds.AddReferencesResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AddReferencesResponse
typeid_by_extension_objects[AddReferencesResponse] = nid
nid = FourByteNodeId(ObjectIds.DeleteNodesItem_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteNodesItem
typeid_by_extension_objects[DeleteNodesItem] = nid
nid = FourByteNodeId(ObjectIds.DeleteNodesRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteNodesRequest
typeid_by_extension_objects[DeleteNodesRequest] = nid
nid = FourByteNodeId(ObjectIds.DeleteNodesResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteNodesResponse
typeid_by_extension_objects[DeleteNodesResponse] = nid
nid = FourByteNodeId(ObjectIds.DeleteReferencesItem_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteReferencesItem
typeid_by_extension_objects[DeleteReferencesItem] = nid
nid = FourByteNodeId(ObjectIds.DeleteReferencesRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteReferencesRequest
typeid_by_extension_objects[DeleteReferencesRequest] = nid
nid = FourByteNodeId(ObjectIds.DeleteReferencesResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteReferencesResponse
typeid_by_extension_objects[DeleteReferencesResponse] = nid
nid = FourByteNodeId(ObjectIds.ViewDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ViewDescription
typeid_by_extension_objects[ViewDescription] = nid
nid = FourByteNodeId(ObjectIds.BrowseDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowseDescription
typeid_by_extension_objects[BrowseDescription] = nid
nid = FourByteNodeId(ObjectIds.ReferenceDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReferenceDescription
typeid_by_extension_objects[ReferenceDescription] = nid
nid = FourByteNodeId(ObjectIds.BrowseResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowseResult
typeid_by_extension_objects[BrowseResult] = nid
nid = FourByteNodeId(ObjectIds.BrowseRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowseRequest
typeid_by_extension_objects[BrowseRequest] = nid
nid = FourByteNodeId(ObjectIds.BrowseResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowseResponse
typeid_by_extension_objects[BrowseResponse] = nid
nid = FourByteNodeId(ObjectIds.BrowseNextRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowseNextRequest
typeid_by_extension_objects[BrowseNextRequest] = nid
nid = FourByteNodeId(ObjectIds.BrowseNextResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowseNextResponse
typeid_by_extension_objects[BrowseNextResponse] = nid
nid = FourByteNodeId(ObjectIds.BrowsePath_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowsePath
typeid_by_extension_objects[BrowsePath] = nid
nid = FourByteNodeId(ObjectIds.BrowsePathTarget_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowsePathTarget
typeid_by_extension_objects[BrowsePathTarget] = nid
nid = FourByteNodeId(ObjectIds.BrowsePathResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BrowsePathResult
typeid_by_extension_objects[BrowsePathResult] = nid
nid = FourByteNodeId(ObjectIds.TranslateBrowsePathsToNodeIdsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TranslateBrowsePathsToNodeIdsRequest
typeid_by_extension_objects[TranslateBrowsePathsToNodeIdsRequest] = nid
nid = FourByteNodeId(ObjectIds.TranslateBrowsePathsToNodeIdsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TranslateBrowsePathsToNodeIdsResponse
typeid_by_extension_objects[TranslateBrowsePathsToNodeIdsResponse] = nid
nid = FourByteNodeId(ObjectIds.RegisterNodesRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisterNodesRequest
typeid_by_extension_objects[RegisterNodesRequest] = nid
nid = FourByteNodeId(ObjectIds.RegisterNodesResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RegisterNodesResponse
typeid_by_extension_objects[RegisterNodesResponse] = nid
nid = FourByteNodeId(ObjectIds.UnregisterNodesRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UnregisterNodesRequest
typeid_by_extension_objects[UnregisterNodesRequest] = nid
nid = FourByteNodeId(ObjectIds.UnregisterNodesResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UnregisterNodesResponse
typeid_by_extension_objects[UnregisterNodesResponse] = nid
nid = FourByteNodeId(ObjectIds.EndpointConfiguration_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EndpointConfiguration
typeid_by_extension_objects[EndpointConfiguration] = nid
nid = FourByteNodeId(ObjectIds.QueryDataDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QueryDataDescription
typeid_by_extension_objects[QueryDataDescription] = nid
nid = FourByteNodeId(ObjectIds.NodeTypeDescription_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NodeTypeDescription
typeid_by_extension_objects[NodeTypeDescription] = nid
nid = FourByteNodeId(ObjectIds.QueryDataSet_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QueryDataSet
typeid_by_extension_objects[QueryDataSet] = nid
nid = FourByteNodeId(ObjectIds.NodeReference_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NodeReference
typeid_by_extension_objects[NodeReference] = nid
nid = FourByteNodeId(ObjectIds.ContentFilterElement_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ContentFilterElement
typeid_by_extension_objects[ContentFilterElement] = nid
nid = FourByteNodeId(ObjectIds.ContentFilter_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ContentFilter
typeid_by_extension_objects[ContentFilter] = nid
nid = FourByteNodeId(ObjectIds.FilterOperand_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = FilterOperand
typeid_by_extension_objects[FilterOperand] = nid
nid = FourByteNodeId(ObjectIds.ElementOperand_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ElementOperand
typeid_by_extension_objects[ElementOperand] = nid
nid = FourByteNodeId(ObjectIds.LiteralOperand_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = LiteralOperand
typeid_by_extension_objects[LiteralOperand] = nid
nid = FourByteNodeId(ObjectIds.AttributeOperand_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AttributeOperand
typeid_by_extension_objects[AttributeOperand] = nid
nid = FourByteNodeId(ObjectIds.SimpleAttributeOperand_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SimpleAttributeOperand
typeid_by_extension_objects[SimpleAttributeOperand] = nid
nid = FourByteNodeId(ObjectIds.PublishedEventsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishedEventsDataType
typeid_by_extension_objects[PublishedEventsDataType] = nid
nid = FourByteNodeId(ObjectIds.ContentFilterElementResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ContentFilterElementResult
typeid_by_extension_objects[ContentFilterElementResult] = nid
nid = FourByteNodeId(ObjectIds.ContentFilterResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ContentFilterResult
typeid_by_extension_objects[ContentFilterResult] = nid
nid = FourByteNodeId(ObjectIds.ParsingResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ParsingResult
typeid_by_extension_objects[ParsingResult] = nid
nid = FourByteNodeId(ObjectIds.QueryFirstRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QueryFirstRequest
typeid_by_extension_objects[QueryFirstRequest] = nid
nid = FourByteNodeId(ObjectIds.QueryFirstResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QueryFirstResponse
typeid_by_extension_objects[QueryFirstResponse] = nid
nid = FourByteNodeId(ObjectIds.QueryNextRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QueryNextRequest
typeid_by_extension_objects[QueryNextRequest] = nid
nid = FourByteNodeId(ObjectIds.QueryNextResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = QueryNextResponse
typeid_by_extension_objects[QueryNextResponse] = nid
nid = FourByteNodeId(ObjectIds.ReadValueId_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadValueId
typeid_by_extension_objects[ReadValueId] = nid
nid = FourByteNodeId(ObjectIds.ReadRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadRequest
typeid_by_extension_objects[ReadRequest] = nid
nid = FourByteNodeId(ObjectIds.ReadResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadResponse
typeid_by_extension_objects[ReadResponse] = nid
nid = FourByteNodeId(ObjectIds.HistoryReadValueId_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryReadValueId
typeid_by_extension_objects[HistoryReadValueId] = nid
nid = FourByteNodeId(ObjectIds.HistoryReadResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryReadResult
typeid_by_extension_objects[HistoryReadResult] = nid
nid = FourByteNodeId(ObjectIds.HistoryReadDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryReadDetails
typeid_by_extension_objects[HistoryReadDetails] = nid
nid = FourByteNodeId(ObjectIds.SortRuleElement_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SortRuleElement
typeid_by_extension_objects[SortRuleElement] = nid
nid = FourByteNodeId(ObjectIds.ReadRawModifiedDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadRawModifiedDetails
typeid_by_extension_objects[ReadRawModifiedDetails] = nid
nid = FourByteNodeId(ObjectIds.ReadAtTimeDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadAtTimeDetails
typeid_by_extension_objects[ReadAtTimeDetails] = nid
nid = FourByteNodeId(ObjectIds.ReadAnnotationDataDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadAnnotationDataDetails
typeid_by_extension_objects[ReadAnnotationDataDetails] = nid
nid = FourByteNodeId(ObjectIds.HistoryData_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryData
typeid_by_extension_objects[HistoryData] = nid
nid = FourByteNodeId(ObjectIds.ModificationInfo_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ModificationInfo
typeid_by_extension_objects[ModificationInfo] = nid
nid = FourByteNodeId(ObjectIds.HistoryModifiedData_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryModifiedData
typeid_by_extension_objects[HistoryModifiedData] = nid
nid = FourByteNodeId(ObjectIds.HistoryReadRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryReadRequest
typeid_by_extension_objects[HistoryReadRequest] = nid
nid = FourByteNodeId(ObjectIds.HistoryReadResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryReadResponse
typeid_by_extension_objects[HistoryReadResponse] = nid
nid = FourByteNodeId(ObjectIds.WriteValue_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = WriteValue
typeid_by_extension_objects[WriteValue] = nid
nid = FourByteNodeId(ObjectIds.WriteRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = WriteRequest
typeid_by_extension_objects[WriteRequest] = nid
nid = FourByteNodeId(ObjectIds.WriteResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = WriteResponse
typeid_by_extension_objects[WriteResponse] = nid
nid = FourByteNodeId(ObjectIds.HistoryUpdateDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryUpdateDetails
typeid_by_extension_objects[HistoryUpdateDetails] = nid
nid = FourByteNodeId(ObjectIds.UpdateDataDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UpdateDataDetails
typeid_by_extension_objects[UpdateDataDetails] = nid
nid = FourByteNodeId(ObjectIds.UpdateStructureDataDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UpdateStructureDataDetails
typeid_by_extension_objects[UpdateStructureDataDetails] = nid
nid = FourByteNodeId(ObjectIds.DeleteRawModifiedDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteRawModifiedDetails
typeid_by_extension_objects[DeleteRawModifiedDetails] = nid
nid = FourByteNodeId(ObjectIds.DeleteAtTimeDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteAtTimeDetails
typeid_by_extension_objects[DeleteAtTimeDetails] = nid
nid = FourByteNodeId(ObjectIds.DeleteEventDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteEventDetails
typeid_by_extension_objects[DeleteEventDetails] = nid
nid = FourByteNodeId(ObjectIds.HistoryUpdateResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryUpdateResult
typeid_by_extension_objects[HistoryUpdateResult] = nid
nid = FourByteNodeId(ObjectIds.HistoryUpdateRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryUpdateRequest
typeid_by_extension_objects[HistoryUpdateRequest] = nid
nid = FourByteNodeId(ObjectIds.HistoryUpdateResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryUpdateResponse
typeid_by_extension_objects[HistoryUpdateResponse] = nid
nid = FourByteNodeId(ObjectIds.CallMethodRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CallMethodRequest
typeid_by_extension_objects[CallMethodRequest] = nid
nid = FourByteNodeId(ObjectIds.CallMethodResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CallMethodResult
typeid_by_extension_objects[CallMethodResult] = nid
nid = FourByteNodeId(ObjectIds.CallRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CallRequest
typeid_by_extension_objects[CallRequest] = nid
nid = FourByteNodeId(ObjectIds.CallResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CallResponse
typeid_by_extension_objects[CallResponse] = nid
nid = FourByteNodeId(ObjectIds.MonitoringFilter_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoringFilter
typeid_by_extension_objects[MonitoringFilter] = nid
nid = FourByteNodeId(ObjectIds.DataChangeFilter_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataChangeFilter
typeid_by_extension_objects[DataChangeFilter] = nid
nid = FourByteNodeId(ObjectIds.EventFilter_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EventFilter
typeid_by_extension_objects[EventFilter] = nid
nid = FourByteNodeId(ObjectIds.ReadEventDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadEventDetails
typeid_by_extension_objects[ReadEventDetails] = nid
nid = FourByteNodeId(ObjectIds.ReadEventDetails2_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadEventDetails2
typeid_by_extension_objects[ReadEventDetails2] = nid
nid = FourByteNodeId(ObjectIds.ReadEventDetailsSorted_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadEventDetailsSorted
typeid_by_extension_objects[ReadEventDetailsSorted] = nid
nid = FourByteNodeId(ObjectIds.AggregateConfiguration_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AggregateConfiguration
typeid_by_extension_objects[AggregateConfiguration] = nid
nid = FourByteNodeId(ObjectIds.ReadProcessedDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ReadProcessedDetails
typeid_by_extension_objects[ReadProcessedDetails] = nid
nid = FourByteNodeId(ObjectIds.AggregateFilter_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AggregateFilter
typeid_by_extension_objects[AggregateFilter] = nid
nid = FourByteNodeId(ObjectIds.MonitoringFilterResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoringFilterResult
typeid_by_extension_objects[MonitoringFilterResult] = nid
nid = FourByteNodeId(ObjectIds.EventFilterResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EventFilterResult
typeid_by_extension_objects[EventFilterResult] = nid
nid = FourByteNodeId(ObjectIds.AggregateFilterResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AggregateFilterResult
typeid_by_extension_objects[AggregateFilterResult] = nid
nid = FourByteNodeId(ObjectIds.MonitoringParameters_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoringParameters
typeid_by_extension_objects[MonitoringParameters] = nid
nid = FourByteNodeId(ObjectIds.MonitoredItemCreateRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoredItemCreateRequest
typeid_by_extension_objects[MonitoredItemCreateRequest] = nid
nid = FourByteNodeId(ObjectIds.MonitoredItemCreateResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoredItemCreateResult
typeid_by_extension_objects[MonitoredItemCreateResult] = nid
nid = FourByteNodeId(ObjectIds.CreateMonitoredItemsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CreateMonitoredItemsRequest
typeid_by_extension_objects[CreateMonitoredItemsRequest] = nid
nid = FourByteNodeId(ObjectIds.CreateMonitoredItemsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CreateMonitoredItemsResponse
typeid_by_extension_objects[CreateMonitoredItemsResponse] = nid
nid = FourByteNodeId(ObjectIds.MonitoredItemModifyRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoredItemModifyRequest
typeid_by_extension_objects[MonitoredItemModifyRequest] = nid
nid = FourByteNodeId(ObjectIds.MonitoredItemModifyResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoredItemModifyResult
typeid_by_extension_objects[MonitoredItemModifyResult] = nid
nid = FourByteNodeId(ObjectIds.ModifyMonitoredItemsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ModifyMonitoredItemsRequest
typeid_by_extension_objects[ModifyMonitoredItemsRequest] = nid
nid = FourByteNodeId(ObjectIds.ModifyMonitoredItemsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ModifyMonitoredItemsResponse
typeid_by_extension_objects[ModifyMonitoredItemsResponse] = nid
nid = FourByteNodeId(ObjectIds.SetMonitoringModeRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SetMonitoringModeRequest
typeid_by_extension_objects[SetMonitoringModeRequest] = nid
nid = FourByteNodeId(ObjectIds.SetMonitoringModeResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SetMonitoringModeResponse
typeid_by_extension_objects[SetMonitoringModeResponse] = nid
nid = FourByteNodeId(ObjectIds.SetTriggeringRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SetTriggeringRequest
typeid_by_extension_objects[SetTriggeringRequest] = nid
nid = FourByteNodeId(ObjectIds.SetTriggeringResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SetTriggeringResponse
typeid_by_extension_objects[SetTriggeringResponse] = nid
nid = FourByteNodeId(ObjectIds.DeleteMonitoredItemsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteMonitoredItemsRequest
typeid_by_extension_objects[DeleteMonitoredItemsRequest] = nid
nid = FourByteNodeId(ObjectIds.DeleteMonitoredItemsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteMonitoredItemsResponse
typeid_by_extension_objects[DeleteMonitoredItemsResponse] = nid
nid = FourByteNodeId(ObjectIds.CreateSubscriptionRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CreateSubscriptionRequest
typeid_by_extension_objects[CreateSubscriptionRequest] = nid
nid = FourByteNodeId(ObjectIds.CreateSubscriptionResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = CreateSubscriptionResponse
typeid_by_extension_objects[CreateSubscriptionResponse] = nid
nid = FourByteNodeId(ObjectIds.ModifySubscriptionRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ModifySubscriptionRequest
typeid_by_extension_objects[ModifySubscriptionRequest] = nid
nid = FourByteNodeId(ObjectIds.ModifySubscriptionResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ModifySubscriptionResponse
typeid_by_extension_objects[ModifySubscriptionResponse] = nid
nid = FourByteNodeId(ObjectIds.SetPublishingModeRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SetPublishingModeRequest
typeid_by_extension_objects[SetPublishingModeRequest] = nid
nid = FourByteNodeId(ObjectIds.SetPublishingModeResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SetPublishingModeResponse
typeid_by_extension_objects[SetPublishingModeResponse] = nid
nid = FourByteNodeId(ObjectIds.NotificationMessage_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NotificationMessage
typeid_by_extension_objects[NotificationMessage] = nid
nid = FourByteNodeId(ObjectIds.NotificationData_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NotificationData
typeid_by_extension_objects[NotificationData] = nid
nid = FourByteNodeId(ObjectIds.MonitoredItemNotification_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = MonitoredItemNotification
typeid_by_extension_objects[MonitoredItemNotification] = nid
nid = FourByteNodeId(ObjectIds.DataChangeNotification_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DataChangeNotification
typeid_by_extension_objects[DataChangeNotification] = nid
nid = FourByteNodeId(ObjectIds.EventFieldList_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EventFieldList
typeid_by_extension_objects[EventFieldList] = nid
nid = FourByteNodeId(ObjectIds.EventNotificationList_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EventNotificationList
typeid_by_extension_objects[EventNotificationList] = nid
nid = FourByteNodeId(ObjectIds.HistoryEventFieldList_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryEventFieldList
typeid_by_extension_objects[HistoryEventFieldList] = nid
nid = FourByteNodeId(ObjectIds.HistoryEvent_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryEvent
typeid_by_extension_objects[HistoryEvent] = nid
nid = FourByteNodeId(ObjectIds.HistoryModifiedEvent_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = HistoryModifiedEvent
typeid_by_extension_objects[HistoryModifiedEvent] = nid
nid = FourByteNodeId(ObjectIds.UpdateEventDetails_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = UpdateEventDetails
typeid_by_extension_objects[UpdateEventDetails] = nid
nid = FourByteNodeId(ObjectIds.StatusChangeNotification_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StatusChangeNotification
typeid_by_extension_objects[StatusChangeNotification] = nid
nid = FourByteNodeId(ObjectIds.SubscriptionAcknowledgement_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SubscriptionAcknowledgement
typeid_by_extension_objects[SubscriptionAcknowledgement] = nid
nid = FourByteNodeId(ObjectIds.PublishRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishRequest
typeid_by_extension_objects[PublishRequest] = nid
nid = FourByteNodeId(ObjectIds.PublishResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = PublishResponse
typeid_by_extension_objects[PublishResponse] = nid
nid = FourByteNodeId(ObjectIds.RepublishRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RepublishRequest
typeid_by_extension_objects[RepublishRequest] = nid
nid = FourByteNodeId(ObjectIds.RepublishResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RepublishResponse
typeid_by_extension_objects[RepublishResponse] = nid
nid = FourByteNodeId(ObjectIds.TransferResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TransferResult
typeid_by_extension_objects[TransferResult] = nid
nid = FourByteNodeId(ObjectIds.TransferSubscriptionsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TransferSubscriptionsRequest
typeid_by_extension_objects[TransferSubscriptionsRequest] = nid
nid = FourByteNodeId(ObjectIds.TransferSubscriptionsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = TransferSubscriptionsResponse
typeid_by_extension_objects[TransferSubscriptionsResponse] = nid
nid = FourByteNodeId(ObjectIds.DeleteSubscriptionsRequest_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteSubscriptionsRequest
typeid_by_extension_objects[DeleteSubscriptionsRequest] = nid
nid = FourByteNodeId(ObjectIds.DeleteSubscriptionsResponse_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DeleteSubscriptionsResponse
typeid_by_extension_objects[DeleteSubscriptionsResponse] = nid
nid = FourByteNodeId(ObjectIds.BuildInfo_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = BuildInfo
typeid_by_extension_objects[BuildInfo] = nid
nid = FourByteNodeId(ObjectIds.RedundantServerDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = RedundantServerDataType
typeid_by_extension_objects[RedundantServerDataType] = nid
nid = FourByteNodeId(ObjectIds.EndpointUrlListDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EndpointUrlListDataType
typeid_by_extension_objects[EndpointUrlListDataType] = nid
nid = FourByteNodeId(ObjectIds.NetworkGroupDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = NetworkGroupDataType
typeid_by_extension_objects[NetworkGroupDataType] = nid
nid = FourByteNodeId(ObjectIds.SamplingIntervalDiagnosticsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SamplingIntervalDiagnosticsDataType
typeid_by_extension_objects[SamplingIntervalDiagnosticsDataType] = nid
nid = FourByteNodeId(ObjectIds.ServerDiagnosticsSummaryDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServerDiagnosticsSummaryDataType
typeid_by_extension_objects[ServerDiagnosticsSummaryDataType] = nid
nid = FourByteNodeId(ObjectIds.ServerStatusDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServerStatusDataType
typeid_by_extension_objects[ServerStatusDataType] = nid
nid = FourByteNodeId(ObjectIds.SessionSecurityDiagnosticsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SessionSecurityDiagnosticsDataType
typeid_by_extension_objects[SessionSecurityDiagnosticsDataType] = nid
nid = FourByteNodeId(ObjectIds.ServiceCounterDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ServiceCounterDataType
typeid_by_extension_objects[ServiceCounterDataType] = nid
nid = FourByteNodeId(ObjectIds.SessionDiagnosticsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SessionDiagnosticsDataType
typeid_by_extension_objects[SessionDiagnosticsDataType] = nid
nid = FourByteNodeId(ObjectIds.StatusResult_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = StatusResult
typeid_by_extension_objects[StatusResult] = nid
nid = FourByteNodeId(ObjectIds.SubscriptionDiagnosticsDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SubscriptionDiagnosticsDataType
typeid_by_extension_objects[SubscriptionDiagnosticsDataType] = nid
nid = FourByteNodeId(ObjectIds.ModelChangeStructureDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ModelChangeStructureDataType
typeid_by_extension_objects[ModelChangeStructureDataType] = nid
nid = FourByteNodeId(ObjectIds.SemanticChangeStructureDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = SemanticChangeStructureDataType
typeid_by_extension_objects[SemanticChangeStructureDataType] = nid
nid = FourByteNodeId(ObjectIds.Range_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Range
typeid_by_extension_objects[Range] = nid
nid = FourByteNodeId(ObjectIds.EUInformation_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = EUInformation
typeid_by_extension_objects[EUInformation] = nid
nid = FourByteNodeId(ObjectIds.ComplexNumberType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ComplexNumberType
typeid_by_extension_objects[ComplexNumberType] = nid
nid = FourByteNodeId(ObjectIds.DoubleComplexNumberType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = DoubleComplexNumberType
typeid_by_extension_objects[DoubleComplexNumberType] = nid
nid = FourByteNodeId(ObjectIds.AxisInformation_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = AxisInformation
typeid_by_extension_objects[AxisInformation] = nid
nid = FourByteNodeId(ObjectIds.XVType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = XVType
typeid_by_extension_objects[XVType] = nid
nid = FourByteNodeId(ObjectIds.ProgramDiagnosticDataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ProgramDiagnosticDataType
typeid_by_extension_objects[ProgramDiagnosticDataType] = nid
nid = FourByteNodeId(ObjectIds.ProgramDiagnostic2DataType_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = ProgramDiagnostic2DataType
typeid_by_extension_objects[ProgramDiagnostic2DataType] = nid
nid = FourByteNodeId(ObjectIds.Annotation_Encoding_DefaultBinary)
extension_objects_by_typeid[nid] = Annotation
typeid_by_extension_objects[Annotation] = nid
