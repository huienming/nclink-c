"""
server side implementation of a subscription object
"""

from __future__ import annotations

import copy
import logging
from logging import Logger
from typing import TYPE_CHECKING, Any

from asyncua import ua

from .address_space import AddressSpace

if TYPE_CHECKING:
    from .internal_subscription import InternalSubscription


class MonitoredItemData:
    def __init__(self) -> None:
        self.client_handle: int | None = None
        self.callback_handle: int | None = None
        self.monitored_item_id: int | None = None
        self.mode: ua.MonitoringMode | None = None
        self.filter: Any = None
        self.mvalue = MonitoredItemValues()
        self.where_clause_evaluator: WhereClauseEvaluator | None = None
        self.queue_size: int = 0


class MonitoredItemValues:
    def __init__(self) -> None:
        self.current_dvalue: ua.DataValue | None = None
        self.old_dvalue: ua.DataValue | None = None

    def set_current_datavalue(self, cur_val: ua.DataValue) -> None:
        self.old_dvalue = self.current_dvalue
        # We need to clone the value, to prevent referencing the inner value
        self.current_dvalue = copy.deepcopy(cur_val)

    def get_current_datavalue(self) -> ua.DataValue | None:
        return self.current_dvalue

    def get_old_datavalue(self) -> ua.DataValue | None:
        return self.old_dvalue


class MonitoredItemService:
    """
    Implements monitored item service for one subscription
    """

    def __init__(self, isub: "InternalSubscription", aspace: AddressSpace) -> None:
        self.logger = logging.getLogger(f"{__name__}.{isub.data.SubscriptionId}")
        self.isub: "InternalSubscription" = isub
        self.aspace: AddressSpace = aspace
        self._monitored_items: dict[int, MonitoredItemData] = {}
        self._monitored_events: dict[ua.NodeId, list[int]] = {}
        self._monitored_datachange: dict[int, int] = {}
        self._monitored_item_counter = 111

    def __str__(self) -> str:
        return f"MonitoredItemService({self.isub.data.SubscriptionId})"

    def delete_all_monitored_items(self) -> None:
        self.delete_monitored_items([mdata.monitored_item_id for mdata in self._monitored_items.values()])

    async def create_monitored_items(
        self, params: ua.CreateMonitoredItemsParameters
    ) -> list[ua.MonitoredItemCreateResult]:
        results: list[ua.MonitoredItemCreateResult] = []
        for item in params.ItemsToCreate:
            if item.ItemToMonitor.AttributeId == ua.AttributeIds.EventNotifier:
                result = self._create_events_monitored_item(item)
            else:
                result = await self._create_data_change_monitored_item(item)
            results.append(result)
        return results

    def modify_monitored_items(
        self, params: ua.ModifyMonitoredItemsParameters
    ) -> list[ua.MonitoredItemModifyResult]:
        results: list[ua.MonitoredItemModifyResult] = []
        for item in params.ItemsToModify:
            results.append(self._modify_monitored_item(item))
        return results

    async def trigger_datachange(self, handle: int, nodeid: ua.NodeId, attr: ua.AttributeIds) -> None:
        self.logger.debug("triggering datachange for handle %s, nodeid %s, and attribute %s", handle, nodeid, attr)
        dv = self.aspace.read_attribute_value(nodeid, attr)
        await self.datachange_callback(handle, dv)

    def _modify_monitored_item(self, params: ua.MonitoredItemModifyRequest) -> ua.MonitoredItemModifyResult:
        for mdata in self._monitored_items.values():
            result = ua.MonitoredItemModifyResult()
            if mdata.monitored_item_id == params.MonitoredItemId:
                result.RevisedSamplingInterval = params.RequestedParameters.SamplingInterval
                result.RevisedQueueSize = params.RequestedParameters.QueueSize
                if params.RequestedParameters.Filter is not None:
                    mdata.filter = params.RequestedParameters.Filter
                mdata.queue_size = params.RequestedParameters.QueueSize
                return result
        result = ua.MonitoredItemModifyResult()
        result.StatusCode(ua.StatusCodes.BadMonitoredItemIdInvalid)
        return result

    def _commit_monitored_item(self, result: ua.MonitoredItemCreateResult, mdata: MonitoredItemData) -> None:
        if result.StatusCode.is_good():
            self._monitored_items[result.MonitoredItemId] = mdata

    def _make_monitored_item_common(
        self, params: ua.MonitoredItemCreateRequest
    ) -> tuple[ua.MonitoredItemCreateResult, MonitoredItemData]:
        result = ua.MonitoredItemCreateResult()
        result.RevisedSamplingInterval = self.isub.data.RevisedPublishingInterval
        result.RevisedQueueSize = self._revise_queue_size(params.RequestedParameters.QueueSize)
        self._monitored_item_counter += 1
        result.MonitoredItemId = self._monitored_item_counter
        self.logger.debug("Creating MonitoredItem with id %s", result.MonitoredItemId)
        mdata = MonitoredItemData()
        mdata.mode = params.MonitoringMode
        mdata.client_handle = params.RequestedParameters.ClientHandle
        mdata.monitored_item_id = result.MonitoredItemId
        mdata.queue_size = result.RevisedQueueSize
        mdata.filter = params.RequestedParameters.Filter
        return result, mdata

    def _revise_queue_size(self, requested: int) -> int:
        cap = self.isub.max_queue_size
        if requested == 0:
            return cap
        return min(int(requested), cap)

    def _create_events_monitored_item(self, params: ua.MonitoredItemCreateRequest) -> ua.MonitoredItemCreateResult:
        self.logger.info(
            "request to subscribe to events for node %s and attribute %s",
            params.ItemToMonitor.NodeId,
            params.ItemToMonitor.AttributeId,
        )

        result, mdata = self._make_monitored_item_common(params)
        node_id = params.ItemToMonitor.NodeId
        if node_id is None:
            result.StatusCode = ua.StatusCode(ua.StatusCodes.BadNodeIdInvalid)
            return result
        dv = self.aspace.read_attribute_value(node_id, ua.AttributeIds.EventNotifier)
        ev_notify_byte = dv.Value.Value if dv.Value is not None else None

        if ev_notify_byte is None or not ua.ua_binary.test_bit(ev_notify_byte, ua.EventNotifier.SubscribeToEvents):
            result.StatusCode = ua.StatusCode(ua.StatusCodes.BadServiceUnsupported)
            return result
        mdata.where_clause_evaluator = WhereClauseEvaluator(self.logger, self.aspace, mdata.filter.WhereClause)
        self._commit_monitored_item(result, mdata)
        if params.ItemToMonitor.NodeId not in self._monitored_events:
            self._monitored_events[params.ItemToMonitor.NodeId] = []
        self._monitored_events[params.ItemToMonitor.NodeId].append(result.MonitoredItemId)
        return result

    async def _create_data_change_monitored_item(
        self, params: ua.MonitoredItemCreateRequest
    ) -> ua.MonitoredItemCreateResult:
        self.logger.info(
            "request to subscribe to datachange for node %s and attribute %s",
            params.ItemToMonitor.NodeId,
            params.ItemToMonitor.AttributeId,
        )

        result, mdata = self._make_monitored_item_common(params)
        result.StatusCode, handle = self.aspace.add_datachange_callback(
            params.ItemToMonitor.NodeId, params.ItemToMonitor.AttributeId, self.datachange_callback
        )

        self.logger.debug("adding callback return status %s and handle %s", result.StatusCode, handle)
        mdata.callback_handle = handle
        self._commit_monitored_item(result, mdata)
        if result.StatusCode.is_good():
            self._monitored_datachange[handle] = result.MonitoredItemId
            await self.trigger_datachange(handle, params.ItemToMonitor.NodeId, params.ItemToMonitor.AttributeId)
        return result

    def delete_monitored_items(self, ids: list[int]) -> list[ua.StatusCode]:
        self.logger.debug("delete monitored items %s", ids)
        results: list[ua.StatusCode] = []
        for mid in ids:
            results.append(self._delete_monitored_items(mid))
        return results

    def _delete_monitored_items(self, mid: int) -> ua.StatusCode:
        if mid not in self._monitored_items:
            return ua.StatusCode(ua.StatusCodes.BadMonitoredItemIdInvalid)
        for node_key, mid_list in self._monitored_events.items():
            if mid in mid_list:
                mid_list.remove(mid)
                if not mid_list:
                    self._monitored_events.pop(node_key)
                break
        for handle, owner_mid in self._monitored_datachange.items():
            if owner_mid == mid:
                self.aspace.delete_datachange_callback(handle)
                self._monitored_datachange.pop(handle)
                break
        self._monitored_items.pop(mid)
        return ua.StatusCode()

    @staticmethod
    def _is_data_changed(values: MonitoredItemValues, trg: ua.DataChangeTrigger) -> bool:
        old = values.get_old_datavalue()
        current = values.get_current_datavalue()
        if old is None and current is None:
            return False
        if (old is None) != (current is None):
            return True
        if old is None or current is None:
            # This should never happen with the above logic, adding this check for mypy
            raise ValueError("This is an implementation error")

        if old.StatusCode != current.StatusCode:
            return True

        if (
            trg in [ua.DataChangeTrigger.StatusValue, ua.DataChangeTrigger.StatusValueTimestamp]
            and old.Value != current.Value
        ):
            return True

        if trg == ua.DataChangeTrigger.StatusValueTimestamp and (
            old.SourceTimestamp != current.SourceTimestamp or old.SourcePicoseconds != current.SourcePicoseconds
        ):
            return True

        return False

    async def datachange_callback(
        self, handle: int, value: ua.DataValue, error: ua.StatusCode | None = None
    ) -> None:
        if error:
            self.logger.info(
                "subscription %s: datachange callback called with handle '%s' and error '%s'", self, handle, error
            )
            await self.trigger_statuschange(error)
        else:
            event = ua.MonitoredItemNotification()
            mid = self._monitored_datachange[handle]
            mdata = self._monitored_items[mid]
            mdata.mvalue.set_current_datavalue(value)
            if mdata.filter:
                deadband_flag_pass = self._is_data_changed(
                    mdata.mvalue, mdata.filter.Trigger
                ) and self._is_deadband_exceeded(mdata.mvalue, mdata.filter)
            else:
                deadband_flag_pass = self._is_data_changed(mdata.mvalue, ua.DataChangeTrigger.StatusValue)

            if deadband_flag_pass:
                event.ClientHandle = mdata.client_handle
                event.Value = value
                await self.isub.enqueue_datachange_event(mid, event, mdata.queue_size)

    def _is_deadband_exceeded(self, values: MonitoredItemValues, flt: ua.DataChangeFilter) -> bool:
        cur = values.get_current_datavalue()
        old = values.get_old_datavalue()
        if flt.DeadbandType == ua.DeadbandType.None_ or old is None:
            return True
        if cur is None or cur.Value is None or old.Value is None:
            return True
        delta = cur.Value.Value - old.Value.Value
        if flt.DeadbandType == ua.DeadbandType.Absolute and ((abs(delta)) > flt.DeadbandValue):
            return True
        if flt.DeadbandType == ua.DeadbandType.Percent:
            self.logger.warning("DeadbandType Percent is not implemented !")
            return True
        return False

    async def trigger_event(self, event: Any, mid: int | None = None) -> bool:
        if event.emitting_node not in self._monitored_events:
            self.logger.debug("%s has NO subscription for events %s from node: %s", self, event, event.emitting_node)
            return False

        self.logger.debug("%s has subscription for events %s from node: %s", self, event, event.emitting_node)
        if mid is not None:
            await self._trigger_event(event, mid)
        else:
            mids = self._monitored_events[event.emitting_node]
            for mid in mids:
                await self._trigger_event(event, mid)
        return True

    async def _trigger_event(self, event: Any, mid: int) -> None:
        if mid not in self._monitored_items:
            self.logger.debug(
                "Could not find monitored items for id %s for event %s in subscription %s", mid, event, self
            )
            return
        mdata = self._monitored_items[mid]
        if mdata.where_clause_evaluator is None or not mdata.where_clause_evaluator.eval(event):
            self.logger.info("%s, %s, Event %s does not fit WhereClause, not generating event", self, mid, event)
            return
        fieldlist = ua.EventFieldList()
        fieldlist.ClientHandle = mdata.client_handle
        fieldlist.EventFields = event.to_event_fields(mdata.filter.SelectClauses)
        await self.isub.enqueue_event(mid, fieldlist, mdata.queue_size)

    async def trigger_statuschange(self, code: ua.StatusCode) -> None:
        await self.isub.enqueue_statuschange(code)


class WhereClauseEvaluator:
    def __init__(self, logger: Logger, aspace: AddressSpace, whereclause: ua.ContentFilter) -> None:
        self.logger = logger
        self.elements = whereclause.Elements
        self._aspace = aspace

    def eval(self, event: Any) -> bool:
        if not self.elements:
            return True
        try:
            res = self._eval_el(0, event)
        except Exception as ex:
            self.logger.exception(
                "Exception while evaluating WhereClause %s for event %s: %s", self.elements, event, ex
            )
            return False
        return bool(res)

    def _eval_el(self, index: int, event: Any) -> Any:
        el = self.elements[index]
        ops = el.FilterOperands
        if el.FilterOperator == ua.FilterOperator.Equals:
            return self._eval_op(ops[0], event) == self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.IsNull:
            return self._eval_op(ops[0], event) is None
        if el.FilterOperator == ua.FilterOperator.GreaterThan:
            return self._eval_op(ops[0], event) > self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.LessThan:
            return self._eval_op(ops[0], event) < self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.GreaterThanOrEqual:
            return self._eval_op(ops[0], event) >= self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.LessThanOrEqual:
            return self._eval_op(ops[0], event) <= self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.Like:
            return self._like_operator(self._eval_op(ops[0], event), self._eval_op(ops[1], event))
        if el.FilterOperator == ua.FilterOperator.Not:
            return not self._eval_op(ops[0], event)
        if el.FilterOperator == ua.FilterOperator.Between:
            return self._eval_op(ops[2], event) >= self._eval_op(ops[0], event) >= self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.InList:
            return self._eval_op(ops[0], event) in [self._eval_op(op, event) for op in ops[1:]]
        if el.FilterOperator == ua.FilterOperator.And:
            return self._eval_op(ops[0], event) and self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.Or:
            return self._eval_op(ops[0], event) or self._eval_op(ops[1], event)
        if el.FilterOperator == ua.FilterOperator.Cast:
            self.logger.warning("Cast operand not implemented, assuming True")
            return True
        if el.FilterOperator == ua.FilterOperator.OfType:
            return event.EventType == self._eval_op(ops[0], event)
        self.logger.warning("WhereClause not implemented for element: %s", el)
        raise NotImplementedError

    def _like_operator(self, string: str, pattern: str) -> bool:
        raise NotImplementedError

    def _eval_op(self, op: Any, event: Any) -> Any:
        if isinstance(op, ua.ElementOperand):
            return self._eval_el(op.Index, event)
        if isinstance(op, ua.AttributeOperand):
            if op.BrowsePath:
                return getattr(event, op.BrowsePath.Elements[0].TargetName.Name)
            return self._read_attribute_value(event.EventType, op.AttributeId)
        if isinstance(op, ua.SimpleAttributeOperand):
            if op.BrowsePath:
                return getattr(event, op.BrowsePath[0].Name)
            return self._read_attribute_value(event.EventType, op.AttributeId)
        if isinstance(op, ua.LiteralOperand):
            return op.Value.Value if op.Value is not None else None
        self.logger.warning("Where clause element % is not of a known type", op)
        raise NotImplementedError

    def _read_attribute_value(self, node_id: ua.NodeId, attr_id: ua.AttributeIds) -> Any:
        dv = self._aspace.read_attribute_value(node_id, attr_id)
        if dv.Value is None:
            return None
        return dv.Value.Value
