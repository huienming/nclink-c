"""
server side implementation of a subscription object
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable, Iterable
from typing import TYPE_CHECKING, Any

from asyncua import ua

from .address_space import AddressSpace
from .monitored_item_service import MonitoredItemService

if TYPE_CHECKING:
    from asyncua.server.uaprocessor import PublishRequestData

    PublishResultCallback = Callable[..., Awaitable[None]]
    PublishRequestCallback = Callable[[int], PublishRequestData | None]
    DeleteCallback = Callable[[], Any]


class InternalSubscription:
    """
    Server internal subscription.
    Runs the publication loop and stores the Publication Results until they are acknowledged.
    """

    def __init__(
        self,
        data: ua.CreateSubscriptionResult,
        aspace: AddressSpace,
        callback: PublishResultCallback,
        session_id: ua.NodeId,
        request_callback: PublishRequestCallback | None = None,
        delete_callback: DeleteCallback | None = None,
        no_acks_limit: int = 500,
        max_queue_size: int = 10_000,
    ) -> None:
        """
        :param loop: Event loop instance
        :param data: Create Subscription Result
        :param aspace: Server Address Space
        :param callback: Callback for publishing
        :param session_id: Id of the session that owns this subscription.
        :param request_callback: Callback for getting queued publish requests.
            If None, publishing will be done without waiting for a token and no
            acknowledging will be expected (for server internal subscriptions)
        :param delete_callback: Optional callback to call when the subscription
            is stopped due to the publish count exceeding the
            RevisedLifetimeCount.
        """
        self.logger = logging.getLogger(__name__)
        self.data: ua.CreateSubscriptionResult = data
        self.pub_result_callback: PublishResultCallback = callback
        self.pub_request_callback: PublishRequestCallback | None = request_callback
        self.monitored_item_srv = MonitoredItemService(self, aspace)
        self.delete_callback: DeleteCallback | None = delete_callback
        self.session_id: ua.NodeId = session_id
        self._triggered_datachanges: dict[int, list[ua.MonitoredItemNotification]] = {}
        self._triggered_events: dict[int, list[ua.EventFieldList]] = {}
        self._triggered_statuschanges: list[ua.StatusCode] = []
        self._notification_seq = 1
        self._no_acks_limit = no_acks_limit
        self.max_queue_size = max_queue_size
        self._not_acknowledged_results: dict[int, ua.PublishResult] = {}
        self._startup = True
        self._keep_alive_count = 0
        self._publish_cycles_count = 0
        self._task: asyncio.Task[None] | None = None
        self._closing = False

    def __str__(self) -> str:
        return f"Subscription(id:{self.data.SubscriptionId})"

    async def start(self) -> None:
        self.logger.debug("starting subscription %s", self.data.SubscriptionId)
        if self.data.RevisedPublishingInterval > 0.0:
            self._closing = False
            self._task = asyncio.create_task(self._subscription_loop())

    async def stop(self) -> None:
        if self._task:
            self.logger.info("stopping internal subscription %s", self.data.SubscriptionId)
            self._closing = True
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        self.monitored_item_srv.delete_all_monitored_items()

    async def _trigger_publish(self) -> None:
        """
        Trigger immediate publication (if requested by the PublishingInterval).
        """
        if not self._task and self.data.RevisedPublishingInterval <= 0.0:
            # Publish immediately (as fast as possible)
            await self.publish_results()

    async def _subscription_loop(self) -> None:
        """
        Start the publication loop running at the RevisedPublishingInterval.
        """
        ts = time.monotonic()
        period = self.data.RevisedPublishingInterval / 1000.0
        try:
            await self.publish_results()
            while not self._closing:
                next_ts = ts + period
                sleep_time = next_ts - time.monotonic()
                ts = next_ts
                await asyncio.sleep(max(sleep_time, 0))
                await self.publish_results()
        except asyncio.CancelledError:
            self.logger.info("exiting _subscription_loop for %s", self.data.SubscriptionId)
            raise
        except Exception:
            # seems this except is necessary to log errors
            self.logger.exception("Exception in subscription loop")
            raise

    def has_published_results(self) -> bool:
        if self._startup or self._triggered_datachanges or self._triggered_events:
            return True
        if self._keep_alive_count > self.data.RevisedMaxKeepAliveCount:
            self.logger.debug(
                "keep alive count %s is > than max keep alive count %s, sending publish event",
                self._keep_alive_count,
                self.data.RevisedMaxKeepAliveCount,
            )
            return True
        self._keep_alive_count += 1
        return False

    async def publish_results(self, requestdata: PublishRequestData | None = None) -> bool:
        """
        Publish all enqueued data changes, events and status changes though the callback.
        This method gets first called without publish request from subscription loop.
        It tries to get a publish request itself (if needed). If it doesn't succeed, method gets
        queued to be called back with publish request when one is available.
        """
        if self._publish_cycles_count > self.data.RevisedLifetimeCount:
            self.logger.warning(
                "Subscription %s has expired, publish cycle count(%s) > lifetime count (%s)",
                self,
                self._publish_cycles_count,
                self.data.RevisedLifetimeCount,
            )
            # FIXME this will never be send since we do not have publish request anyway
            await self.monitored_item_srv.trigger_statuschange(ua.StatusCode(ua.StatusCodes.BadTimeout))
            # Stop the subscription
            if self._task:
                self._closing = True
                self._task = None
            if self.delete_callback:
                self.delete_callback()
            self.monitored_item_srv.delete_all_monitored_items()
            return False
        if not self.has_published_results():
            return False
        # called from loop and external request
        if requestdata is None and self.pub_request_callback:
            # get publish request or queue us to be called back
            requestdata = self.pub_request_callback(self.data.SubscriptionId)
            if requestdata is None:
                self._publish_cycles_count += 1
                return False
        result = self._pop_publish_result()
        # self.logger.info('publish_results for %s', self.data.SubscriptionId)
        if requestdata is None:
            # Subscription.publish_callback -> server internal subscription
            await self.pub_result_callback(result)
        else:
            # UaProcessor.forward_publish_response -> client subscription
            await self.pub_result_callback(result, requestdata)
        return True

    def _pop_publish_result(self) -> ua.PublishResult:
        """
        Return a `PublishResult` with all enqueued data changes, events and status changes.
        Clear all queues.
        """
        result = ua.PublishResult()
        result.SubscriptionId = self.data.SubscriptionId
        self._pop_triggered_datachanges(result)
        self._pop_triggered_events(result)
        self._pop_triggered_statuschanges(result)
        self._keep_alive_count = 0
        self._publish_cycles_count = 0
        self._startup = False
        result.NotificationMessage.SequenceNumber = self._notification_seq
        if result.NotificationMessage.NotificationData and self.pub_request_callback:
            # Acknowledgement is only expected when the Subscription is for a client.
            self._notification_seq += 1
            self._not_acknowledged_results[result.NotificationMessage.SequenceNumber] = result
            while len(self._not_acknowledged_results) > self._no_acks_limit:
                oldest = next(iter(self._not_acknowledged_results))
                self._not_acknowledged_results.pop(oldest)
        result.MoreNotifications = False
        result.AvailableSequenceNumbers = list(self._not_acknowledged_results.keys())
        return result

    def _pop_triggered_datachanges(self, result: ua.PublishResult) -> None:
        """Append all enqueued data changes to the given `PublishResult` and clear the queue."""
        if self._triggered_datachanges:
            notif = ua.DataChangeNotification()
            notif.MonitoredItems = [item for sublist in self._triggered_datachanges.values() for item in sublist]
            self._triggered_datachanges = {}
            result.NotificationMessage.NotificationData.append(notif)

    def _pop_triggered_events(self, result: ua.PublishResult) -> None:
        """Append all enqueued events to the given `PublishResult` and clear the queue."""
        if self._triggered_events:
            notif = ua.EventNotificationList()
            notif.Events = [item for sublist in self._triggered_events.values() for item in sublist]
            self._triggered_events = {}
            result.NotificationMessage.NotificationData.append(notif)

    def _pop_triggered_statuschanges(self, result: ua.PublishResult) -> None:
        """Append all enqueued status changes to the given `PublishResult` and clear the queue."""
        if self._triggered_statuschanges:
            notif = ua.StatusChangeNotification()
            notif.Status = self._triggered_statuschanges.pop(0)
            result.NotificationMessage.NotificationData.append(notif)

    def publish(self, acks: Iterable[int]) -> None:
        """
        Reset publish cycle count, acknowledge PublishResults.
        :param acks: Sequence number of the PublishResults to acknowledge
        """
        # self.logger.info("publish request with acks %s", acks)
        for nb in acks:
            self._not_acknowledged_results.pop(nb, None)

    def republish(self, nb: int) -> ua.NotificationMessage:
        # self.logger.info("re-publish request for ack %s in subscription %s", nb, self)
        result = self._not_acknowledged_results.pop(nb, None)
        if result:
            self.logger.info("re-publishing ack %s in subscription %s", nb, self)
            return result.NotificationMessage
        self.logger.info("Error request to re-published non existing ack %s in subscription %s", nb, self)
        return ua.NotificationMessage()

    async def enqueue_datachange_event(self, mid: int, eventdata: ua.MonitoredItemNotification, maxsize: int) -> None:
        """
        Enqueue a monitored item data change.
        :param mid: Monitored Item Id
        :param eventdata: Monitored Item Notification
        :param maxsize: Max queue size (0: No limit)
        """
        await self._enqueue_event(mid, eventdata, maxsize, self._triggered_datachanges)

    async def enqueue_event(self, mid: int, eventdata: ua.EventFieldList, maxsize: int) -> None:
        """
        Enqueue a event.
        :param mid: Monitored Item Id
        :param eventdata: Event Field List
        :param maxsize: Max queue size (0: No limit)
        """
        await self._enqueue_event(mid, eventdata, maxsize, self._triggered_events)

    async def enqueue_statuschange(self, code: ua.StatusCode) -> None:
        """
        Enqueue a status change.
        :param code:
        """
        self._triggered_statuschanges.append(code)
        await self._trigger_publish()

    async def _enqueue_event(
        self,
        mid: int,
        eventdata: ua.MonitoredItemNotification | ua.EventFieldList,
        size: int,
        queue: dict[int, list[Any]],
    ) -> None:
        if mid not in queue:
            # New Monitored Item Id
            queue[mid] = [eventdata]
            await self._trigger_publish()
            return
        if size != 0:
            # Limit queue size
            if len(queue[mid]) >= size:
                queue[mid].pop(0)
        queue[mid].append(eventdata)
