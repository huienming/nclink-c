"""
server side implementation of subscription service
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Iterable
from typing import TYPE_CHECKING, Any

from asyncua import ua
from asyncua.common import uamethod, utils

from .address_space import AddressSpace
from .internal_subscription import InternalSubscription

if TYPE_CHECKING:
    from .internal_server import InternalServer


class SubscriptionService:
    """
    Manages subscriptions on the server side.
    There is one `SubscriptionService` instance for every `Server`/`InternalServer`.
    """

    def __init__(self, aspace: AddressSpace, iserver: "InternalServer | None" = None) -> None:
        self.logger = logging.getLogger(__name__)
        self.aspace: AddressSpace = aspace
        self.iserver: "InternalServer | None" = iserver
        self.subscriptions: dict[int, InternalSubscription] = {}
        self._sub_id_counter = 77
        self.standard_events: dict[int, Any] = {}
        self._conditions: dict[ua.NodeId, Any] = {}

    async def create_subscription(
        self,
        params: ua.CreateSubscriptionParameters,
        callback: Callable[..., Any],
        session_id: ua.NodeId,
        request_callback: Callable[..., Any] | None = None,
    ) -> ua.CreateSubscriptionResult:
        self.logger.info("create subscription")
        max_subs = self.iserver.max_subscriptions if self.iserver else 1_000
        if len(self.subscriptions) >= max_subs:
            self.logger.warning("Refusing subscription: at max_subscriptions=%s", max_subs)
            raise utils.ServiceError(ua.StatusCodes.BadTooManySubscriptions)
        result = ua.CreateSubscriptionResult()
        result.RevisedPublishingInterval = params.RequestedPublishingInterval
        result.RevisedLifetimeCount = self._clamp_lifetime_count(params.RequestedLifetimeCount)
        result.RevisedMaxKeepAliveCount = self._clamp_keep_alive_count(params.RequestedMaxKeepAliveCount)
        self._sub_id_counter += 1
        result.SubscriptionId = self._sub_id_counter
        no_acks_limit = self.iserver.max_unacked_messages_per_subscription if self.iserver else 5000
        max_queue_size = self.iserver.max_monitored_item_queue_size if self.iserver else 10_000
        internal_sub = InternalSubscription(
            result,
            self.aspace,
            callback,
            session_id,
            request_callback=request_callback,
            delete_callback=lambda: self.subscriptions.pop(result.SubscriptionId, None),
            no_acks_limit=no_acks_limit,
            max_queue_size=max_queue_size,
        )
        await internal_sub.start()
        self.subscriptions[result.SubscriptionId] = internal_sub
        return result

    def _clamp_lifetime_count(self, requested: int) -> int:
        if self.iserver is None:
            return requested
        cap = self.iserver.max_lifetime_count
        return min(requested, cap) if requested > 0 else cap

    def _clamp_keep_alive_count(self, requested: int) -> int:
        if self.iserver is None:
            return requested
        cap = self.iserver.max_keep_alive_count
        return min(requested, cap) if requested > 0 else cap

    def modify_subscription(self, params: ua.ModifySubscriptionParameters) -> ua.ModifySubscriptionResult:
        # Requested params are ignored, result = params set during create_subscription.
        self.logger.info("modify subscription")
        result = ua.ModifySubscriptionResult()
        try:
            sub = self.subscriptions[params.SubscriptionId]
            result.RevisedPublishingInterval = sub.data.RevisedPublishingInterval
            result.RevisedLifetimeCount = sub.data.RevisedLifetimeCount
            result.RevisedMaxKeepAliveCount = sub.data.RevisedMaxKeepAliveCount

            return result
        except KeyError:
            raise utils.ServiceError(ua.StatusCodes.BadSubscriptionIdInvalid)

    async def delete_subscriptions(self, ids: list[int]) -> list[ua.StatusCode]:
        self.logger.info("delete subscriptions: %s", ids)
        res: list[ua.StatusCode] = []
        existing_subs: list[InternalSubscription] = []
        for i in ids:
            sub = self.subscriptions.pop(i, None)
            if sub is None:
                res.append(ua.StatusCode(ua.StatusCodes.BadSubscriptionIdInvalid))
            else:
                existing_subs.append(sub)
                res.append(ua.StatusCode())
        stop_results = await asyncio.gather(*[sub.stop() for sub in existing_subs], return_exceptions=True)
        for stop_result in stop_results:
            if isinstance(stop_result, Exception):
                self.logger.warning("Exception while stopping subscription", exc_info=stop_result)
        return res

    def publish(self, acks: Iterable[ua.SubscriptionAcknowledgement]) -> tuple[int, list[ua.StatusCode]]:
        self.logger.info("publish request with acks %s", acks)
        if not self.subscriptions:
            raise utils.ServiceError(ua.StatusCodes.BadNoSubscription)
        results: list[ua.StatusCode] = []
        for ack in acks:
            sub = self.subscriptions.get(ack.SubscriptionId)
            if sub is None:
                results.append(ua.StatusCode(ua.StatusCodes.BadSubscriptionIdInvalid))
            else:
                sub.publish([ack.SequenceNumber])
                results.append(ua.StatusCode())
        return len(self.subscriptions), results

    async def create_monitored_items(
        self, params: ua.CreateMonitoredItemsParameters
    ) -> list[ua.MonitoredItemCreateResult]:
        self.logger.info("create monitored items")
        if params.SubscriptionId not in self.subscriptions:
            raise utils.ServiceError(ua.StatusCodes.BadSubscriptionIdInvalid)
        return await self.subscriptions[params.SubscriptionId].monitored_item_srv.create_monitored_items(params)

    def modify_monitored_items(
        self, params: ua.ModifyMonitoredItemsParameters
    ) -> list[ua.MonitoredItemModifyResult]:
        self.logger.info("modify monitored items")
        if params.SubscriptionId not in self.subscriptions:
            raise utils.ServiceError(ua.StatusCodes.BadSubscriptionIdInvalid)
        return self.subscriptions[params.SubscriptionId].monitored_item_srv.modify_monitored_items(params)

    def delete_monitored_items(self, params: ua.DeleteMonitoredItemsParameters) -> list[ua.StatusCode]:
        self.logger.info("delete monitored items")
        if params.SubscriptionId not in self.subscriptions:
            raise utils.ServiceError(ua.StatusCodes.BadSubscriptionIdInvalid)
        return self.subscriptions[params.SubscriptionId].monitored_item_srv.delete_monitored_items(
            params.MonitoredItemIds
        )

    def republish(self, params: ua.RepublishParameters) -> ua.NotificationMessage:
        if params.SubscriptionId not in self.subscriptions:
            # TODO: what should I do?
            return ua.NotificationMessage()
        return self.subscriptions[params.SubscriptionId].republish(params.RetransmitSequenceNumber)

    async def transfer_subscriptions(
        self,
        params: ua.TransferSubscriptionsParameters,
        session_id: ua.NodeId,
        callback: Callable[..., Any],
    ) -> list[ua.TransferResult]:
        self.logger.info("transfer_subscriptions: %s", params.SubscriptionIds)
        results: list[ua.TransferResult] = []
        for sub_id in params.SubscriptionIds:
            sub = self.subscriptions.get(int(sub_id))
            result = ua.TransferResult()
            if sub is None:
                result.StatusCode = ua.StatusCode(ua.StatusCodes.BadSubscriptionIdInvalid)
                results.append(result)
                continue
            sub.session_id = session_id
            sub.pub_result_callback = callback
            result.AvailableSequenceNumbers = sorted(sub._not_acknowledged_results.keys())
            results.append(result)
        return results

    async def trigger_event(self, event: Any, subscription_id: int | None = None) -> None:
        if hasattr(event, "Retain") and hasattr(event, "NodeId"):
            if event.Retain:
                self._conditions[event.NodeId] = event
            elif event.NodeId in self._conditions:
                del self._conditions[event.NodeId]
        if subscription_id is not None:
            if subscription_id in self.subscriptions:
                await self.subscriptions[subscription_id].monitored_item_srv.trigger_event(event)
        else:
            for sub in self.subscriptions.values():
                await sub.monitored_item_srv.trigger_event(event)

    @uamethod
    async def condition_refresh(
        self, parent: Any, subscription_id: int, mid: int | None = None
    ) -> ua.StatusCode | None:
        if subscription_id not in self.subscriptions:
            return ua.StatusCode(ua.StatusCodes.BadSubscriptionIdInvalid)
        sub = self.subscriptions[subscription_id]
        if mid is not None and mid not in sub.monitored_item_srv._monitored_items:
            return ua.StatusCode(ua.StatusCodes.BadMonitoredItemIdInvalid)
        if ua.ObjectIds.RefreshStartEventType in self.standard_events:
            await self.standard_events[ua.ObjectIds.RefreshStartEventType].trigger(subscription_id=subscription_id)
        for event in self._conditions.values():
            await sub.monitored_item_srv.trigger_event(event, mid)
        if ua.ObjectIds.RefreshEndEventType in self.standard_events:
            await self.standard_events[ua.ObjectIds.RefreshEndEventType].trigger(subscription_id=subscription_id)
        return None  # FIXME: really not sure this is correct, but this is the original behaviour
