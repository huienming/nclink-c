"""
High level method related functions
"""

from __future__ import annotations

import inspect
from functools import wraps
from typing import Any

import asyncua
from asyncua import ua
from asyncua.common.session_interface import AbstractSession


async def call_method(parent: asyncua.Node, methodid: ua.NodeId | ua.QualifiedName | str, *args: Any) -> Any:
    """
    Call an OPC-UA method. methodid is browse name of child method or the
    nodeid of method as a NodeId object
    arguments are variants or python object convertible to variants.
    which may be of different types
    returns a list of values or a single value depending on the output of the method
    : param: parent `Node`
    """
    result = await call_method_full(parent, methodid, *args)

    if len(result.OutputArguments) == 0:
        return None
    if len(result.OutputArguments) == 1:
        return result.OutputArguments[0]
    return result.OutputArguments


async def call_method_full(
    parent: asyncua.Node, methodid: ua.NodeId | ua.QualifiedName | str, *args: Any
) -> ua.CallMethodResult:
    """
    Call an OPC-UA method. methodid is browse name of child method or the
    nodeid of method as a NodeId object
    arguments are variants or python object convertible to variants.
    which may be of different types
    returns a CallMethodResult object with converted OutputArguments
    : param: parent `Node`
    """
    if isinstance(methodid, str | ua.uatypes.QualifiedName):
        methodid = (await parent.get_child(methodid)).nodeid
    elif hasattr(methodid, "nodeid"):
        methodid = methodid.nodeid

    result = await _call_method(parent.session, parent.nodeid, methodid, to_variant(*args))
    if result.OutputArguments is None:
        result.OutputArguments = []
    result.OutputArguments = [var.Value for var in result.OutputArguments]
    return result


async def _call_method(
    session: AbstractSession,
    parentnodeid: ua.NodeId,
    methodid: ua.NodeId,
    arguments: list[ua.Variant],
) -> ua.CallMethodResult:
    """
    :param server: `UaClient` or `InternalSession`
    :param parentnodeid:
    :param methodid:
    :param arguments:
    :return:
    """
    request = ua.CallMethodRequest()
    request.ObjectId = parentnodeid
    request.MethodId = methodid
    request.InputArguments = arguments
    methodstocall = [request]
    results = await session.call(methodstocall)
    res = results[0]
    res.StatusCode.check()
    return res


def uamethod(func: Any) -> Any:
    """
    Method decorator to automatically convert
    arguments and output to and from variants
    """

    if inspect.iscoroutinefunction(func):

        @wraps(func)
        async def wrapper(parent: Any, *args: Any) -> Any:
            func_args = _format_call_inputs(parent, *args)
            result = await func(*func_args)
            return _format_call_outputs(result)

    else:

        @wraps(func)
        def wrapper(parent: Any, *args: Any) -> Any:
            func_args = _format_call_inputs(parent, *args)
            result = func(*func_args)
            return _format_call_outputs(result)

    return wrapper


def _format_call_inputs(parent: Any, *args: Any) -> tuple[Any, ...]:
    if isinstance(parent, ua.NodeId):
        return (parent, *[arg.Value for arg in args])
    self = parent
    parent = args[0]
    args = args[1:]
    return (self, parent, *[arg.Value for arg in args])


def _format_call_outputs(result: Any) -> Any:
    if result is None:
        return []
    if isinstance(result, ua.CallMethodResult):
        result.OutputArguments = to_variant(*result.OutputArguments)
        return result
    if isinstance(result, ua.StatusCode):
        return result
    if isinstance(result, tuple):
        return to_variant(*result)
    return to_variant(result)


def to_variant(*args: Any) -> list[ua.Variant]:
    """Create a list of ua.Variants from a given iterable of arguments."""
    uaargs: list[ua.Variant] = []
    for arg in args:
        if not isinstance(arg, ua.Variant):
            arg = ua.Variant(arg)
        uaargs.append(arg)
    return uaargs
