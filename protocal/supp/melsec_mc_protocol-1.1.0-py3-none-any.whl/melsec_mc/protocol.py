import socket
import struct
from typing import Union, List, Tuple
from enum import Enum


class MCProtocolType(Enum):
    """MC协议类型"""
    BINARY = 1  # 二进制协议
    ASCII = 2   # ASCII协议


class FrameType(Enum):
    """帧类型"""
    TYPE3E = 3  # 3E帧
    TYPE4E = 4  # 4E帧


class PLCSeries(Enum):
    """PLC系列"""
    Q = "Q"         # Q系列
    L = "L"         # L系列
    QnA = "QnA"     # QnA系列
    iQ_L = "iQ-L"   # iQ-L系列
    iQ_R = "iQ-R"   # iQ-R系列


class DeviceType(Enum):
    """设备类型"""
    X = "X"     # 输入继电器
    Y = "Y"     # 输出继电器
    M = "M"     # 内部继电器
    D = "D"     # 数据寄存器
    W = "W"     # 链接寄存器
    R = "R"     # 文件寄存器
    S = "S"     # 状态继电器
    T = "T"     # 定时器
    C = "C"     # 计数器
    L = "L"     # 锁存继电器
    B = "B"     # 链接继电器（Q系列）
    F = "F"     # 特殊继电器
    V = "V"     # 变址寄存器
    Z = "Z"     # 变址寄存器
    U = "U"     # 链接寄存器（QnA系列）
    G = "G"     # 链接继电器（A系列）
    P = "P"     # 边缘继电器
    I = "I"     # 立即输入继电器
    Q = "Q"     # 立即输出继电器
    SM = "SM"   # 特殊辅助继电器
    SD = "SD"   # 特殊数据寄存器
    TS = "TS"   # 定时器设定值
    TC = "TC"   # 定时器当前值
    CS = "CS"   # 计数器设定值
    CC = "CC"   # 计数器当前值


class MelsecMCProtocol:
    """三菱MC协议客户端"""
    
    # 帧头常量
    SUBHEADER_3E = 0x50  # 3E帧子标题
    NETWORK_NO = 0x00    # 网络号
    PC_NO = 0xFF         # PLC号
    REQUEST_MODULE_IO_NO = 0xFF03  # 请求目标模块IO编号
    REQUEST_MODULE_STATION_NO = 0x00  # 请求目标模块站号
    
    # 指令常量
    CMD_BATCH_READ = 0x0401   # 批量读取
    CMD_BATCH_WRITE = 0x1401  # 批量写入
    
    def __init__(self, host: str, port: int = 1025, protocol_type: MCProtocolType = MCProtocolType.BINARY, frame_type: FrameType = FrameType.TYPE3E, plc_series: PLCSeries = PLCSeries.Q):
        """
        初始化MC协议客户端
        
        Args:
            host: PLC IP地址
            port: 端口号，默认1025
            protocol_type: 协议类型，默认二进制协议
            frame_type: 帧类型，默认3E帧
            plc_series: PLC系列，默认Q系列
        """
        self.host = host
        self.port = port
        self.protocol_type = protocol_type
        self.frame_type = frame_type
        self.plc_series = plc_series
        self.socket = None
        self.timeout = 5  # 默认超时5秒
        self.serial_id = 0  # 4E帧的序列号
    
    def connect(self) -> bool:
        """建立连接"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(self.timeout)
            self.socket.connect((self.host, self.port))
            return True
        except Exception as e:
            print(f"连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.socket:
            self.socket.close()
            self.socket = None
    
    def _build_request_header(self, data_length: int) -> bytes:
        """
        构建请求帧头
        
        Args:
            data_length: 数据部分长度
            
        Returns:
            帧头字节数据
        """
        if self.protocol_type == MCProtocolType.BINARY:
            header = bytearray()
            
            if self.frame_type == FrameType.TYPE3E:
                # 3E帧头
                # 子标题
                header.append(self.SUBHEADER_3E)
                header.append(0x00)  # 子标题第二字节
                # 网络号
                header.append(self.NETWORK_NO)
                # PLC号
                header.append(self.PC_NO)
                # 请求目标模块IO编号 (高字节在前)
                header.extend(struct.pack('>H', self.REQUEST_MODULE_IO_NO))
                # 请求目标模块站号
                header.append(self.REQUEST_MODULE_STATION_NO)
                # 请求数据长度 (低字节在前，包含请求数据长度本身)
                total_length = 2 + data_length  # 2是请求数据长度字段本身
                header.extend(struct.pack('<H', total_length))
                # CPU监视定时器 (低字节在前)
                header.extend(struct.pack('<H', 16))
            elif self.frame_type == FrameType.TYPE4E:
                # 4E帧头
                # 子标题
                header.append(0x52)  # 4E帧子标题
                header.append(0x00)  # 子标题第二字节
                # 网络号
                header.append(self.NETWORK_NO)
                # PLC号
                header.append(self.PC_NO)
                # 请求目标模块IO编号 (高字节在前)
                header.extend(struct.pack('>H', self.REQUEST_MODULE_IO_NO))
                # 请求目标模块站号
                header.append(self.REQUEST_MODULE_STATION_NO)
                # 序列号 (低字节在前)
                header.extend(struct.pack('<I', self.serial_id))
                # 请求数据长度 (低字节在前，包含请求数据长度本身)
                total_length = 2 + data_length  # 2是请求数据长度字段本身
                header.extend(struct.pack('<H', total_length))
                # CPU监视定时器 (低字节在前)
                header.extend(struct.pack('<H', 16))
                # 增加序列号
                self.serial_id += 1
            
            return bytes(header)
        elif self.protocol_type == MCProtocolType.ASCII:
            # ASCII帧头
            # 起始字符
            header = "@"
            # 网络号 (2位十六进制)
            header += f"{self.NETWORK_NO:02X}"
            # PLC号 (2位十六进制)
            header += f"{self.PC_NO:02X}"
            # 请求目标模块IO编号 (4位十六进制，高字节在前)
            header += f"{self.REQUEST_MODULE_IO_NO:04X}"
            # 请求目标模块站号 (2位十六进制)
            header += f"{self.REQUEST_MODULE_STATION_NO:02X}"
            # 请求数据长度 (4位十六进制，包含请求数据长度本身)
            total_length = 4 + data_length * 2  # ASCII模式下，每个字节用2个字符表示
            header += f"{total_length:04X}"
            # CPU监视定时器 (4位十六进制)
            header += f"{16:04X}"
            # 结束字符
            header += "*"
            return header.encode('ascii')
    
    def _build_device_address(self, device_type: DeviceType, address: int) -> bytes:
        """
        构建设备地址
        
        Args:
            device_type: 设备类型
            address: 设备地址
            
        Returns:
            设备地址字节数据
        """
        if self.protocol_type == MCProtocolType.BINARY:
            addr_bytes = bytearray()
            # 起始软元件编号 (3字节，低字节在前)
            addr_bytes.extend(struct.pack('<I', address)[:3])
            # 软元件代码
            device_code = self._get_device_code(device_type)
            addr_bytes.append(device_code)
            return bytes(addr_bytes)
        elif self.protocol_type == MCProtocolType.ASCII:
            # ASCII模式下，设备地址格式为：设备类型+地址
            # 例如：D100
            device_str = device_type.value
            address_str = f"{address:06X}"  # 6位十六进制地址
            return (device_str + address_str).encode('ascii')
    
    def _get_device_code(self, device_type: DeviceType) -> int:
        """
        获取设备代码
        
        Args:
            device_type: 设备类型
            
        Returns:
            设备代码
        """
        device_codes = {
            DeviceType.X: 0x9C,
            DeviceType.Y: 0x9D,
            DeviceType.M: 0x90,
            DeviceType.D: 0xA8,
            DeviceType.W: 0xB4,
            DeviceType.R: 0xAF,
            DeviceType.S: 0x91,
            DeviceType.T: 0xC0,
            DeviceType.C: 0xC1,
            DeviceType.L: 0x92,
            DeviceType.B: 0xA0,
            DeviceType.F: 0x93,
            DeviceType.V: 0xA9,
            DeviceType.Z: 0xAA,
            DeviceType.U: 0xB4,
            DeviceType.G: 0xB0,
            DeviceType.P: 0x94,
            DeviceType.I: 0x9C,
            DeviceType.Q: 0x9D,
            DeviceType.SM: 0x93,
            DeviceType.SD: 0xA8,
            DeviceType.TS: 0xC2,
            DeviceType.TC: 0xC0,
            DeviceType.CS: 0xC3,
            DeviceType.CC: 0xC1,
        }
        return device_codes.get(device_type, 0xA8)
    
    def _send_request(self, request_data: bytes) -> bytes:
        """
        发送请求并接收响应
        
        Args:
            request_data: 请求数据
            
        Returns:
            响应数据
        """
        if not self.socket:
            raise ConnectionError("未连接到PLC")

        if self.protocol_type == MCProtocolType.BINARY:
            # 构建完整请求帧
            header = self._build_request_header(len(request_data))
            full_request = header + request_data

            # 发送请求
            print("发送请求:")
            print(' '.join(f'{b:02X}' for b in full_request))

            self.socket.sendall(full_request)

            # 根据帧类型确定响应帧头长度
            if self.frame_type == FrameType.TYPE3E:
                header_length = 9
                data_length_offset = 7
            elif self.frame_type == FrameType.TYPE4E:
                header_length = 13  # 4E帧头比3E帧头多4字节序列号
                data_length_offset = 11

            # 接收响应帧头
            response_header = self._recv_all(header_length)
            print("接收响应帧头:")
            print(' '.join(f'{b:02X}' for b in response_header))

            if len(response_header) < header_length:
                raise ConnectionError("接收响应帧头失败")

            # 解析响应数据长度
            response_data_length = struct.unpack('<H', response_header[data_length_offset:data_length_offset+2])[0]

            # 接收响应数据
            response_data = self._recv_all(response_data_length)

            # 检查结束代码
            end_code = struct.unpack('<H', response_data[0:2])[0]
            if end_code != 0:
                raise RuntimeError(f"PLC返回错误码: 0x{end_code:04X}")

            return response_data[2:]  # 返回数据部分（去掉结束代码）
        elif self.protocol_type == MCProtocolType.ASCII:
            # 构建完整请求帧
            header = self._build_request_header(len(request_data))
            # 转换请求数据为ASCII十六进制字符串
            request_data_ascii = ''.join(f'{b:02X}' for b in request_data)
            # 计算CRC
            crc = self._calculate_crc(header.decode('ascii') + request_data_ascii)
            # 构建完整请求
            full_request = (header.decode('ascii') + request_data_ascii + crc).encode('ascii')

            # 发送请求
            print("发送请求:")
            print(full_request.decode('ascii'))

            self.socket.sendall(full_request)

            # 接收响应（ASCII协议响应以\r\n结尾）
            response = b''
            while True:
                chunk = self.socket.recv(1024)
                if not chunk:
                    raise ConnectionError("连接已关闭")
                response += chunk
                if b'\r\n' in response:
                    break

            # 解析响应
            response_str = response.decode('ascii').strip()
            print("接收响应:")
            print(response_str)

            # 检查响应格式
            if not response_str.startswith('@') or '*' not in response_str:
                raise RuntimeError("响应格式错误")

            # 提取数据部分
            data_part = response_str.split('*')[1]
            # 去掉CRC
            data_part = data_part[:-4]  # CRC占4个字符

            # 解析结束代码
            end_code_str = data_part[:4]
            end_code = int(end_code_str, 16)
            if end_code != 0:
                raise RuntimeError(f"PLC返回错误码: 0x{end_code:04X}")

            # 转换数据部分为字节
            data_bytes = bytes.fromhex(data_part[4:])
            return data_bytes

    def _calculate_crc(self, data: str) -> str:
        """
        计算ASCII协议的CRC校验

        Args:
            data: 要计算CRC的数据字符串

        Returns:
            CRC校验值（4位十六进制字符串）
        """
        crc = 0
        for char in data:
            crc ^= ord(char)
        return f"{crc:04X}"
    
    def _recv_all(self, size: int) -> bytes:
        """
        接收指定长度的数据
        
        Args:
            size: 需要接收的字节数
            
        Returns:
            接收到的数据
        """
        data = bytearray()
        while len(data) < size:
            chunk = self.socket.recv(size - len(data))
            if not chunk:
                raise ConnectionError("连接已关闭")
            data.extend(chunk)
        return bytes(data)
    
    def read_single_register(self, device_type: DeviceType, address: int) -> int:
        """
        读取单个寄存器
        
        Args:
            device_type: 设备类型
            address: 设备地址
            
        Returns:
            寄存器值（16位有符号整数）
        """
        return self.read_batch_registers(device_type, address, 1)[0]

    def write_single_register(self, device_type: DeviceType, address: int, value: int) -> bool:
        """
        写入单个寄存器
        
        Args:
            device_type: 设备类型
            address: 设备地址
            value: 要写入的值（16位有符号整数）
            
        Returns:
            是否写入成功
        """
        return self.write_batch_registers(device_type, address, [value])

    def read_batch_registers(self, device_type: DeviceType, start_address: int, count: int) -> List[int]:
        """
        批量读取寄存器
        
        Args:
            device_type: 设备类型
            start_address: 起始地址
            count: 读取数量
            
        Returns:
            寄存器值列表
        """
        if count <= 0 or count > 960:
            raise ValueError("批量读取数量必须在1-960之间")

        # 构建请求数据
        request = bytearray()
        
        # 检查是否为位设备
        is_bit_device = device_type in [DeviceType.X, DeviceType.Y, DeviceType.M, DeviceType.S, DeviceType.L, DeviceType.B, DeviceType.F, DeviceType.P, DeviceType.I, DeviceType.Q, DeviceType.SM]
        
        if self.protocol_type == MCProtocolType.BINARY:
            # 指令 (小端序)
            request.extend(struct.pack('<H', self.CMD_BATCH_READ))
            
            # 根据PLC系列设置子指令
            if is_bit_device:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列位单位操作子指令
                    request.extend(struct.pack('<H', 0x0003))
                else:
                    # 其他系列位单位操作子指令
                    request.extend(struct.pack('<H', 0x0001))
            else:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列字单位操作子指令
                    request.extend(struct.pack('<H', 0x0002))
                else:
                    # 其他系列字单位操作子指令
                    request.extend(struct.pack('<H', 0x0000))
            
            # 起始软元件
            request.extend(self._build_device_address(device_type, start_address))
            # 软元件点数 (小端序)
            request.extend(struct.pack('<H', count))
        elif self.protocol_type == MCProtocolType.ASCII:
            # ASCII模式下的指令格式
            # 指令
            request.extend(b'0401')
            
            # 根据PLC系列设置子指令
            if is_bit_device:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列位单位操作子指令
                    request.extend(b'0003')
                else:
                    # 其他系列位单位操作子指令
                    request.extend(b'0001')
            else:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列字单位操作子指令
                    request.extend(b'0002')
                else:
                    # 其他系列字单位操作子指令
                    request.extend(b'0000')
            
            # 起始软元件
            request.extend(self._build_device_address(device_type, start_address))
            # 软元件点数
            request.extend(f'{count:04X}'.encode('ascii'))

        # 发送请求
        response = self._send_request(bytes(request))

        # 解析响应数据
        values = []

        if is_bit_device:
            if self.protocol_type == MCProtocolType.BINARY:
                # 二进制协议下，每2个位设备占用1个字节
                # 偶数索引的位设备使用第4位（bit 4）
                # 奇数索引的位设备使用第0位（bit 0）
                for i in range(count):
                    data_index = i // 2
                    value = response[data_index]
                    if i % 2 == 0:
                        # 偶数索引，使用第4位
                        bit_value = 1 if value & (1 << 4) else 0
                    else:
                        # 奇数索引，使用第0位
                        bit_value = 1 if value & (1 << 0) else 0
                    values.append(bit_value)
            elif self.protocol_type == MCProtocolType.ASCII:
                # ASCII协议下，每个位设备使用1个字符
                for i in range(count):
                    value = int(response[i:i+1].decode())
                    values.append(value)
        else:
            # 字设备响应数据（每字2字节，低字节在前）
            for i in range(count):
                value = struct.unpack('<H', response[i*2:(i+1)*2])[0]
                values.append(value)
        return values

    def write_batch_registers(self, device_type: DeviceType, start_address: int, values: List[int]) -> bool:
        """
        批量写入寄存器
        
        Args:
            device_type: 设备类型
            start_address: 起始地址
            values: 要写入的值列表
            
        Returns:
            是否写入成功
        """
        count = len(values)
        if count <= 0 or count > 960:
            raise ValueError("批量写入数量必须在1-960之间")

        # 检查是否为位设备
        is_bit_device = device_type in [DeviceType.X, DeviceType.Y, DeviceType.M, DeviceType.S, DeviceType.L, DeviceType.B, DeviceType.F, DeviceType.P, DeviceType.I, DeviceType.Q, DeviceType.SM]
        
        # 检查位设备值是否合法
        if is_bit_device:
            for value in values:
                if not (value == 0 or value == 1):
                    raise ValueError("位设备的值必须是0或1")

        # 构建请求数据
        request = bytearray()
        
        if self.protocol_type == MCProtocolType.BINARY:
            # 指令 (小端序)
            request.extend(struct.pack('<H', self.CMD_BATCH_WRITE))
            
            # 根据PLC系列设置子指令
            if is_bit_device:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列位单位操作子指令
                    request.extend(struct.pack('<H', 0x0003))
                else:
                    # 其他系列位单位操作子指令
                    request.extend(struct.pack('<H', 0x0001))
            else:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列字单位操作子指令
                    request.extend(struct.pack('<H', 0x0002))
                else:
                    # 其他系列字单位操作子指令
                    request.extend(struct.pack('<H', 0x0000))
            
            # 起始软元件
            request.extend(self._build_device_address(device_type, start_address))
            # 软元件点数 (小端序)
            request.extend(struct.pack('<H', count))
            
            if is_bit_device:
                # 二进制协议下，每2个位设备占用1个字节
                # 偶数索引的位设备使用第4位（bit 4）
                # 奇数索引的位设备使用第0位（bit 0）
                bit_data = [0] * ((count + 1) // 2)
                for i, value in enumerate(values):
                    data_index = i // 2
                    if i % 2 == 0:
                        # 偶数索引，设置第4位
                        if value:
                            bit_data[data_index] |= (1 << 4)
                    else:
                        # 奇数索引，设置第0位
                        if value:
                            bit_data[data_index] |= (1 << 0)
                request.extend(bytes(bit_data))
            else:
                # 写入数据（每字2字节，低字节在前）
                for value in values:
                    request.extend(struct.pack('<H', value))
        elif self.protocol_type == MCProtocolType.ASCII:
            # ASCII模式下的指令格式
            # 指令
            request.extend(b'1401')
            
            # 根据PLC系列设置子指令
            if is_bit_device:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列位单位操作子指令
                    request.extend(b'0003')
                else:
                    # 其他系列位单位操作子指令
                    request.extend(b'0001')
            else:
                if self.plc_series == PLCSeries.iQ_R:
                    # iQ-R系列字单位操作子指令
                    request.extend(b'0002')
                else:
                    # 其他系列字单位操作子指令
                    request.extend(b'0000')
            
            # 起始软元件
            request.extend(self._build_device_address(device_type, start_address))
            # 软元件点数
            request.extend(f'{count:04X}'.encode('ascii'))
            
            if is_bit_device:
                # ASCII协议下，每个位设备使用1个字符
                for value in values:
                    request.extend(str(value).encode())
            else:
                # 写入数据（每字4个十六进制字符）
                for value in values:
                    request.extend(f'{value:04X}'.encode('ascii'))

        # 发送请求
        self._send_request(bytes(request))
        return True
